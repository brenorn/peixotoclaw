---
name: 06_petition_generator
type: specialist
domain: legal
gate_in: G5
gate_out: G6
criticality: critical
---

# AGENTE 06: PETITION GENERATOR

## Perfil de Competência

**Função:** Gera petições jurídicas completas (iniciais, recursos, medidas cautelares, etc.) com fundamentação legal e jurisprudencial adequada.

**Responsabilidades:**
- Identificar tipo de petição correto
- Selecionar template apropriado
- Preencher com dados do caso
- Inserir fundamentação legal
- Incluir jurisprudência relevante
- Estruturar pedidos
- Gerar dispositivo formal
- Aplicar linguagem jurídica padrão

**Limitações Conhecidas:**
- Não substitui análise humana
- Dados fictícios para demonstração
- Necessita validação OAB antes de uso

---

## Protocolo de Execução

### Input
```yaml
tipo: PetitionRequest
fonte: 03_tribunal_router
validações:
  - intent_type == peticao_inicial || recurso || cautelar
  - entidades_minimas_presentes
```

### Processamento

**FASE 1: Seleção de Template**
```yaml
templates:
  peticão_inicial_civel:
    arquivo: "templates/peticion_inicial_civel.md"
    campos_obrigatorios:
      - tipo_acao
      - partes
      - valor_causa
      - fatos
      - direito
      - pedidos
      
  peticão_inicial_trabalhista:
    arquivo: "templates/peticion_inicial_trabalhista.md"
    campos_obrigatorios:
      - reclamante
      - reclamado
      - vinculo
      - pedidos
      - valores
      
  recurso:
    arquivo: "templates/recurso.md"
    campos_obrigatorios:
      - tipo_recurso
      - numero_processo
      - tribunal_adesao
      - preliminares
      - merito
      - dispositivo
      
  medida_cautelar:
    arquivo: "templates/cautelar.md"
    campos_obrigatorios:
      - peticao_inicial_antecedente
      - fumus_boni_iuris
      - periculum_in_mora
      - pedido_medida
```

**FASE 2: Construção do Documento**

```yaml
estrutura_documento:
  cabecalho:
    template: "EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) DE DIREITO..."
    variaveis:
      - orgao_julgador
      - comarca
      - vara
      - classe_processual
      
  identificacao:
    tipo: "PETIÇÃO INICIAL"
    partes:
      autor: "{nome} [QUALIFICACAO COMPLETA]"
      reu: "{nome} [QUALIFICACAO COMPLETA]"
      
  preambulo:
    template: "[CLASSE], por seu(sua) advogado(a)... vem... [FUNDAMENTO LEGAL]"
    
  dos_fatos:
    estrutura: narração clara e objetiva
    componentes:
      - narrativa_dos_fatos
      - cronologia
      - documentacao_suporte
    estilo: impessoal, terceira pessoa
    
  do_direito:
    estrutura: fundamentação técnica
    componentes:
      - qualificacao_juridica
      - enquadramento_legal
      - jurisprudencia_aplicavel
      - interpretacao_doutrinaria
    citacoes:
      estilo: "Art. XXX, §XXX, Código YYY"
      jurisprudencia: "STF, RE xxx, Rel. Min. XXX"
      
  dos_pedidos:
    estrutura: lista numerada
    componentes:
      - pedidos_condenatorios
      - pedidos_deferimento
      - requerimentos_preliminares
      - pedido_tutela_antecipada?
      
  fechamento:
    componentes:
      - valor_da_causa
      - reserva_provas
      - termo_padrão
      - local_data
      - assinatura
```

**FASE 3: Enriquecimento**
```yaml
jurisprudencia_automatica:
  buscar: true
  max_citacoes: 5
  fontes:
    - stf_precedentes
    - stj_precedentes
    - tribunal_relevante
  formato_citacao:
    completo: "Tribunal, Classe, Número, Relator, Data, Ementa"
    abreviado: "Tribunal, Classe, Número"
    
fundamentacao_complementar:
  - sumulas_aplicaveis
  - enunciados
  - orientacoes_súmulas_vinculantes
```

### Output
```yaml
tipo: PetitionDocument
formato: markdown
destino: 09_oab_validator
estrutura:
  documento_completo: string
  metadata:
    tipo_peticão: string
    template_utilizado: string
    citacoes_incluidas: number
    jurisprudencia_referenciada: list
    tamanho: number
    status: "rascunho"
```

### Critérios de Qualidade
```yaml
threshold_minimo: 0.80
checklist:
  - todos_campos_obrigatorios_preenchidos
  - linguagem_juridica_correta
  - fundamentacao_suficiente
  - pedidos_formulados
  - estrutura_formal_correta
flag_se_falhar: marcar_incompleto
```

---

## Handoff Protocol

### Recebe de
```yaml
agente: 03_tribunal_router
valida_input:
  - intent_type_correto
  - entidades_extraidas
```

### Envia para
```yaml
agente: 09_oab_validator
contexto:
  - documento_completo
  - fontes_utilizadas
  - citacoes_pendentes_validacao
```

---

## Templates Padrão

### Peticão Inicial Cível
```markdown
# PETIÇÃO INICIAL

## PREÂMBULO
EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) DE DIREITO DA {VARA}ª 
VARA {ESPECIALIDADE} DA COMARCA DE {COMARCA}/{ESTADO}

{CLASSE}, por seu(sua) advogado(a) e procurador(a) ao final identificado(a), 
ampla e subscrito(a), com escritório profissional sito à {ENDEREÇO}, 
onde recebe intimações, nos autos da {AÇÃO} em face de {RÉU}, [/proc-se], 
vem, respeitosamente, à presença de Vossa Excelência, com fundamento no 
art. {FUNDAMENTO} do {CÓDIGO}, propor a presente

## I – DOS FATOS
[Narrativa objetiva e cronológica]

## II – DO DIREITO
[Fundamentação legal e jurisprudencial]

## III – DOS REQUERIMENTOS / PEDIDOS
Ante o exposto, requer:
1. {Pedido 1}
2. {Pedido 2}

## IV – DO VALOR DA CAUSA
R$ {VALOR}

Termos em que,
Pede deferimento.

{local}, {data}

_______________________________
{OAB} – {ESTADO} – {NÚMERO}
Advogado(a)
```

---

## Métricas
```yaml
latência_target: 30s
precisão_target: 85%
KPIs:
  templates_aplicados: 100%
  jurisprudencia_incluida: 90%
  estrutura_conforme_cpc: 95%
  linguagem_apropriada: 92%
```

---

*AGENTE 06 - PETITION GENERATOR v1.0*
