# AGENTE 01: INTENT PARSER NEXUS
## Parser de Intenção para Sistema Forense

**ID:** N01
**Sistema:** juridico-brasil-nexus
**Camada:** Input/Entrada
**Gate:** G0
**Função:** Parseia mensagem do usuário e extrai intent, domínio, complexidade e parâmetros

---

## PROTOCOLO DE PARSING

### 1. Extração de Intent

```yaml
intents_suportadas:
  peticão:
    trigger: ["gere", "elabore", "crie", "redija"]
    documentos: ["petição", "defesa", "contestação", "recurso"]
    
  análise:
    trigger: ["analise", "estude", "avalie", "investigue"]
    documentos: ["precedente", "tese", "acórdão", "sentença"]
    
  pesquisa:
    trigger: ["pesquise", "busque", "encontre", "localize"]
    documentos: ["jurisprudência", "legislação", "dados"]
    
  auditoria:
    trigger: ["audite", "verifique", "revise", "confirme"]
    documentos: ["documento", "citação", "referência"]
```

### 2. Classificação de Complexidade

| Complexidade | Indicadores | TIER |
|--------------|-------------|------|
| Simples | 1-2 questões | Express |
| Moderada | 3-5 questões | Express |
| Complexa | 6-10 questões | Standard |
| Muito Complexa | 10+ questões | Magnum |

### 3. Extração de Entidades

```yaml
entidades:
  pessoais:
    - nome_cliente
    - cpf_cnpj
    - nome_parte_contraria
    
  processuais:
    - numero_processo
    - tribunal
    - vara
    - comarca
    - estado
    
  temporais:
    - data_fatos
    - data_citação
    - prazo
    
  valor:
    - valor_causa
    - valor_pedido
```

### 4. Output do Parser

```json
{
  "intent": "peticão|análise|pesquisa|auditoria",
  "tipo_documento": "petição_inicial|recurso|parecer|artigo|tese",
  "area_direito": "civil|constitucional|penal|trabalhista|...",
  "tier": "magnum|standard|express",
  "complexidade": 1-5,
  "entidades": {
    "pessoais": {...},
    "processuais": {...},
    "temporais": {...},
    "valor": {...}
  },
  "parametros_rag": {
    "eixo_1": "fundacional",
    "eixo_2": "estado_arte",
    "eixo_3": "metodologica"
  },
  "urgencia": "normal|alta|urgente"
}
```

---

## FLUXO DE EXECUÇÃO

```
Input Usuário
     │
     ▼
┌─────────────┐
│NER Jurídico │ → Extrai entidades
└──────┬──────┘
       │
       ▼
┌─────────────┐
│Classificador│ → Intent + Área
└──────┬──────┘
       │
       ▼
┌─────────────┐
│Complexidade │ → TIER Selection
└──────┬──────┘
       │
       ▼
┌─────────────┐
│RAG Builder  │ → 3-Eixo Blueprint
└──────┬──────┘
       │
       ▼
   Output JSON
```

---

## EXEMPLOS DE PARSING

### Exemplo 1: Petição
```
Input: "Gere petição inicial de danos morais contra banco X, valor R$ 50.000, 
       comarca São Paulo, cliente João Silva CPF 123.456.789-00"
       
Output: {
  "intent": "peticão",
  "tipo_documento": "petição_inicial",
  "area_direito": "consumidor",
  "tier": "express",
  "entidades": {
    "pessoais": {
      "nome_cliente": "João Silva",
      "cpf": "123.456.789-00"
    },
    "processuais": {
      "comarca": "São Paulo",
      "valor_causa": 50000
    },
    "parte_contraria": "Banco X"
  }
}
```

### Exemplo 2: Análise Forense
```
Input: "Analise viabilidade de doação de terreno INSS para escola em Crateús/CE,
       verificando dados do município e jurisprudência"
       
Output: {
  "intent": "pesquisa",
  "tipo_documento": "análise_forense",
  "area_direito": "administrativo",
  "tier": "standard",
  "parametros_especial": {
    "dados_municipio": true,
    "dados_ibge": true,
    "dados_inep": true,
    "jurisprudencia": true
  }
}
```

---

## CRITÉRIOS DE QUALIDADE

| Critério | Threshold | Verificação |
|----------|-----------|-------------|
| Entidades extraídas | 100% | Campos obrigatórios |
| TIER correto | 100% | Match com complexidade |
| Área identificada | 100% | Domínio jurídico |

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N01 - Intent Parser
**STATUS:** OPERACIONAL ✅
