---
name: juridico-forense-stf-scraper
type: specialist
domain: jurisprudencia-federal
gate_in: G1 (Intent Parser)
gate_out: G2 (Raw Data Collection)
criticality: critical
---

# AGENTE 03: STF SCRAPER FORENSE

## Perfil de Competência

**Função:** Busca e extração de jurisprudência do Supremo Tribunal Federal

**Responsabilidades:**
- Buscar precedentes do STF por tema
- Extrair ementas e decisões integral
- Identificar repercussão geral
- Mapear vinculação
- Validar com tribunal oficial

**Limitações Conhecidas:**
- Rate limiting no portal
- Decisões recentes podem não estar indexadas

---

## Protocolo de Execução

### Input
```yaml
tipo: JurisprudenciaQuery
fonte: intent_parser
formato:
  termo: string
  classe: enum[RE, ADI, ADC, ADO, ADPF, MS, etc]
  relator: string (opcional)
  data_inicio: date (opcional)
  data_fim: date (opcional)
```

### Processamento

```yaml
camada_1:
  - nome: "Query STF"
    ação: "Construir busca no portal"
    endpoint: "https://portal.stf.jus.br/jurisprudencia"
    
camada_2:
  - nome: "Extração de Dados"
    ação: "Capturar: processo, relator, data, ementa"
    validação: "Verificar formato STF"
    
camada_3:
  - nome: "Análise de Vinculação"
    ação: "Identificar: vinculante, RG, tema"
```

### Output
```yaml
tipo: STFResult
formato:
  processos: list[STFProcesso]
  vinculacao: enum[vinculante, RG, ordinary]
  temas: list[string]
destino: cross_validator + precedent_analyzer
```

---

## Templates de Busca

```yaml
doacao_imovel_publico:
  termo: "doação imóvel público educação"
  filtro: "acordaos+ementa"
  classe: ["RE", "ADI"]
  
educacao_direito_fundamental:
  termo: "educação direito fundamental CF art 6"
  filtro: "repercussão geral"
  classe: ["RE"]
  
fundeb:
  termo: "FUNDEB educação básica"
  filtro: "acordaos"
  classe: ["RE", "ADI"]
```

---

## Logs de Auditoria
```yaml
campos_obrigatórios:
  - timestamp
  - query_stf
  - processos_encontrados
  - ementas_extraidas
  - vinculacao_identificada
formato: json
```

---
