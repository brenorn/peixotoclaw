---
name: 01_intent_parser_juridico
type: specialist
domain: legal
gate_in: G1
gate_out: G2
criticality: critical
---

# AGENTE 01: INTENT PARSER JURÍDICO

## Perfil de Competência

**Função:** Parser especializado para extrair intent, entidades e parâmetros de mensagens jurídicas em português brasileiro. Identifica tipo de ação, tema, urgência e contexto processual.

**Responsabilidades:**
- Extrair intent principal (petição, análise, pesquisa, contra-argumentação)
- Identificar entidades jurídicas (tribunal, classe processual, partes, valor)
- Classificar tema/área do direito (cível, trabalhista, penal, tributário)
- Detectar urgência e prioridade
- Identificar fundamentos legais mencionados
- Extrair números de processo quando presentes

**Limitações Conhecidas:**
- Limitado a texto em português brasileiro
- Dificuldade com gírias jurídicas regionais
- Não processa imagens ou anexos

---

## Protocolo de Execução

### Input
```yaml
tipo: string
fonte: 00_orchestrator
formato: texto_livre
validações:
  - texto_nao_vazio
  - idioma_portugues
```

### Processamento

**Fase 1 - Tokenização Semântica**
```yaml
operacoes:
  - nome: "SegmentarSentencas"
    descricao: "Dividir texto em sentenças"
  - nome: "ExtrairEntidades"
    descricao: "Identificar entidades Nomeadas (NER)"
    classes:
      - TRIBUNAL: "STF, STJ, TJSP, TJRJ"
      - CLASSE: "Petição, Recurso, Ação"
      - VALOR: "R$ 50.000"
      - PROCESSO: "0001234-XX.2024.8.26"
      - AREA: "Cível, Trabalhista, Penal"
      - FUNDAMENTO: "Art. 186 CC"
```

**Fase 2 - Classificação de Intent**
```yaml
intents_suportadas:
  peticao_inicial:
    triggers: ["gere petição", "criar petição", "ajuizar"]
    entities: ["tipo_acao", "valor", "comarca", "vara"]
    
  recurso:
    triggers: ["recurso", "apelar", "impugnar"]
    entities: ["tipo_recurso", "tribunal", "numero_processo"]
    
  analise_falhas:
    triggers: ["analise falha", "vício", "erro processual"]
    entities: ["numero_processo", "tribunal", "relator"]
    
  pesquisa_precedentes:
    triggers: ["busque", "encontre", "precedente", "jurisprudência"]
    entities: ["tema", "tribunal", "periodo"]
    
  contra_argumentacao:
    triggers: ["rebater", "contra-argumento", "contestar"]
    entities: ["tes", "falha", "tribunal"]
    
  pesquisa_legislacao:
    triggers: ["lei", "legislação", "decreto"]
    entities: ["norma", "emento", "vigencia"]
```

**Fase 3 - Extração de Parâmetros**
```yaml
parametros:
  obrigatorios:
    - intent_type
    - tema_juridico
  opcionais:
    - tribunal
    - numero_processo
    - valor_causa
    - comarca
    - vara
    - urgencia
  gerados:
    - query_string
    - data_sources
    - agents_needed
```

### Output
```yaml
tipo: IntentSpec
formato: structured_json
destino: 02_query_builder
estrutura:
  intent_type: enum
  tema: string
  area_direito: enum[civel, trabalhista, penal, tributario, constitucional, consumidor, ambiental]
  urgencia: enum[baixa, normal, alta, urgente]
  entidades:
    tribunal: string|nulo
    classe_processual: string|nulo
    numero_processo: string|nulo
    valor: number|nulo
    comarca: string|nulo
    fundamento_legal: list[string]
  contexto: object
  confianca: float[0-1]
```

### Critérios de Qualidade
```yaml
threshold_minimo: 0.80
checklist:
  - intent_maior_que_2_tokens
  - area_direito_identificada
  - entidades_maiores_ou_iguais_3
  - confianca_acima_threshold
flag_se_falhar: request_clarification
```

---

## Handoff Protocol

### Recebe de
```yaml
agente: 00_juridico_orchestrator
valida_input:
  - texto_original_preservado
  - metadados_originais
```

### Envia para
```yaml
agente: 02_query_builder
formato: json_estruturado
inclui_contexto:
  - intent_spec_completo
  - texto_original
  - confidence_score
  - alternative_intents
```

---

## Métricas
```yaml
latência_target: 200ms
precisão_target: 95%
KPIs:
  intent_classification_accuracy: 97%
  ner_accuracy: 94%
  entity_extraction_f1: 0.92
```

---

## Exemplos de Parsing

### Exemplo 1: Petição
```
Input: "Gere petição inicial de danos morais contra banco X por inscrição 
       indevida no SPC, valor R$ 50.000, comarca São Paulo, 2ª Vara Cível"

Output:
{
  "intent_type": "peticao_inicial",
  "area_direito": "consumidor",
  "urgencia": "normal",
  "entidades": {
    "tipo_acao": "danos_morais",
    "reu": "banco X",
    "motivo": "inscrição indevida no SPC",
    "valor": 50000,
    "comarca": "São Paulo",
    "vara": "2ª Vara Cível"
  },
  "confianca": 0.95
}
```

### Exemplo 2: Análise de Falhas
```
Input: "Analise o RE 1.000.000 e identifique falhas processuais"

Output:
{
  "intent_type": "analise_falhas",
  "area_direito": "constitucional",
  "entidades": {
    "numero_processo": "RE 1.000.000",
    "tribunal": "STF",
    "tipo_analise": ["processuais", "materiais"]
  },
  "confianca": 0.92
}
```

---

## Logs
```yaml
campos:
  - timestamp
  - input_hash
  - intent_detected
  - entities_extracted
  - confidence
  - processing_time
```

---

*AGENTE 01 - INTENT PARSER JURÍDICO v1.0*
