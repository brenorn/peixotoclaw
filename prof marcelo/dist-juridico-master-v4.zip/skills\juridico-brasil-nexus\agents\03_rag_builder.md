# AGENTE 03: RAG BUILDER
## Blueprint de Referências - 3 Eixos de Citação

**ID:** N03
**Sistema:** juridico-brasil-nexus
**Camada:** Input/Entrada
**Gate:** G0
**Função:** Constrói blueprint de referências baseado no RAG Protocol de 3 eixos

---

## PROTOCOLO RAG - 3 EIXOS

### 1. Estrutura dos Eixos

```yaml
rag_protocol:
  eixo_1:
    nome: "Literatura Fundacional"
    temporalidade: ">10 anos"
    objetivo: "Teorias seminais, marcos conceituais"
    fontes:
      - "Livros clássicos de direito"
      - "Obras de referência"
      - "Doutrina clássica"
      
  eixo_2:
    nome: "Estado da Arte"
    temporalidade: "Últimos 3-5 anos"
    objetivo: "Top Journals Scopus/WoS/Q1"
    fontes:
      - "Artigos acadêmicos Q1"
      - "Revistas jurídicas Qualis A1"
      - "Precedentes recentes STF/STJ"
      
  eixo_3:
    nome: "Metodológica"
    temporalidade: "Validada"
    objetivo: "Técnicas, frameworks, instrumentos"
    fontes:
      - "Metodologias comprovadas"
      - "Frameworks jurídicos"
      - "Instrumentos de pesquisa"
```

### 2. Regras de Citação Obrigatórias

```yaml
citacao_strictness:
  nivel: MAXIMO
  
  regras:
    - "NENHUMA afirmação categórica sem lastro"
    - "Formato ABNT NBR 10520: [Autor, Ano, Página]"
    - "Formato APA 7th: (Autor, Ano)"
    
  contraditorios:
    obrigatorio: true
    minimo: 1
    justificativa: "Ciência repousa sobre falseabilidade"
```

### 3. Anti-Hallucination Check

```
Para cada CITACAO no texto:
□ Autor existe na literatura jurídica?
□ Ano é consistente com a obra citada?
□ Página é verificável no original?
□ Contexto da citação está correto?
□ Não há citação de heard-say (ouviu dizer)?

Se QUALQUER resposta for NÃO:
→ REMOVER ou CORRIGIR a citação
```

---

## BLUEPRINT RAG CONSTRUTOR

### 1. Input do Agente

```json
{
  "intent": "peticão|artigo|tese|parecer",
  "area_direito": "civil|constitucional|...",
  "tema_especifico": "contratos|responsabilidade|...",
  "tier": "magnum|standard|express",
  "parametros_temporal": {
    "data_inicio": "YYYY-MM-DD",
    "data_fim": "YYYY-MM-DD"
  }
}
```

### 2. Output - Blueprint RAG

```json
{
  "blueprint": {
    "id": "uuid",
    "data_criacao": "YYYY-MM-DD",
    "tier": "magnum",
    "eixos": {
      "eixo_1_fundacional": {
        "min_referencias": 15,
        "max_referencias": 30,
        "temporalidade": ">10 anos",
        "tipos": ["livros", "doutrina_classica"],
        "query_template": "site:scholar.google.com OR site:scielo.br {tema} autor:{autor}"
      },
      "eixo_2_estado_arte": {
        "min_referencias": 20,
        "max_referencias": 50,
        "temporalidade": "3-5 anos",
        "tipos": ["artigos_q1", "precedentes_recentes", "legislacao_vigente"],
        "query_template": "site:stf.jus.br OR site:stj.jus.br {tema} {ano}"
      },
      "eixo_3_metodologica": {
        "min_referencias": 10,
        "max_referencias": 20,
        "temporalidade": "validada",
        "tipos": ["metodologias", "frameworks", "instrumentos"],
        "query_template": "{tema} metodologia OR framework OR instrumento"
      }
    },
    "total_min": 45,
    "total_max": 100
  }
}
```

---

## EXEMPLO DE BLUEPRINT

### Tema: "Responsabilidade Civil no Direito Digital"

```yaml
blueprint:
  tema: "Responsabilidade Civil no Direito Digital"
  area: "civil_consumidor"
  tier: "standard"
  
  eixo_1_fundacional:
    referencias:
      - "GONÇALVES, Carlos Roberto. Responsabilidade Civil. Saraiva."
      - "DINIZ, Maria Helena. Curso de Direito Civil Brasileiro."
      - "PEREIRA, Caio Mário da Silva. Responsabilidade Civil."
      - "VENOSA, Sílvio de Salvo. Direito Civil."
    query: "responsabilidade civil fundamentos doutrina clássica"
    
  eixo_2_estado_arte:
    referencias:
      - "STF: RE 1.000.000 (LGPD e proteção de dados)"
      - "STJ: Temas sobre direito digital"
      - "Artigos: Responsabilidade civil digital (2020-2024)"
    query: "site:stf.jus.br OR site:stj.jus.br responsabilidade digital 2020..2024"
    
  eixo_3_metodologica:
    referencias:
      - "Framework de análise de danos morais"
      - "Metodologia de cálculo de indenizações"
      - "Instrumentos de prova digital"
    query: "responsabilidade civil digital metodologia framework"
```

---

## VALIDAÇÃO DO BLUEPRINT

### Checklist

- [ ] Eixo 1 tem mínimo de referências fundacionais
- [ ] Eixo 2 tem referências de estado da arte
- [ ] Eixo 3 tem referências metodológicas
- [ ] Não há duplicação de referências entre eixos
- [ ] Temporalidade respeitada
- [ ] Citações seguem formato ABNT

### Score de Conformidade

| Critério | Pontos |
|----------|--------|
| Eixo 1 completo | 33 |
| Eixo 2 completo | 33 |
| Eixo 3 completo | 33 |
| Sem duplicações | +1 |
| **TOTAL** | **100** |

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N03 - RAG Builder
**STATUS:** OPERACIONAL ✅
