# ÍNDICE AMPLIADO DE JURISPRUDÊNCIA v2.0

## STF - SUPREMO TRIBUNAL FEDERAL

### Súmulas Vinculantes (SV 1-45)

| Número | Tema | Thesis |
|--------|------|--------|
| SV 1 | Repercussão Geral | Obrigatória |
| SV 2 | SCP | Não configura |
| SV 3 | STF Competência | Processual Penal |
| SV 4 | CPF | Não onera advogado |
| SV 5 | Perda do objeto | Recurso perde |
| SV 6 | Indenização | Presidente República |
| SV 7 | Transferência | STJ |
| SV 8 | STF Competência | Crimes comuns |
| SV 9 | STF Competência | Desembargadores |
| SV 10 | Precatório | STF competência |
| SV 11 | Proporcionalidade | Vedada interceptação |
| SV 12 | Multa diária | Limite |
| SV 13 | Honorários | Advogado dativo |
| SV 14 | Honorários periciais | Fazenda Pública |
| SV 15 | Competência TRT | Militar |
| SV 16 | Agravo regimental | Reclamação |
| SV 17 | Precatório | Transação |
| SV 18 | Precatório | Alimentos |
| SV 19 | Depoimento | Por precatório |
| SV 20 | Deserção | Custas |
| SV 21 | Reformatio in pejus | Apelação |
| SV 22 | Nulidade | Interesse |
| SV 23 | Reclamação | Competência |
| SV 24 | Competência Federal | Defensores |
| SV 25 | Prisão especial | Diploma superior |
| SV 26 | Denúncia | Prazo |
| SV 27 | Contrabando | Apreensão |
| SV 28 | Contrabando | Similar nacional |
| SV 29 | Receita Federal | Competência |
| SV 30 | IPI | Exportação |
| SV 31 | ICMS | Transferência |
| SV 32 | FGTS | Correção |
| SV 33 | Salário-mínimo | piso |
| SV 34 | Juros | Mora |

### ADCs - Ações Declaratórias de Constitucionalidade

| Número | Tema | Data | Status |
|--------|------|------|--------|
| ADC 1 | Honorários Advocatícios | 1992 | Consolidada |
| ADC 4 | Correção Monetária | 2003 | Revogada |
| ADC 11 | Depósito Prévio | 2001 | Consolidada |
| ADC 12 | Depósito Prévio | 2004 | Consolidada |
| ADC 16 | Correção Monetária | 2009 | Consolidada |
| ADC 25 | STN Dívida Pública | 2005 | Consolidada |
| ADC 30 | Honorários Sucumbenciais | 2015 | Consolidada |
| ADC 43 | Honorários Recursais | 2018 | Consolidada |

### ADIs - Ações Diretas de Inconstitucionalidade Relevantes

| Número | Tema | Data |
|--------|------|------|
| ADI 1 | MP 152/90 | 1991 |
| ADI 3.112 | FGTS | 2005 |
| ADI 4.874 | terceirização | 2018 |
| ADI 5.529 | Contrato Temporal | 2020 |
| ADI 6.387 | SC 100/2019 | 2021 |

### Temas de Repercussão Geral (Exemplos)

| Tema | Número | Tema |
|------|--------|------|
| 1 | RG 1 | Proibição censura |
| 10 | RG 10 | Foro privilege |
| 50 | RG 50 | Horas extraordinárias |
| 100 | RG 100 | Desaposentação |
| 188 | RG 188 | TAC/FGTS |
| 500 | RG 500 | Dano moral |
| 635 | RG 635 | Desconsideração PJ |
| 888 | RG 888 | IRPF auxílio |
| 985 | RG 985 | Desoneração exportadoras |
| 1.010 | RG 1.010 | Marco Civil Internet |

---

## STJ - SUPERIOR TRIBUNAL DE JUSTIÇA

### Súmulas STJ (1-200+)

| Número | Tema |
|--------|------|
| S 1 | Foro Contractus |
| S 7 | REsp Cabimento |
| S 8 | Violação Lei |
| S 9 | Contrato Social |
| S 11 | Honorários Advocatícios |
| S 14 | Fraude à Execução |
| S 33 | Alienação |
| S 51 | Juros |
| S 102 | Honorários |
| S 129 | Responsabilidade |
| S 176 | Mora |
| S 197 | Competência |
| S 265 | Protesto |
| S 277 | Depósito |
| S 281 | Ato Jurídico |

### Temas Repetitivos (TRs)

| Tema | Número | Tema |
|------|--------|------|
| 1 | TR 1 | Responsabilidade civil |
| 12 | TR 12 | Contratos bancários |
| 73 | TR 73 | Indenização |
| 95 | TR 95 | Desconsideração |
| 130 | TR 130 | Franquia |
| 170 | TR 170 | Seguro |
| 183 | TR 183 | Honorários |
| 381 | TR 381 | Honorários recursais |
| 438 | TR 438 | Inclusão indevida |
| 581 | TR 581 | Desconsideração |
| 592 | TR 592 | Falência |

---

## TST - TRIBUNAL SUPERIOR DO TRABALHO

### Súmulas TST

| Número | Tema |
|--------|------|
| TST 17 | Adicional de Insalubridade |
| TST 47 | Horas extras |
| TST 129 | Horas extras |
| TST 219 | Intervalo intrajornada |
| TST 228 | Horas in itinere |
| TST 239 | Adicional de periculosidade |
| TST 291 | Horas extras comissionista |
| TST 294 | Salário utilidade |
| TST 331 | Terceirização |
| TST 376 | Honorários advocatícios |
| TST 414 | Justa causa |
| TST 430 | Prescrição bienal |
| TST 437 | Horas extras |

### Precedentes Administrativos

| Número | Tema |
|--------|------|
| PA 1 | Terceirização |
| PA 2 | Contrato intermitente |
| PA 3 | Teletrabalho |

---

## PRECEDENTES POR MATÉRIA

### Responsabilidade Civil

| Tribunal | Número | Ano | Key Point |
|----------|--------|-----|-----------|
| STF | RE 841.526 | 2016 | Dano moral coletivo |
| STJ | REsp 1.419.421 | 2015 | Dano moral |
| STJ | REsp 1.660.828 | 2017 | Dano existencial |
| STJ | REsp 1.731.003 | 2018 | Dano moral corporativo |

### Contratos

| Tribunal | Número | Ano | Key Point |
|----------|--------|-----|-----------|
| STJ | REsp 1.550.260 | 2016 | Resolução |
| STJ | REsp 1.587.462 | 2017 | Lesão |
| STJ | REsp 1.685.902 | 2018 | Alienação fiduciária |
| STJ | REsp 1.732.082 | 2019 | Contrato de gaveta |

### Direito do Consumidor

| Tribunal | Número | Ano | Key Point |
|----------|--------|-----|-----------|
| STJ | REsp 1.459.515 | 2016 | Inclusão indevida |
| STJ | REsp 1.550.700 | 2017 | Inversão ônus |
| STJ | REsp 1.731.000 | 2018 | SAC |
| STJ | REsp 1.782.190 | 2019 | Cláusula penal |

### Direito Trabalhista

| Tribunal | Número | Ano | Key Point |
|----------|--------|-----|-----------|
| TST | RR 1.002.432 | 2017 | Ultratividade |
| TST | RR 200.800 | 2018 | Norma coletiva |
| TST | RR 1.014.300 | 2019 | Teletrabalho |
| TST | RR 1.089.300 | 2020 | Assédio moral |

### Direito Tributário

| Tribunal | Número | Ano | Key Point |
|----------|--------|-----|-----------|
| STF | RE 566.007 | 2017 | ICMS Substituição |
| STF | RE 593.068 | 2017 | ICMS Exportação |
| STJ | REsp 1.781.000 | 2018 | ICMS Substituição |
| STJ | REsp 1.994.000 | 2019 | IRPJ/Cofins |

---

## JURISPRUDÊNCIA INTERNACIONAL

### Corte IDH

| Caso | Ano | Tema |
|------|-----|------|
| Velez Rodriguez | 2016 | Due process |
| Brewer-Carías | 2014 | Estado de exceção |
| Favela Nova Brasília | 2017 | Desaparecimentos |
| Gomes Lund | 2010 | Guerrilha do Araguaia |

### STF - Competência Internacional

| Número | Tema |
|--------|------|
| EXT 1.085 | Extradição |
| EXT 1.121 | Entrega |
| ARE 1.086.960 | Tratado |

---

## DOUTRINA QUALIS A1

### Revistas Classificadas

| Periódico | Qualis | Área |
|-----------|--------|------|
| Revista de Processo (RPro) | A1 | Direito |
| Arquivo de Direito Processual | A1 | Direito |
| Revista dos Tribunais | A2 | Direito |
| Cadernos de Direito | B1 | Direito |
| Jus Navigandi | B1 | Direito |
| Consultor Jurídico | B2 | Direito |

### Autores de Referência

| Área | Autores |
|------|---------|
| Civil | Caio Mário, Stolze, Dinamarco, Rosenvald |
| Constitucional | Barroso, Mendes, Silva, Medien |
| Penal | Bitencourt, Capez, Greco |
| Trabalhista | CLS, Martins, Delgado |
| Tributário | BALEEIRO, DERZI, Carvalhosa |
