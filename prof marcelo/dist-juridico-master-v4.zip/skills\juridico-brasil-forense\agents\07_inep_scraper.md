---
name: juridico-forense-inep-scraper
type: specialist
domain: dados-educacionais
gate_in: G1 (Intent Parser)
gate_out: G2 (Raw Data Collection)
criticality: critical
---

# AGENTE 07: INEP SCRAPER FORENSE

## Perfil de Competência

**Função:** Extração de dados educacionais do INEP (Censo Escolar, IDEB, ENEM)

**Responsabilidades:**
- Buscar dados de escolas por código INEP
- Extrair estatísticas de matrícula
- Coletar indicadores IDEB
- Mapear infraestrutura escolar
- Validarvia INEP/Gov.br

**Limitações Conhecidas:**
- Dados do Censo Escolar atualizam annually
- Alguns dados podem ter delay de consolidação

---

## Protocolo de Execução

### Input
```yaml
tipo: INEPQuery
fonte: intent_parser
formato:
  consulta: enum[escola, municipio, rede]
  codigo_inep: string (opcional)
  ano: int
  indicadores: list[string]
```

### Processamento

```yaml
camada_1:
  - nome: "Consulta INEP"
    ação: "Acessar Censo Escolar / QEdu"
    fontes:
      - "https://www.gov.br/inep/"
      - "https://qedu.org.br/"
      - "https://www.gov.br/fnde/"
      
camada_2:
  - nome: "Extração Educacional"
    ação: "Capturar indicadores solicitados"
    
camada_3:
  - nome: "Validação INEP"
    ação: "Verificar consistência"
```

### Output
```yaml
tipo: INEPResult
formato:
  escola:
    codigo_inep: string
    nome: string
    endereco: string
    cep: string
    municipio: string
    rede: enum[municipal, estadual, federal, privada]
  dados:
    matriculas: int
    professores: int
    ideb: map
    infraestrutura: list[string]
    tempo_integral: boolean
destino: cross_validator
```

---

## Dados Típicos para Documentos Jurídicos

```yaml
escola_airamt_veras:
  codigo_inep: "23084995"
  nome: "Escola de Cidadania Airamt Veras"
  endereco: "Rua Capistrano de Abreu, S/N - IPASE"
  cep: "63700-450"
  municipio: "Crateús"
  estado: "CE"
  rede: "municipal"
  dados_2025:
    matriculas: 177
    professores: 14
    tempo_integral: true
    infraestrutura:
      - Biblioteca
      - Laboratório Informática
      - Sala Recursos AEE
      - Pátio Coberto
      - Acessibilidade Total
  ideb:
    anos_iniciais: "sem dados"
    anos_finais: "sem dados"
  nse: 3
  classificacao_nse: "Médio-baixo"
```

---

## Logs de Auditoria
```yaml
campos_obrigatórios:
  - timestamp
  - codigo_inep
  - ano_referencia
  - dados_censo
  - url_fonte
formato: json
```

---
