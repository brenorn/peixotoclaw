# AGENTE N06: STF SCRAPER
## Coleta de Jurisprudência - Supremo Tribunal Federal

**ID:** N06
**Sistema:** juridico-brasil-nexus
**Camada:** Collection (Fase 1)
**Gate:** G1
**Função:** Coleta jurisprudência do STF (portal.stf.jus.br)

---

## PORTAL STF

### Informações
| Campo | Valor |
|-------|-------|
| URL | https://portal.stf.jus.br/ |
| Portal | portal.stf.jus.br |
| Giros | giross.stf.jus.br |

### Endpoints

```
# Jurisprudência
/servicos/jurisprudencia/
/servicos/acordaos/

# Repercussão Geral
/jurisprudencia/repercussao/

# Informativos
/servicos/informativos/
```

---

## QUERIES DE EXEMPLO

```
# Repercussão Geral
site:portal.stf.jus.br "repercussão geral" "recurso extraordinário"

# ADI
site:portal.stf.jus.br "ação direta de inconstitucionalidade" "ADI"

# Educação como direito social
site:portal.stf.jus.br "direito social" "educação" "art. 6º"

# Doação de bens públicos
site:portal.stf.jus.br "doação" "bens públicos" "interesse social"
```

---

## TIPOS DE JULGAMENTOS

| Tipo | Descrição |
|------|-----------|
| RE | Recurso Extraordinário |
| ADI | Ação Direta de Inconstitucionalidade |
| ADC | Ação Declaratória de Constitucionalidade |
| ADO | Ação Direta de Inconstitucionalidade por Omissão |
| MS | Mandado de Segurança |
| HC | Habeas Corpus |
| REXT | Recurso Extraordinário com Repercussão |

---

## OUTPUT

```json
{
  "fonte": "STF",
  "url": "https://portal.stf.jus.br/...",
  "tipo": "jurisprudencia",
  "data_coleta": "YYYY-MM-DD",
  "dados": {
    "numero": "RE 1.000.000",
    "relator": "Min. Nome",
    "data_julgamento": "YYYY-MM-DD",
    "ementa": "texto da ementa",
    "decisao": "inteiro teor",
    "tema": "número do tema",
    "repercussao_geral": true,
    "procedencia": "PARCIAL|TOTAL|IMPROCEDENTE"
  },
  "status": "VINCULANTE|NÃO_VINCULANTE"
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N06 - STF Scraper
**STATUS:** OPERACIONAL ✅
