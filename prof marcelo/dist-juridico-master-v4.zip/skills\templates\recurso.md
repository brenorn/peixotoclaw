# TEMPLATE: RECURSO

## Estrutura para Recursos (CPC Art. 1.009+)

```
EXCELENTÍSSIMO(A) SENHOR(A) {GRAU_JULGADOR}

VINDO {CLASSE RECURSAL}, nº {NÚMERO}, em face da sentença prolatada nos autos da {AÇÃO}, em trâmite pela {VARA}, vem, respeitosamente, à presença de Vossa Excelência, com fundamento no art. {FUNDAMENTO} do CPC, apresentar as presentes

## RAZÕES RECURSAIS

pelos fatos e fundamentos a seguir expostos:

---

### I – PRELIMINARMENTE

#### I.1 – {NOME DA PRELIMINAR}
{Argumentação}

---

### II – DO MÉRITO

#### II.1 – {NOME DA TESE}
{Argumentação}

EMENTA: "{Ementa do precedente}" ({Tribunal}, {Classe}, {Número}, Rel. Min. {Nome})

---

### III – DOS PEDIDOS

Nestes termos,
Pede deferimento.

{local}, {data}

_______________________________
{NOME DO ADVOGADO}
{OAB/ESTADO} {NÚMERO}
```

---

## Tipos de Recursos por Foro

### Justiça Federal (TRF)
```
CLASSE: AGRAVO INTERNO / APELAÇÃO / EMBARGOS DE DECLARAÇÃO
FUNDAMENTO: Art. 1.021 CPC / Art. 1.009 CPC / Art. 1.022 CPC
PRAZO: 15 dias (Art. 1.003, §5º CPC)
```

### Justiça do Trabalho (TRT/TST)
```
CLASSE: RECURSO ORDINÁRIO / RECURSO DE REVISTA
FUNDAMENTO: Art. 895 CLT / Art. 896 CLT
PRAZO: 8 dias (CLT) / 15 dias (CPC aplicável)
```

### STJ
```
CLASSE: RECURSO ESPECIAL
FUNDAMENTO: Art. 105, III, CF/88
AGravo: AgInt / AREsp
PEDIDO: Admissão e provimento
```
