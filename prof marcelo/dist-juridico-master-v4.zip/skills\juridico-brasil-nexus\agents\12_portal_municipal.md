# AGENTE N12: PORTAL MUNICIPAL SCRAPER
## Coleta de Dados de Portais Municipais

**ID:** N12
**Sistema:** juridico-brasil-nexus
**Camada:** Collection (Fase 1)
**Gate:** G1
**Função:** Coleta dados de portais municipais (transparência, educação, saúde)

---

## PORTAL CRATEÚS/CE

### Informações
| Campo | Valor |
|-------|-------|
| URL | https://www.crateus.ce.gov.br/ |
| CNPJ | 07.982.036/0001-67 |
| Prefecture | Airamt Veras (gestão anterior) |
| Prefecture Atual | Janaina Carla Farias |

---

## FONTES MUNICIPAIS

### Dados Governamentais
```yaml
prefeitura:
  - nome_prefeito
  - vice_prefeito
  - secretarios
  - estrutura_organizacional
  - contatos
```

### Educação Municipal
```yaml
educacao:
  - escolas_municipais
  - matriculas_educacao_infantil
  - matriculas_ensino_fundamental
  - fundeb
  - plano_educacao
```

### Transparência
```yaml
transparencia:
  - licitacoes
  - contratos
  - receitas
  - despesas
  - patrimonio
  - diario_oficial
```

---

## QUERIES DE EXEMPLO

```
# Crateús Dados
site:crateus.ce.gov.br "prefeitura" "Crateús"
site:crateus.ce.gov.br "educação" "escolas"

# Transparência
site:crateus.ce.gov.br "transparência" "licitações"
site:crateus.ce.gov.br "contrato" "educação"

# Diário Oficial Municipal
site:crateus.ce.gov.br "diário oficial" "publicação"
```

---

## OUTPUT

```json
{
  "fonte": "Portal Municipal Crateús",
  "url": "https://www.crateus.ce.gov.br/...",
  "tipo": "dados_municipais",
  "data_coleta": "YYYY-MM-DD",
  "dados": {
    "municipio": {
      "nome": "Crateús",
      "uf": "CE",
      "codigo_ibge": 2304103,
      "populacao": 76390,
      "area_km2": 2981.461
    },
    "prefeito": {
      "nome": "Janaina Carla Farias",
      "vice": "A definir",
      "mandato": "2025-2028"
    },
    "secretarias": {
      "educacao": "Secretaria de Educação",
      "saude": "Secretaria de Saúde",
      "administracao": "Secretaria de Administração"
    }
  },
  "metadados": {
    "completude": 88,
    "precisao": 95,
    "status": "PARCIALMENTE_DISPONIVEL"
  }
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N12 - Portal Municipal Scraper
**STATUS:** OPERACIONAL ✅
