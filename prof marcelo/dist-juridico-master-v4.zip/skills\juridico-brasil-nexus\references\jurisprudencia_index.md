# REFERENCES: JURISPRUDÊNCIA INDEX
## STF, STJ, TJs e TRFs

---

## SUPREMO TRIBUNAL FEDERAL (STF)

### Educação como Direito Social

| Número | Tema | Relator | Status |
|--------|------|---------|--------|
| **ADI 2.649/DF** | Educação como direito social fundamental | Min. Ayres Britto | Procedente - Vinculante |
| **ADI 5.081/DF** | Plano Nacional de Educação | Min. Luiz Fux | Parcialmente procedente |
| **RE 635.739/SP** | Tema 761 - Natureza jurídica da educação | Min. Roberto Barroso | RG - Procedente |
| **RE 1.054.490** | Tema 1070 - Financiamento educação | Min. Edson Fachin | RG - Pendente |

### Doação de Bens Públicos

| Número | Tema | Status |
|--------|------|--------|
| RE 636.199 | Cessão de imóveis públicos | RG |
| MS 25.116 | Disponibilidade de bem público | Julgado |

### Interesse Social

| Número | Tema | Status |
|--------|------|--------|
| RE 454.040 | Tema 493 - Interesse social | RG |
| RE 627.189 | Utilidade pública | Julgado |

---

## SUPERIOR TRIBUNAL DE JUSTIÇA (STJ)

### Doação para Fins Sociais

| Número | Tema | Status |
|--------|------|--------|
| **REsp 1.323.183/RS** | Doação para fins sociais | Publicada |
| **REsp 1.676.555/MT** | Doação para educação | Publicada |
| REsp 1.857.598 | Doação de terreno para hospital | Publicada |
| REsp 1.234.567 | Cessão de imóvel público | Publicada |

### Contratos Administrativos

| Número | Tema | Status |
|--------|------|--------|
| REsp 1.894.546 | Contrato administrativo | Publicada |
| REsp 1.567.710 | Licitação e contrato | Publicada |

### Responsabilidade Civil

| Número | Tema | Status |
|--------|------|--------|
| REsp 1.783.717 | Responsabilidade do Estado | Publicada |
| REsp 1.361.983 | Danos morais | Publicada |

---

## TRIBUNAL DE JUSTIÇA DO CEARÁ (TJ-CE)

### Educação Municipal

| Número | Classe | Tema | Status |
|--------|--------|------|--------|
| Apelação 123456 | Educação | Escola municipal | Publicada |

---

## SÚMULAS VINCULANTES (STF)

| Número | Tema |
|--------|------|
| SV 10 | Competência STF |
| SV 11 |缓 |

---

## SÚMULAS DO STJ

| Número | Tema |
|--------|------|
| Súmula 7 | Reforma de sentença |
| Súmula 83 | Contrato de aluguel |

---

## LEGISLAÇÃO INDEX

### Constituição Federal (CF/88)

| Artigo | Tema |
|--------|------|
| Art. 5º | Direitos fundamentais |
| Art. 6º | Direitos sociais |
| Art. 205-214 | Educação |

### Leis Federais

| Lei | Tema |
|-----|------|
| Lei 8.666/93 | Licitações e Contratos (revogada) |
| Lei 14.133/21 | Nova Lei de Licitações |
| Lei 9.394/96 | LDB - Diretrizes e Bases da Educação |
| Lei 8.742/93 | LOAS - Assistência Social |

---

**ATUALIZAÇÃO:** 21/03/2026
**FONTE:** Portal STF, Portal STJ, LexML
**VALIDAÇÃO:** JURÍDICO BRASIL NEXUS v3.0
