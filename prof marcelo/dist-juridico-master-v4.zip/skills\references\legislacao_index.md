# ÍNDICE AMPLIADO DE LEGISLAÇÃO BRASILEIRA v2.0

## DIREITO CONSTITUCIONAL

### Constituição e Emendas
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| CF/88 | Constituição Federal | 05/10/1988 | Vigente |
| EC 1/69 | Emenda 1/1969 | 01/10/1969 | Revogada |
| EC 26/2000 | ADPF das Quarentenas | 14/02/2000 | Vigente |
| EC 41/2003 | Reforma da Previdência | 31/12/2003 | Vigente |
| EC 45/2004 | Reforma do Judiciário | 08/12/2004 | Vigente |
| EC 75/2013 | Marco Civil da Internet | 23/04/2013 | Vigente |
| EC 85/2015 | Atualização Gestão | 11/02/2015 | Vigente |
| EC 103/2019 | Reforma da Previdência | 13/11/2019 | Vigente |
| EC 109/2021 | Ampla Defesa Digital | 01/12/2021 | Vigente |

### Leis Constitucionais Esparsas
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei 9.882/99 | ADPF | 03/12/1999 | Vigente |
| Lei 12.412/2011 | RFSP | 14/06/2011 | Vigente |

---

## DIREITO CIVIL

### Código Civil e Complementares
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei 10.406/2002 | Código Civil | 10/01/2002 | Vigente |
| Lei 3.071/1916 | Código Civil 1916 | 01/01/1916 | Revogada |
| Lei 6.766/79 | Loteamento | 19/12/1979 | Vigente |
| Lei 4.504/64 | Estatuto Terra | 30/11/1964 | Vigente |
| Lei 8.971/94 | Convivência | 29/12/1994 | Revogada |
| Lei 9.278/96 | União Estável | 10/05/1996 | Vigente |

### Obrigações e Contratos
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei 4.950-A/66 | Honorários Advocatícios | 22/06/1966 | Vigente |
| Lei 6.015/73 | Registro Públicos | 31/12/1973 | Vigente |
| Lei 8.245/91 | Locações | 18/10/1991 | Vigente |
| Lei 9.307/96 | Arbitragem | 23/09/1996 | Vigente |
| Lei 13.874/2019 | EASE - Liberdade Econômica | 20/09/2019 | Vigente |

---

## DIREITO PROCESSUAL CIVIL

### CPC e Leis Complementares
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei 13.105/2015 | Código de Processo Civil | 16/03/2015 | Vigente |
| Lei 5.869/73 | CPC 1973 | 11/01/1973 | Revogada |
| Lei 12.016/2009 | Mandado de Segurança | 07/08/2009 | Vigente |
| Lei 12.378/2010 | OAB | 31/12/2010 | Vigente |
| Lei 13.655/2018 | LINDB Nova | 25/04/2018 | Vigente |
| Lei 14.195/2021 | Agências Reguladoras | 27/08/2021 | Vigente |

---

## DIREITO TRABALHISTA

### CLT e Reformas
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Decreto-Lei 5.452/43 | CLT | 01/05/1943 | Vigente |
| Lei 9.601/98 | Contrato Temporário | 21/01/1998 | Vigente |
| Lei 12.023/2009 | Trabalho Rural | 25/08/2009 | Vigente |
| Lei 13.429/2017 | Terceirização | 31/03/2017 | Vigente |
| Lei 13.467/2017 | Reforma Trabalhista | 11/07/2017 | Vigente |
| Lei 14.020/2020 | Teletrabalho | 23/07/2020 | Vigente |
| Lei 14.457/2022 | home office | 21/03/2022 | Vigente |

### Fundiárias e Associativas
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei 5.764/71 | Cooperativas | 16/12/1971 | Vigente |
| Lei 10.101/2000 | Participação Lucros | 19/12/2000 | Vigente |
| Lei 13.999/2020 | MEI | 01/06/2020 | Vigente |

---

## DIREITO PENAL

### Código Penal e Legislação Complementar
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Decreto-Lei 2.848/40 | Código Penal | 07/12/1940 | Vigente |
| Lei 7.210/84 | LEP - Execução Penal | 11/07/1984 | Vigente |
| Lei 8.072/90 | Crimes Hediondos | 25/07/1990 | Vigente |
| Lei 8.078/90 | Crimes Consumista | 11/09/1990 | Vigente |
| Lei 8.137/90 | Crimes Ordem Tributária | 27/12/1990 | Vigente |
| Lei 9.034/95 | Crimes Organizados | 03/05/1995 | Vigente |
| Lei 9.455/97 | Crimes Tortura | 07/04/1997 | Vigente |
| Lei 9.605/98 | Crimes Ambientais | 12/02/1998 | Vigente |
| Lei 10.741/2003 | Estatuto Idoso | 01/10/2003 | Vigente |
| Lei 11.343/06 | Lei Antidrogas | 23/08/2006 | Vigente |
| Lei 12.037/09 | CPP | 01/10/2009 | Vigente |
| Lei 12.850/2013 | Crime Organizado | 02/08/2013 | Vigente |
| Lei 13.964/2019 | Pacote Anticrime | 24/12/2019 | Vigente |

---

## DIREITO TRIBUTÁRIO

### CTN e Impostos
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei 5.172/66 | CTN | 25/10/1966 | Vigente |
| Lei 3.470/58 | IRPF | 28/11/1958 | Vigente |
| Lei 4.502/64 | IPI | 30/11/1964 | Vigente |
| Lei 5.172/66 | IOF | 25/10/1966 | Vigente |
| Lei 9.393/96 | ITR | 19/12/1996 | Vigente |
| Lei 7.799/89 | PIS/COFINS | 19/07/1989 | Vigente |
| Lei 8.212/91 | INSS | 24/07/1991 | Vigente |
| Lei 8.213/91 | Benefícios | 24/07/1991 | Vigente |

### ICMS e ISS
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei Complementar 87/96 | ICMS | 13/09/1996 | Vigente |
| Lei Complementar 116/03 | ISS | 31/08/2003 | Vigente |

### Execução Fiscal
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei 6.830/80 | LEF - Execução Fiscal | 22/09/1980 | Vigente |
| Lei 9.289/96 | Custas | 04/07/1996 | Vigente |

---

## DIREITO EMPRESARIAL

### Sociedades e Títulos
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei 6.404/76 | Lei das S.A. | 15/12/1976 | Vigente |
| Lei 5.764/71 | Cooperativas | 16/12/1971 | Vigente |
| Decreto-Lei 2.044/08 | Títulos de Crédito | 31/12/1908 | Vigente |
| Lei 9.279/96 | Propriedade Industrial | 14/05/1996 | Vigente |
| Lei 9.610/98 | Direitos Autorais | 19/02/1998 | Vigente |

### Falência e Recuperação
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei 11.101/2005 | Falência/Recuperação | 09/02/2005 | Vigente |
| Lei 14.112/2020 | Nova Lei Falência | 24/12/2020 | Vigente |
| Lei 14.195/2021 | Empresarial | 27/08/2021 | Vigente |

---

## DIREITO ADMINISTRATIVO

### Licitações e Contratos
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei 14.133/2021 | Nova Lei Licitações | 01/04/2021 | Vigente |
| Lei 11.079/04 | PPPs | 30/12/2004 | Vigente |
| Lei 8.666/93 | Licitações 93 | 21/06/1993 | Revogada |

### Servidores
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei 8.112/90 | Servidores Union | 11/12/1990 | Vigente |
| Lei 9.624/98 | Regulamento | 02/04/1998 | Vigente |

---

## DIREITO DO CONSUMIDOR

| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei 8.078/90 | CDC | 11/09/1990 | Vigente |
| Lei 8.137/90 | Crimes Consumista | 27/12/1990 | Vigente |
| Lei 9.921/2000 | SAC | 29/03/2000 | Vigente |
| Lei 12.965/2014 | Marco Civil Internet | 23/04/2014 | Vigente |

---

## LEGISLAÇÃO COMPLEMENTAR

### Anticorrupção e Compliance
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei 12.846/2013 | Anticorrupção | 01/08/2013 | Vigente |
| Lei 13.303/2016 | Empresas Estatais | 30/06/2016 | Vigente |

### Proteção de Dados
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei 13.709/2018 | LGPD | 14/08/2018 | Vigente |
| Lei 13.853/2019 | LGPD Alterações | 08/07/2019 | Vigente |

### Ambiental
| Código | Nome | Data | Vigência |
|--------|------|------|----------|
| Lei 6.938/81 | PNMA | 31/08/1981 | Vigente |
| Lei 9.605/98 | Crimes Ambientais | 12/02/1998 | Vigente |
| Lei 12.651/2012 | Código Florestal | 25/05/2012 | Vigente |

---

## PRINCÍPIOS FUNDAMENTAIS

### Constitucionais
| Princípio | Artigo CF |
|-----------|-----------|
| Dignidade da pessoa humana | Art. 1º, III |
| Estado Democrático de Direito | Art. 1º |
| Separação dos poderes | Art. 2º |
| Legalidade | Art. 5º, II |
| Ampla defesa | Art. 5º, LV |
| Due process | Art. 5º, LIV |
| Inafastabilidade | Art. 5º, XXXV |
| Motivação | Art. 93, IX |
| Proporcionalidade | Implicito |

### Processuais
| Princípio | Artigo CPC |
|-----------|-----------|
| Cooperação | Art. 6º |
| Boa-fé objetiva | Art. 5º |
| Lealdade processual | Art. 5º |
| Concentração | Art. 12 |
| Fungibilidade | Art. 1.003, §3º |
| Juiz natural | Art. 4º |

### Trabalhistas
| Princípio | Fundamento |
|-----------|-----------|
| Proteção | CLT Art. 8º |
| Primazia da realidade | OJ |
| Continuidade | OJ |
| Normas mais benéficas | Art. 9º CLT |
