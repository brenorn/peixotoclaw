---
name: 05_stf_stj_scraper
type: specialist
domain: legal
gate_in: G4
gate_out: G5
criticality: critical
---

# AGENTE 05: STF/STJ SCRAPER

## Perfil de Competência

**Função:** Executa scraping dos portais STF e STJ para jurisprudência, Informativos, Repercussão Geral e Recursos.

**Responsabilidades:**
- Buscar jurisprudência STF (Pleno, Turmas)
- Buscar jurisprudência STJ (Seções, Turmas)
- Extrair Informativos (STF nº 1-XXXX, STJ)
- Capturar decisões com Repercussão Geral
- Identificar Temas de Repercussão Geral
- Parsear ADIs, ADCs, ADOs
- Extrair relações entre precedentes

**Limitações Conhecidas:**
- Portal pode estar em manutenção
- CAPTCHA em algumas consultas
- Rate limit por IP
- Dados recentes podem ter delay

---

## Protocolo de Execução

### Input
```yaml
tipo: QuerySpec
fonte: 03_tribunal_router
validações:
  - tribunal_in: [STF, STJ]
  - query_valida
```

### Processamento

**FASE 1: STF**

```yaml
endpoints:
  pesquisa_jurisprudencia:
    url: "https://portal.stf.jus.br/jurisprudencia/"
    metodo: POST
    body:
      pesquisa: "{query}"
      tipo_documento: "acordaos|decisoes_monocraticas|informativos"
      
  repercussao_geral:
    url: "https://portal.stf.jus.br/jurisprudencia/repercussao/"
    metodo: GET
    parametros:
      tema: "{numero_tema}"
      
  informativ:
    url: "https://portal.stf.jus.br/servicos/informativos/"
    metodo: GET
    
parse_fields:
  acordao:
    - numero_processo
    - numero_registro
    - data_julgamento
    - data_publicacao
    - relatoria
    - orgao
    - tipo_resultado
    - ementa
    - texto_completo_url
    - tese_julgamento
    - vinculos_tematicos
    
  decisao_monocratica:
    - numero_processo
    - relator
    - data_decisao
    - teor_decisao
    - recurso
```

**FASE 2: STJ**

```yaml
endpoints:
  pesquisa_jurisprudencia:
    url: "https://www.stj.jus.br/jurisprudencia/"
    metodo: POST
    body:
      pesquisa: "{query}"
      formulario_pesquisa: "pesquisa_por_palavra"
      
  pesquisa_unificada:
    url: "https://www.stj.jus.br/jurisprudencia/pesquisa/"
    parametros:
      texto: "{palavras}"
      classe: "{classe}"
      
parse_fields_stj:
  acordao:
    - numero_processo
    - numero_registro
    - data_julgamento
    - relatoria
    - orgao
    - secao
    - tipo_decisao
    - ementa
    - informativo
    - tags_tematicas
```

**FASE 3: Enriquecimento**
```yaml
enrichment:
  - identificar_tema_repercussao_geral
  - mapear_relacoes_citado_citante
  - adicionar_precedentes_citados
  - marcar_filhos_principais
```

### Output
```yaml
tipo: JurisprudenciaResults
formato: structured_json
destino: 03_tribunal_router
estrutura:
  fonte: "STF" | "STJ"
  total_results: number
  results:
    - tipo_documento: enum
      numero_processo: string
      classe: string
      relator: string
      orgao: string
      data_julgamento: date
      data_publicacao: date
      ementa: string
      tese: string
      vinculos:
        repercussao_geral: boolean
        tema_rg: number|null
        precedentes_citados: list[string]
       adc_referenciada: list[string]
      url: string
      score: float
  metadata:
    Tempo_execucao: number
    paginas_consultadas: number
    rate_limit_atingido: boolean
```

---

## Handoff Protocol

### Recebe de
```yaml
agente: 03_tribunal_router
valida_input:
  - tribunal_specificado
  - query_formatada
```

### Envia para
```yaml
agente: 03_tribunal_router (agregacao)
agente: 10_citation_engine (se citacoes necessarias)
```

---

## Mapping de Classes

### STF
```yaml
classes_stf:
  RE: "Recurso Extraordinário"
  AI: "Agravo de Instrumento"
  ACO: "Ação Cível Originária"
  ADI: "Ação Direta de Inconstitucionalidade"
  ADC: "Ação Declaratória de Constitucionalidade"
  ADO: "Ação Direta de Inconstitucionalidade por Omissão"
  HC: "Habeas Corpus"
  RHC: "Recurso em Habeas Corpus"
  CR: "Conflito de Competência"
  MS: "Mandado de Segurança"
  PET: "Petição"
  SE: "Segredo de Justiça"
```

### STJ
```yaml
classes_stj:
  REsp: "Recurso Especial"
  REsp: "Recurso Especial Repetitivo"
  AgInt: "Agravo Interno"
  RMS: "Recurso em Mandado de Segurança"
  HC: "Habeas Corpus"
  RHC: "Recurso em Habeas Corpus"
  AREsp: "Agravo em Recurso Especial"
  EDcl: "Embargos de Declaração"
  EDvA: "Embargos de Declaração em Agravo"
  CC: "Conflito de Competência"
  AI: "Agravo de Instrumento"
```

---

## Métricas
```yaml
latência_target: 20s
precisão_target: 93%
KPIs:
  stf_fetch_rate: 95%
  stj_fetch_rate: 95%
  parse_accuracy: 97%
  rg_capture_rate: 90%
```

---

*AGENTE 05 - STF/STJ SCRAPER v1.0*
