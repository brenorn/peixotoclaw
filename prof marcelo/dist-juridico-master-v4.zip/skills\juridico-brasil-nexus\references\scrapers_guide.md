# REFERENCES: SCRAPERS GUIDE
## Guia de Scrapers e APIs para Coleta de Dados

---

## 1. FONTES OFICIAIS - GOVERNAMENTAIS

### IBGE - Instituto Brasileiro de Geografia e Estatística

```yaml
ibge:
  url_base: "https://www.ibge.gov.br"
  endpoints:
    cidades: "https://cidades.ibge.gov.br"
    sidra: "https://sidra.ibge.gov.br"
    ftp: "ftp.ibge.gov.br"
    
  scrapers:
    - nome: "IBGE Cidades"
      url: "https://cidades.ibge.gov.br/brasil/{uf}/{municipio}/panorama"
      dados: ["população", "IDHM", "PIB", "área"]
      
    - nome: "SIDRA API"
      url: "https://apisidra.ibge.gov.br"
      dados: ["séries históricas", "censo"]
```

### INEP - Instituto Nacional de Estudos e Pesquisas Educacionais

```yaml
inep:
  url_base: "https://www.inep.gov.br"
  endpoints:
    ideb: "/inep/ideb"
    censo_escolar: "/censo-escolar"
    enem: "/enem"
    
  scrapers:
    - nome: "IDEB"
      url: "https://www.inep.gov.br/inep-ideb"
      dados: ["IDEB por escola", "IDEB por município"]
      
    - nome: "Censo Escolar"
      url: "https://www.inep.gov.br/censo-escolar"
      dados: ["matrículas", "docentes", "escolas"]
```

### CNJ - Conselho Nacional de Justiça

```yaml
cnj:
  url_base: "https://www.cnj.jus.br"
  endpoints:
    dados_abertos: "/dados-abertos"
    justica_aberta: "https://justicaaberta.cnj.jus.br"
    
  scrapers:
    - nome: "Dados Abertos CNJ"
      url: "https://www.cnj.jus.br/dados-abertos"
      dados: ["processos", "varas", "tribunais"]
```

---

## 2. FONTES JUDICIÁRIAS

### STF - Supremo Tribunal Federal

```yaml
stf:
  url_base: "https://portal.stf.jus.br"
  endpoints:
    jurisprudencia: "/servicos/jurisprudencia/"
    acordaos: "/servicos/acordaos/"
    repertorio: "/servicos/informativos/"
    
  scraping:
    metodo: "web_scraping"
    rate_limit: "10 req/min"
    autenticacao: "não requer"
```

### STJ - Superior Tribunal de Justiça

```yaml
stj:
  url_base: "https://www.stj.jus.br"
  endpoints:
    jurisprudencia: "/jurisprudencia/"
    pesquisa: "/pesquisa.html"
    
  scraping:
    metodo: "web_scraping"
    rate_limit: "10 req/min"
```

---

## 3. LEXML - Legislação

```yaml
lexml:
  url_base: "https://www.lexml.gov.br"
  endpoints:
    busca: "/busca/resultado"
    legislacao: "/legislacao"
    
  scraping:
    metodo: "api_rest"
    autenticacao: "opcional (chave API)"
```

---

## 4. FONTES ESTADUAIS - CEARÁ

### IPECE - Instituto de Pesquisa e Estratégia Econômica do Ceará

```yaml
ipece:
  url_base: "https://ipece.ce.gov.br"
  endpoints:
    indicadores: "/indicadores/"
    publicacoes: "/publicacoes/"
```

### TJ-CE - Tribunal de Justiça do Ceará

```yaml
tjce:
  url_base: "https://www.tjce.jus.br"
  endpoints:
    jurisprudencia: "/jurisprudencia/"
    consulta: "/consulta/"
```

---

## 5. SCRAPING CONFIGURAÇÃO

### Configuração Padrão

```yaml
scraper_config:
  user_agent: "MASWOS-NEXUS-Bot/1.0 (juridico-research)"
  timeout: 30
  retries: 3
  delay: 2  # segundos entre requests
  
headers:
  Accept: "text/html,application/xhtml+xml,application/json"
  Accept-Language: "pt-BR,pt;q=0.9,en;q=0.8"
  
rate_limits:
  gov_br: "10 req/min"
  stf_stj: "10 req/min"
  ibge: "60 req/min"
```

---

## 6. CRITÉRIOS DE VALIDAÇÃO

### Autenticidade da Fonte

```
□ Domínio oficial (.gov.br, .jus.br)?
□ SSL/TLS habilitado (https)?
□ Página com dados institucionais?
□ Última atualização visível?
```

### Qualidade do Dado

```
□ Dado quantificável?
□ Fonte citada?
□ Data de referência presente?
□ Metodologia descrita?
```

---

**ATUALIZAÇÃO:** 21/03/2026
**VALIDAÇÃO:** JURÍDICO BRASIL NEXUS v3.0
