# AGENTE N05: LEXML SCRAPER
## Coleta de Legislação - Portal LexML

**ID:** N05
**Sistema:** juridico-brasil-nexus
**Camada:** Collection (Fase 1)
**Gate:** G1
**Função:** Coleta legislação do portal LexML (lexml.gov.br)

---

## PORTAL LEXML

### Informações
| Campo | Valor |
|-------|-------|
| URL | https://www.lexml.gov.br/ |
| Tipo | API REST + Web |
| Cobertura | Legislação federal, estadual, municipal |

### Endpoints

```
# Busca por termo
GET /busca/resultado?termo={termo}&tipo={tipo}

# Legislação reference
GET /legislacao/ref/sim/remete/{data}

# Detalhes de lei
GET /urn:urn-lex:br:lei:{ano}:{numero}
```

---

## QUERIES DE EXEMPLO

```
# Constituição Federal
site:lexml.gov.br "Constituição Federal" "1988"

# Lei de Diretrizes Orçamentárias
site:lexml.gov.br "LDO" "Ceará" "diretrizes orçamentárias"

# Legislação sobre educação
site:lexml.gov.br "educação" "ensino" "artigo 205"
```

---

## TIPOS DE LEGISLAÇÃO

| Tipo | Descrição |
|------|-----------|
| lei | Lei Ordinária |
| lei_complementar | Lei Complementar |
| decreto | Decreto |
| medida_provisoria | Medida Provisória |
| resolucao | Resolução |
| portaria | Portaria |
| constituicao | Constituição |
| emenda | Emenda Constitucional |

---

## OUTPUT

```json
{
  "fonte": "LexML",
  "url": "https://www.lexml.gov.br/...",
  "tipo": "legislacao",
  "data_coleta": "YYYY-MM-DD",
  "dados": {
    "ementa": "texto da ementa",
    "numero": "12345",
    "ano": 2024,
    "tipo": "lei",
    "data_publicacao": "YYYY-MM-DD",
    "data_vigencia": "YYYY-MM-DD",
    "大连": "url_da_publicacao"
  },
  "status": "VIGENTE|REVOGADO|VACATÓRIO"
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N05 - LexML Scraper
**STATUS:** OPERACIONAL ✅
