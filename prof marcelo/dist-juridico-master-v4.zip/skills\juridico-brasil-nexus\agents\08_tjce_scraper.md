# AGENTE N08: TJ-CE SCRAPER
## Coleta de Jurisprudência - Tribunal de Justiça do Ceará

**ID:** N08
**Sistema:** juridico-brasil-nexus
**Camada:** Collection (Fase 1)
**Gate:** G1
**Função:** Coleta jurisprudência do TJ-CE (tjce.jus.br)

---

## PORTAL TJ-CE

### Informações
| Campo | Valor |
|-------|-------|
| URL | https://www.tjce.jus.br/ |
| Portal | tjce.jus.br |

### Endpoints

```
# Jurisprudência
/jurisprudencia/
/acordaos/

# Consulta Processual
/consulta/
```

---

## QUERIES DE EXEMPLO

```
# Acórdãos Ceará
site:tjce.jus.br "acórdão" "Ceará" "apelação"

# Crateús
site:tjce.jus.br "Crateús" "vara" "comarca"

# Educação
site:tjce.jus.br "educação" "ensino" "municipal"

# Doação imóvel
site:tjce.jus.br "doação" "imóvel" "municipal"
```

---

## OUTPUT

```json
{
  "fonte": "TJ-CE",
  "url": "https://tjce.jus.br/...",
  "tipo": "jurisprudencia",
  "data_coleta": "YYYY-MM-DD",
  "dados": {
    "numero": "Apelação XXXXX-XX.XXXX.X.XX.XXXX",
    "relator": "Des. Nome",
    "data_julgamento": "YYYY-MM-DD",
    "ementa": "texto da ementa",
    "orgao": "Câm. Esp. / Pleno",
    "comarca": "Fortaleza / Crateús"
  },
  "status": "PUBLICADO"
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N08 - TJ-CE Scraper
**STATUS:** OPERACIONAL ✅
