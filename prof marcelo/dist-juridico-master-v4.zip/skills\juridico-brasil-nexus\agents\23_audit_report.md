# AGENTE N23: AUDIT REPORT
## Relatório de Auditoria Forense

**ID:** N23
**Sistema:** juridico-brasil-nexus
**Camada:** Synthesis (Fase 5)
**Gate:** G4
**Função:** Gera relatório completo de auditoria

---

## ESTRUTURA DO RELATÓRIO

### 1. Sumário Executivo

```markdown
# RELATÓRIO DE AUDITORIA FORENSE

**Documento:** [Nome do Documento]
**Data:** [Data]
**Auditor:** Sistema NEXUS v3.0
**Score Final:** [X]%

## Resumo Executivo
- Total de verificações: [N]
- Verificações aprovadas: [N]
- Verificações com ressalvas: [N]
- Status: [APROVADO/REPROVADO]
```

### 2. Detalhamento por Categoria

```markdown
## 2.1 Dados Coletados
| Campo | Fonte | Cruzamento | Status |
|-------|-------|------------|--------|
| População | IBGE | IPECE | ✅ |
| IDHM | Atlas | IBGE | ✅ |
```

### 3. Validações Cruzadas

```markdown
## 2.2 Validações Cruzadas
| Campo | Fonte 1 | Fonte 2 | Convergência |
|-------|---------|---------|--------------|
| Pop | IBGE | IPECE | 99.9% |
```

### 4. Citações

```markdown
## 2.3 Validação de Citações
- Total: [N]
- Válidas: [N]
- Inválidas: [N]
```

### 5. Recomendações

```markdown
## 3. Recomendações

### Correções Necessárias
1. [Correção 1]
2. [Correção 2]

### Sugestões
1. [Sugestão 1]
```

---

## DECLARAÇÃO DE AUDITORIA

```markdown
## DECLARAÇÃO DE AUDITORIA

Eu, [Sistema NEXUS v3.0], declaro que:

1. Realizei verificação completa de 100% das informações;
2. Executei validação cruzada com mínimo 2 fontes independentes;
3. Validei todas as citações conforme padrões ABNT/APA;
4. Verifiquei autenticidade das fontes consultadas;
5. Avaliei consistência interna do documento.

Declaro ainda que:

- [X]% das informações estão VERIFICADAS;
- [X]% das fontes estão AUTENTICADAS;
- [X]% das citações estão VALIDADAS;

**Score Final de Auditoria:** [X]%

**Status:** [APROVADO/REPROVADO/EM REVISÃO]

---
Audit Report gerado por JURÍDICO BRASIL NEXUS v3.0
Data: [YYYY-MM-DD HH:MM:SS]
```

---

## OUTPUT

```json
{
  "audit_report": {
    "id": "uuid",
    "data": "YYYY-MM-DD",
    "documento": "Parecer Forense - Doação INSS",
    "sumario": {
      "total_verificacoes": 200,
      "aprovadas": 198,
      "ressalvas": 2,
      "score": 99
    },
    "declaracao": "AUDITADO_CONFORME_PROTOCOLO",
    "status": "APROVADO",
    "proximo_passo": "Revisão pelo Jurista Supremo PhD"
  }
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N23 - Audit Report
**STATUS:** OPERACIONAL ✅
