# 🏛️ JURÍDICO BRASIL FORENSE v2.0
## Sistema de Pesquisa Forense com Coleta de Dados Reais

---

> **SISTEMA:** Pipeline Forense de Dados Jurídicos  
> **VERSÃO:** 2.0.0  
> **DATA:** 20/03/2026  
> **STATUS:** OPERACIONAL ✅

---

## 📋 RESUMO EXECUTIVO

O **JURÍDICO BRASIL FORENSE** é um sistema de pesquisa jurídica que utiliza **arquitetura Transformer** com **12+ agentes granulares** para coletar, validar, cruzar, auditar e sintetizar dados de **fontes oficiais brasileiras** em tempo real.

### Diferenciais

| Característica | Descrição |
|---------------|-----------|
| **Dados Reais** | Coleta de fontes oficiais (IBGE, INEP, STF, STJ, etc) |
| **Validação Cruzada** | Cada dado verificado por mínimo 2 fontes independentes |
| **Auditoria Completa** | 100% das informações verificadas e rastreadas |
| **Score de Confiança** | Métricas de 0-100% para cada dado coletado |
| **Pipeline Forense** | 6 fases: Coleta → Validação → Cruzamento → Análise → Síntese → Auditoria |

---

## 🎯 O QUE ESTE SISTEMA PODE FAZER

### 1. Buscar Dados de Municípios
```
- População (Censo 2022)
- IDHM
- PIB per capita
- Estrutura administrativa
- Secretarias e órgãos
- CNPJ e dados de transparência
```

### 2. Buscar Dados de Escolas
```
- Código INEP
- Matrículas (Censo 2025)
- IDEB
- Infraestrutura
- Professores
- Telefone e endereço
```

### 3. Buscar Jurisprudência
```
- STF (ADI, RE, ADC, etc)
- STJ (REsp, RMS, AgInt)
- TJ-CE (Acórdãos)
- Repercussão Geral
```

### 4. Buscar Legislação
```
- Leis Federais (LexML)
- Leis Estaduais
- Leis Municipais
- Decretos e Portarias
- Súmulas e Enunciados
```

### 5. Gerar Documentos Jurídicos Auditados
```
- Petições Iniciais
- Pareceres
- Contratos
- Recursos
- Memoriais
```

---

## 🔄 PIPELINE DE 6 FASES

```
┌─────────────────────────────────────────────────────────────────┐
│                    PIPELINE FORENSE DE DADOS                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  FASE 1: COLETA BRUTA                                          │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ Agentes: WebScraper, LexML, STF, STJ, TJ-CE, IBGE,    │   │
│  │          INEP, Portal Municipal                          │   │
│  └──────────────────────────────────────────────────────────┘   │
│                              │                                  │
│                              ▼                                  │
│  FASE 2: VALIDAÇÃO DE FONTES                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ CrossValidator                                            │   │
│  │ Verificação de autenticidade e consistência              │   │
│  └──────────────────────────────────────────────────────────┘   │
│                              │                                  │
│                              ▼                                  │
│  FASE 3: CRUZAMENTO DE INFORMAÇÕES                             │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ Triangulação de dados entre fontes                      │   │
│  │ Score de convergência                                    │   │
│  └──────────────────────────────────────────────────────────┘   │
│                              │                                  │
│                              ▼                                  │
│  FASE 4: ANÁLISE DE CONSISTÊNCIA                             │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ CitationValidator, PrecedentAnalyzer, LegislationChecker │   │
│  │ DoctrineValidator, RiskAnalyzer                         │   │
│  └──────────────────────────────────────────────────────────┘   │
│                              │                                  │
│                              ▼                                  │
│  FASE 5: SÍNTESE AUDITORA                                    │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ DocumentSynthesizer + ForensicAuditor                    │   │
│  │ Relatório de auditoria                                   │   │
│  └──────────────────────────────────────────────────────────┘   │
│                              │                                  │
│                              ▼                                  │
│  FASE 6: APROVAÇÃO/REJEIÇÃO                                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ ComplianceChecker                                         │   │
│  │ Score Final ≥90% = APROVADO                             │   │
│  └──────────────────────────────────────────────────────────┘   │
│                              │                                  │
│                              ▼                                  │
│                    ✅ DOCUMENTO PRONTO                         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📊 AGENTES ESPECIALIZADOS

### Fase 1: Coleta (8 Agentes)

| ID | Agente | Função | Fontes |
|----|--------|--------|--------|
| 01 | WebScraper | Coleta geral de sites | Portais governamentais |
| 02 | LexMLScraper | Legislação | LexML.gov.br |
| 03 | STFScraper | Jurisprudência STF | Portal STF |
| 04 | STJScraper | Jurisprudência STJ | Portal STJ |
| 05 | TJ-CEScraper | Jurisprudência Estadual | TJ-CE |
| 06 | IBGEScraper | Dados demográficos | IBGE Cidades |
| 07 | INEPScraper | Dados educacionais | INEP, QEdu |
| 08 | PortalMunicipal | Dados de prefeituras | Sites municipais |

### Fase 2: Validação (1 Agente)

| ID | Agente | Função |
|----|--------|--------|
| 09 | CrossValidator | Validação cruzada de dados |

### Fase 3-4: Análise (3 Agentes)

| ID | Agente | Função |
|----|--------|--------|
| 10 | ForensicAuditor | Auditoria forense completa |
| 11 | DocumentSynthesizer | Síntese de documentos |
| 12 | ComplianceChecker | Verificação OAB/ABNT |

---

## 🎓 EXEMPLOS DE USO

### Exemplo 1: Dados de Município
```
INPUT: "Buscar dados do município de Crateús/CE"
OUTPUT: 
{
  "municipio": "CRATEÚS",
  "codigo_ibge": "2304103",
  "populacao_2022": 76390,
  "area_km2": 2981.461,
  "idhm_2010": 0.644,
  "pib_per_capita_2023": 16476.30,
  "score_confiabilidade": 0.98,
  "status": "APROVADO"
}
```

### Exemplo 2: Dados de Escola
```
INPUT: "Buscar dados da escola Airamt Veras em Crateús"
OUTPUT:
{
  "escola": "Escola de Cidadania Airamt Veras",
  "codigo_inep": "23084995",
  "matriculas_2025": 177,
  "endereco": "Rua Capistrano de Abreu, S/N - IPASE",
  "tempo_integral": true,
  "score_confiabilidade": 0.99,
  "status": "APROVADO"
}
```

### Exemplo 3: Jurisprudência
```
INPUT: "Buscar jurisprudência do STF sobre doação de imóveis públicos"
OUTPUT:
{
  "resultados": [
    {
      "processo": "REsp 1.323.183/RS",
      "tema": "Doação para fins sociais",
      "ementa": "...",
      "fonte": "Portal STJ",
      "status": "APROVADO"
    }
  ]
}
```

---

## 📈 MÉTRICAS DE QUALIDADE

| Métrica | Target | Crítico |
|---------|--------|---------|
| Completude | ≥95% | <90% |
| Precisão | ≥98% | <95% |
| Cruzamento | 100% | <80% |
| Auditoria | 100% | <90% |
| Score Final | ≥90% | <80% |

### Status de Aprovação

| Status | Condição | Ação |
|--------|----------|------|
| **APROVADO** | Score ≥90% | Documento pronto para entrega |
| **EM REVISÃO** | Score 80-89% | Revisar campos indicados |
| **REJEITADO** | Score <80% | Reprocessar com novas fontes |

---

## 📁 ESTRUTURA DE ARQUIVOS

```
juridico-brasil-forense/
│
├── SKILL.md                          # Este arquivo - Arquitetura principal
│
├── agents/                           # Agentes especializados
│   ├── 01_webscraper_forense.md     # WebScraper - Coleta geral
│   ├── 02_lexml_scraper.md           # LexMLScraper - Legislação
│   ├── 03_stf_scraper.md             # STFScraper - STF
│   ├── 04_stj_scraper.md             # STJScraper - STJ
│   ├── 05_tjce_scraper.md            # TJ-CEScraper - TJ Ceará
│   ├── 06_ibge_scraper.md            # IBGEScraper - IBGE
│   ├── 07_inep_scraper.md            # INEPScraper - INEP
│   ├── 08_portal_municipal_scraper.md # Portal Municipal
│   ├── 09_cross_validator.md         # CrossValidator
│   ├── 10_forensic_auditor.md        # ForensicAuditor
│   ├── 11_document_synthesizer.md   # DocumentSynthesizer
│   └── 12_compliance_checker.md      # ComplianceChecker
│
├── templates/
│   └── documento_forense_template.md # Template de documento final
│
└── README.md                         # Este arquivo
```

---

## 🔗 FONTES OFICIAIS UTILIZADAS

### Fontes Primárias

| Fonte | URL | Dados |
|-------|-----|-------|
| IBGE | ibge.gov.br | População, IDHM, PIB |
| INEP | inep.gov.br | Escolas, matrículas, IDEB |
| STF | portal.stf.jus.br | Jurisprudência federal |
| STJ | stj.jus.br | Jurisprudência superior |
| LexML | lexml.gov.br | Legislação federal/estadual |
| CNJ | cnj.jus.br | Dados processuais |

### Fontes Secundárias

| Fonte | URL | Dados |
|-------|-----|-------|
| QEdu | qedu.org.br | Educação comparada |
| Portal Crateús | crateus.ce.gov.br | Dados municipais |
| TJ-CE | tjce.jus.br | Jurisprudência estadual |

---

## 🚀 COMO USAR

### Passo 1: Identificar a Necessidade
```
- Qual tipo de dados você precisa?
- Município? Escola? Jurisprudência? Legislação?
```

### Passo 2: Executar o Pipeline
```
O sistema executará automaticamente:
1. Coleta de dados de múltiplas fontes
2. Validação cruzada
3. Auditoria forense
4. Geração de documento auditado
```

### Passo 3: Receber Resultado
```
Você receberá:
- Dados coletados e verificados
- Score de confiabilidade
- Status (APROVADO/REJEITADO)
- Documento formatado
```

---

## ⚠️ LIMITAÇÕES CONHECIDAS

1. **Rate Limiting**: Alguns sites governamentais podem bloquear múltiplas requisições
2. **Delay de Indexação**: Dados podem demorar para aparecer nos sistemas oficiais
3. **Não acessa sistemas fechados**: CAPTCHAs, sistemas com login obrigatório
4. **Dependência de internet**: Requer conexão para coleta em tempo real

---

## 📞 SUPORTE

Para dúvidas ou problemas:
1. Verifique se a fonte oficial está acessível
2. Tente novamente após alguns minutos
3. Reporte o problema com o ID da pesquisa

---

## 📝 CHANGELOG

| Versão | Data | Alterações |
|--------|------|-----------|
| 2.0.0 | 20/03/2026 | Sistema forense completo com 12 agentes |
| 1.0.0 | 15/03/2024 | Lançamento inicial |

---

**SISTEMA:** MASWOS V5 NEXUS  
**SKILL:** JURÍDICO BRASIL FORENSE v2.0  
**STATUS:** OPERACIONAL ✅  
**ÚLTIMA ATUALIZAÇÃO:** 20/03/2026

