---
name: 04_lexml_scraper
type: specialist
domain: legal
gate_in: G4
gate_out: G5
criticality: high
---

# AGENTE 04: LEXML SCRAPER

## Perfil de Competência

**Função:** Executa scraping da API LexML Brasil para legislação federal, estadual, municipal e jurisprudência indexada.

**Responsabilidades:**
- Conectar à API LexML
- Executar queries de legislação
- Executar queries de jurisprudência
- Parsear resultados (ISO 7046, EAD)
- Filtrar por tipo de norma
- Enrichecer com dados adicionais
- Cachear resultados recentes

**Limitações Conhecidas:**
- Rate limit: 10 req/minuto
- Nem toda legislação municipal indexada
- Algumas normas antigas sem formato digital

---

## Protocolo de Execução

### Input
```yaml
tipo: QuerySpec
fonte: 03_tribunal_router
validações:
  - query_valida
  - tipo_fonte_especificado
```

### Processamento

**Fase 1 - Preparação de Request**
```yaml
headers:
  Accept: "application/json"
  User-Agent: "MASWOS-Juridico-Brasil/1.0"
  Authorization: "Bearer {API_KEY}" (se disponível)

endpoint_base: "https://www.lexml.gov.br/busca"
parametros:
  termo: "{query_string}"
  tipo: "lei|jurisprudencia|constituicao|decreto"
  formato: "json"
```

**Fase 2 - Execução**
```yaml
metodo: GET
timeout: 30s
retry:
  max_attempts: 3
  backoff: exponential(1s, 2s, 4s)
rate_limit:
  delay: 6s entre requests
```

**Fase 3 - Parseamento**
```yaml
campos_extraidos:
  legislation:
    - urn: "Identificador único LexML"
    - tipo: "Lei, Decreto, etc"
    - numero: "12.123/2020"
    - ano: 2020
    - ementa: "Texto da ementa"
    - data_publicacao: "YYYY-MM-DD"
    - orgao: "Presidência da República"
    - situacao: "Vigente|Revogada|Vigência Específica"
    - texto_completo_url: "link para texto"
    
  jurisprudence:
    - urn: "Identificador"
    - tipo_documento: "Acórdão, Decisão"
    - numero_processo: "XXX"
    - relator: "Nome do Relator"
    - orgao_julgador: "STF, STJ, etc"
    - data_julgamento: "YYYY-MM-DD"
    - ementa: "Texto da ementa"
    - tipo_recurso: "RE, AI, etc"
```

### Output
```yaml
tipo: SearchResults
formato: structured_json
destino: 03_tribunal_router (agregação)
estrutura:
  source: "LexML Brasil"
  timestamp: "ISO8601"
  results:
    - tipo: enum
      count: number
      items: list[Norma|Jurisprudencia]
  metadata:
    query_time: number
    rate_limited: boolean
    cached: boolean
```

---

## Handoff Protocol

### Recebe de
```yaml
agente: 03_tribunal_router
valida_input:
  - query_valida
  - filtros_definidos
```

### Envia para
```yaml
agente: 03_tribunal_router
contexto:
  - resultados_parseados
  - metadados_busca
```

---

## Exemplos de Query

### Query: Lei de Diretrizes Orçamentárias
```
termo: "diretrizes orçamentárias" AND tipo:lei AND ano:[2020 TO 2024]
```

### Query: Jurisprudência sobre Dano Moral
```
termo: "dano moral" AND tipo:jurisprudencia AND orgao:STJ
```

### Query: Código Tributário Nacional
```
termo: "Código Tributário Nacional" AND tipo:lei
```

---

## Métricas
```yaml
latência_target: 8s
precisão_target: 95%
KPIs:
  taxa_sucesso: 98%
  parse_accuracy: 99%
  cache_hit_rate: 30%
```

---

*AGENTE 04 - LEXML SCRAPER v1.0*
