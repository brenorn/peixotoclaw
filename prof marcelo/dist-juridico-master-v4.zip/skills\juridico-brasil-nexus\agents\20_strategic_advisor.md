# AGENTE N20: STRATEGIC ADVISOR
## Orientação Estratégica Processual

**ID:** N20
**Sistema:** juridico-brasil-nexus
**Camada:** Analysis (Fase 3-4)
**Gate:** G3
**Função:** Recomenda estratégia processual baseada em análise

---

## ESTRATÉGIAS POR TIPO DE AÇÃO

### Ação Administrativa
```yaml
administrativa:
  ordem: 1
  agentes:
    - "Manifestação administrativa prévia"
    - "Pedido de informações"
    - "Audiência pública"
  prazos:
    - "30 dias para resposta"
    - "Recurso em 10 dias"
```

### Ação Judicial
```yaml
judicial:
  competencia: "Justiça Federal"
  vara: "Vara Federal de Crateús/CE"
  classe: "Ação Ordinária"
  valor_causa: "Indeterminado"
```

---

## RECOMENDAÇÕES ESTRATÉGICAS

### 1. Fundamentação Legal
```
□ Art. 17 Lei 8.666/93 (doação de bens)
□ CF/88 Art. 205-214 (educação)
□ Lei 9.394/96 (LDB)
□ Interesse social claramente demonstrado
```

### 2. Provas Necessárias
```
□ Levantamento topográfico do terreno
□ Plantabaixa da escola atual
□ Laudo de necessidade de expansão
□ Estudo de impacto ambiental
□ Manifestação do INSS
□ Aprovação da comunidade escolar
```

### 3. Argumentos-Chave
```
□ Direito à educação como fundamental
□ Interesse social da doação
□ Finalidade pública clara
□ Benefício para comunidade
```

---

## OUTPUT

```json
{
  "strategic_advisor": {
    "id": "uuid",
    "data": "YYYY-MM-DD",
    "caso": "Doação Terreno INSS - Crateús",
    "recomendacoes": [
      {
        "ordem": 1,
        "tipo": "Prévia",
        "descricao": "Solicitar manifestação do INSS",
        "prazo": "30 dias",
        "resultado_esperado": "Anuência ou negativa fundamentada"
      },
      {
        "ordem": 2,
        "tipo": "Judicial",
        "descricao": "Ação de usucapião especial municipal",
        "vara": "Vara Federal Crateús",
        "classe": "Ação Ordinária"
      }
    ],
    "estrategia_principal": "FUNDAMENTAÇÃO ROBUSTA NO INTERESSE SOCIAL",
    "score_confianca": 85
  }
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N20 - Strategic Advisor
**STATUS:** OPERACIONAL ✅
