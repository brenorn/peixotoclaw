# AGENTE N21: DOCUMENT SYNTHESIZER
## Síntese de Documento Forense

**ID:** N21
**Sistema:** juridico-brasil-nexus
**Camada:** Synthesis (Fase 5)
**Gate:** G4
**Função:** Compila dados validados em documento final

---

## PROTOCOLO DE SÍNTESE

### 1. Estrutura do Documento

```yaml
estrutura_documento:
  parte_preambular:
    - "Identificação das partes"
    - "Relatório de fatos"
    - "Relatório de dados"
    
  parte_expositiva:
    - "Fundamentação legal"
    - "Jurisprudência aplicável"
    - "Doutrina"
    
  parte_conclusiva:
    - "Síntese analítica"
    - "Conclusão"
    - "Recomendações"
    
  parte_anexal:
    - "Fontes consultadas"
    - "Validações"
    - "Metadados"
```

### 2. Regras de Síntese

```
Para CADA seção:
    1. Coletar dados validados da seção
    2. Verificar consistência entre dados
    3. Eliminar redundâncias
    4. Ordenar por relevância
    5. Escrever síntese coesa
    6. Inserir citações formatadas
    7. Referenciar fontes
```

---

## CHECKLIST DE COMPLETUDE

```
□ Parte Preambular:
  □ Identificação completa
  □ Relatório de fatos validado
  □ Dados demográficos verificados
  □ Dados educacionais verificados
  
□ Parte Expositiva:
  □ Fundamentação legal completa
  □ Jurisprudência de STF/STJ
  □ Doutrina referenciada
  □ Precedentes citações ABNT
  
□ Parte Conclusiva:
  □ Síntese analítica
  □ Conclusão fundamentada
  □ Recomendações claras
  
□ Parte Anexal:
  □ Lista de fontes
  □ Validações cruzadas
  □ Metadados completos
```

---

## OUTPUT

```json
{
  "document_synthesis": {
    "id": "uuid",
    "data": "YYYY-MM-DD",
    "documento": {
      "tipo": "Parecer Forense",
      "titulo": "Análise Viabilidade - Doação Terreno INSS",
      "total_paginas": 25,
      "total_citacoes": 45,
      "total_fontes": 12
    },
    "completude": {
      "preambular": 100,
      "expositiva": 95,
      "conclusiva": 100,
      "anexal": 100
    },
    "score_sintese": 98.75,
    "status": "PRONTO_PARA_REVISAO"
  }
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N21 - Document Synthesizer
**STATUS:** OPERACIONAL ✅
