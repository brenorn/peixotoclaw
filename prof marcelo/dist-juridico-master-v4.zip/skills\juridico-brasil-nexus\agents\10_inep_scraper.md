# AGENTE N10: INEP SCRAPER
## Coleta de Dados Educacionais

**ID:** N10
**Sistema:** juridico-brasil-nexus
**Camada:** Collection (Fase 1)
**Gate:** G1
**Função:** Coleta dados educacionais do INEP (inep.gov.br)

---

## FONTES INEP

| Fonte | URL | Dados |
|-------|-----|-------|
| Portal INEP | inep.gov.br | Dados gerais |
| IDEB | inep.gov.br/ideb | Índice Educação |
| Censo Escolar | inep.gov.br/censo-escolar | Matrículas |
| ENEM | inep.gov.br/enem | Resultados |
| SAEPE | saepe.caedigital.net | Avaliação CE |

---

## DADOS COLETADOS POR ESCOLA

### Identificação
```yaml
escola:
  - nome
  - codigo_inep (8 dígitos)
  - endereco
  - bairro
  - cep
  - municipio
  - dependencia_administrativa
  - localizacao
```

### Infraestrutura
```yaml
infraestrutura:
  - biblioteca
  - laboratorio_informatica
  - laboratorio_ciencias
  - quadra_esportes
  - acesso_internet
  - acessibilidade
```

### Dados Acadêmicos
```yaml
academico:
  - numero_matriculas
  - numero_docentes
  - numero_turmas
  - ideb_anos_iniciais
  - ideb_anos_finais
  - taxa_aprovacao
  - fluxo_escolar
```

---

## QUERIES DE EXEMPLO

```
# Escola Crateús
site:inep.gov.br "Crateús" "escola" "INEP"

# IDEB
site:inep.gov.br "IDEB" "Ceará" "escolas"

# QEdu
site:qedu.org.br "Crateús" "escola" "Airamt Veras"

# Censo Escolar
site:inep.gov.br "censo escolar" "Ceará" "matrículas"
```

---

## OUTPUT

```json
{
  "fonte": "INEP",
  "url": "https://inep.gov.br/...",
  "tipo": "dados_educacionais",
  "data_coleta": "YYYY-MM-DD",
  "dados": {
    "escola": {
      "nome": "Escola de Cidadania Airamt Veras",
      "codigo_inep": 23084995,
      "endereco": "Rua Capistrano de Abreu, S/N",
      "bairro": "IPASE",
      "municipio": "Crateús",
      "uf": "CE",
      "cep": "63700-450"
    },
    "infraestrutura": {
      "biblioteca": true,
      "laboratorio_informatica": true,
      "acesso_internet": true,
      "acessibilidade": true
    },
    "academico_2023": {
      "matriculas": 177,
      "docentes": 14,
      "turmas": 12,
      "ideb": 4.5
    }
  },
  "metadados": {
    "completude": 95,
    "precisao": 99,
    "fonte": "Censo Escolar 2023"
  }
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N10 - INEP Scraper
**STATUS:** OPERACIONAL ✅
