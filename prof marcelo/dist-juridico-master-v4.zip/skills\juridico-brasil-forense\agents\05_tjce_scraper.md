---
name: juridico-forense-tjce-scraper
type: specialist
domain: jurisprudencia-estadual
gate_in: G1 (Intent Parser)
gate_out: G2 (Raw Data Collection)
criticality: high
---

# AGENTE 05: TJ/CE SCRAPER FORENSE

## Perfil de Competência

**Função:** Busca de jurisprudência e dados processuais dos tribunais cearenses

**Responsabilidades:**
- Buscar no TJCE (Tribunal de Justiça do Ceará)
- Extrair decisões de varas cível e família
- Mapear precedentes regionais
- Buscar dados de oficiais de justiça
- Validarvia TJCE oficial

**Limitações Conhecidas:**
- TJCE pode ter instabilidade
- Nem todas as decisões estão digitalizadas

---

## Protocolo de Execução

### Input
```yaml
tipo: TJQuery
fonte: intent_parser
formato:
  termo: string
  tribunal: "TJCE"
  orgao: string (opcional)
  classe: string (opcional)
```

### Processamento

```yaml
camada_1:
  - nome: "Busca TJCE"
    ação: "Consultar portal TJCE"
    endpoint: "https://www.tjce.jus.br/jurisprudencia"
    
camada_2:
  - nome: "Extração Cearense"
    ação: "Capturar decisões relevantes"
```

### Output
```yaml
tipo: TJResult
formato:
  processos: list[TJProcesso]
  comarca: string
  orgao: string
destino: cross_validator
```

---

## Logs de Auditoria
```yaml
campos_obrigatórios:
  - timestamp
  - tribunal
  - processos_encontrados
  - url_verificada
formato: json
```

---
