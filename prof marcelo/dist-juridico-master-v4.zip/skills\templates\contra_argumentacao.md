# TEMPLATE: CONTRA-ARGUMENTAÇÃO JURÍDICA

## Estrutura para Rebatimento de Falhas

```
# CONTRA-ARGUMENTAÇÃO JURÍDICA

## IDENTIFICAÇÃO
- **Processo:** {NÚMERO}
- **Tribunal Origem:** {TRIBUNAL}
- **Falha a Rebater:** {CÓDIGO - TÍTULO}
- **Data:** {DATA}

---

## 1. RECONHECIMENTO DA TESE ADVERSA

"{Transcrição fiel da tese/argumento a ser rebatido}"

---

## 2. IDENTIFICAÇÃO DA FALHA

### 2.1 Tipo de Falha
- [ ] Material (Erro de Fato)
- [ ] Jurídica (Erro de Direito)
- [ ] Processual (Vício)
- [ ] Interpretativa (Má Aplicação)

### 2.2 Localização no Voto/Acórdão
Trecho específico onde a falha se manifesta

---

## 3. ARGUMENTO DE REBATIMENTO

### 3.1 Premissa Factual
{Fatos que demonstram a incorreção da premissa}

### 3.2 Premissa Jurídica
{Norma corretamente aplicável}

### 3.3 Raciocínio Conclusivo
{Se A (fato correto) + B (norma correta) = C (conclusão diversa)}

---

## 4. FUNDAMENTAÇÃO LEGAL

### 4.1 Constituição Federal
| Artigo | Trecho Relevante |
|--------|------------------|
| Art. 5º, LIV | Due process |
| Art. 93, IX | Motivação das decisões |

### 4.2 Legislação Infraconstitucional
| Diploma | Artigo | Aplicação |
|---------|--------|-----------|
| CPC | Art. 489 | Fundamentação |
| CC | Art. 186 | Responsabilidade |

### 4.3 Princípios
- {Princípio 1}
- {Princípio 2}

---

## 5. PRECEDENTES FAVORÁVEIS

### 5.1 STF
| Classe | Número | Tema RG | Resultado |
|--------|--------|---------|-----------|
| RE | xxx | xxx | Provido |

EMENTA: "{Ementa do precedente}"

### 5.2 STJ
| Classe | Número | Tema | Resultado |
|--------|--------|------|-----------|
| REsp | xxx | xxx | Provido |

EMENTA: "{Ementa do precedente}"

### 5.3 Tribunais Inferiores
{Tribunal}, {Classe}, {Número}, Rel. Des. {Nome}

---

## 6. DOUTRINA

- {AUTOR}, {Título da Obra}, {Editora}, {Ano}, p. {xx}
- {AUTOR}, "{Artigo}", {Revista}, {Ano}, p. {xx}

---

## 7. ANTECIPAÇÃO DE CONTRA-ARGUMENTOS

### 7.1 Possível Resposta 1
{Argumento que a parte contrária poderia apresentar}

**Réplica:**
{Rebatimento}

### 7.2 Possível Resposta 2
{...}

---

## 8. PEDIDO RESULTANTE

Diante do exposto, requer:

1. Reconhecimento da falha identificada;
2. {Pedido específico};
3. {Pedido final};

---

## 9. QUALIFICAÇÃO OAB

**Revisado por:** {Nome - OAB/UF}
**Status:** [ ] Aprovado [ ] Com Ressalvas
**Observações:** {Se houver}
```
