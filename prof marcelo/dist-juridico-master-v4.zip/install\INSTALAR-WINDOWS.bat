@echo off
chcp 65001 >nul
echo =============================================================
echo    JURÍDICO BRASIL MASTER v4.0 - INSTALAÇÃO RÁPIDA
echo =============================================================
echo.

:: Verificar se está no diretório correto
if not exist "dist-juridico-master-v4.zip" (
    echo ERRO: Arquivo dist-juridico-master-v4.zip não encontrado!
    echo Execute este script na mesma pasta do arquivo ZIP.
    pause
    exit /b 1
)

:: Criar diretório de destino
set DESTINO=%USERPROFILE%\.opencode\skills
if not exist "%DESTINO%" (
    echo Criando diretório de instalação...
    mkdir "%DESTINO%"
)

:: Extrair ZIP
echo.
echo Extraindo arquivos...
powershell -Command "Expand-Archive -Path 'dist-juridico-master-v4.zip' -DestinationPath 'temp_install' -Force"

:: Copiar skills
echo.
echo Instalando skills...
xcopy /E /Y "temp_install\skills\juridico-brasil-master" "%DESTINO%\juridico-brasil-master\"
xcopy /E /Y "temp_install\skills\juridico-brasil" "%DESTINO%\juridico-brasil\"
xcopy /E /Y "temp_install\skills\juridico-brasil-nexus" "%DESTINO%\juridico-brasil-nexus\"
xcopy /E /Y "temp_install\skills\juridico-brasil-forense" "%DESTINO%\juridico-brasil-forense\"

:: Limpar
echo.
echo Limpando arquivos temporários...
rmdir /S /Q "temp_install" 2>nul

:: Verificar instalação
echo.
echo =============================================================
echo    VERIFICAÇÃO
echo =============================================================
if exist "%DESTINO%\juridico-brasil-master\SKILL.md" (
    echo [OK] juridico-brasil-master
)
if exist "%DESTINO%\juridico-brasil\SKILL.md" (
    echo [OK] juridico-brasil
)
if exist "%DESTINO%\juridico-brasil-nexus\SKILL.md" (
    echo [OK] juridico-brasil-nexus
)
if exist "%DESTINO%\juridico-brasil-forense\SKILL.md" (
    echo [OK] juridico-brasil-forense
)

echo.
echo =============================================================
echo    INSTALAÇÃO CONCLUÍDA!
echo =============================================================
echo.
echo Para usar, no OpenCode digite:
echo   /skill juridico-brasil-master
echo.
pause
