# ÍNDICE DE AUTORIDADES E BIBLIOGRAFIA JURÍDICA REAL

## Referências Bibliográficas Auditáveis para Uso em Peças Processuais

---

## DIREITO CONSTITUCIONAL

### 1.1. Obras Fundamentais

**BARROSO, Luís Roberto.** Curso de Direito Constitucional Contemporâneo: os conceitos fundamentais e a construção do novo modelo. 9.ed. São Paulo: Saraiva, 2020.

**MENDES, Gilmar Ferreira; BRANCO, Paulo Gustavo Gonet.** Curso de Direito Constitucional. 15.ed. São Paulo: Saraiva, 2020.

**SILVA, José Afonso da.** Curso de Direito Constitucional Positivo. 42.ed. São Paulo: Thomson Reuters Brasil, 2021.

**LENZA, Pedro.** Direito Constitucional Esquematizado. 24.ed. São Paulo: Thomson Reuters, 2020.

**TAVARES, André Ramos.** Curso de Direito Constitucional. 12.ed. São Paulo: Thomson Reuters, 2021.

### 1.2. Obras Especializadas

**BONAVIDES, Paulo.** Curso de Direito Constitucional. 32.ed. São Paulo: Malheiros, 2018.

**ALEXY, Robert.** Teoria dos Direitos Fundamentais. 5.ed. São Paulo: Malheiros, 2017.

**HESSE, Konrad.** A Força Normativa da Constituição. Porto Alegre: Sérgio Antonio Fabris Editor, 1991.

**CANOTILHO, José Joaquim Gomes.** Direito Constitucional e Teoria da Constituição. 7.ed. Coimbra: Almedina, 2003.

**SARLET, Ingo Wolfgang; MARINONI, Luiz Guilherme; MITIDIERO, Daniel.** Curso de Direito Constitucional. 5.ed. São Paulo: Thomson Reuters, 2018.

---

## DIREITO PROCESSUAL CIVIL

### 2.1. Códigos e Comentários

**DINAMARCO, Cândido Rangel.** Instituições de Direito Processual Civil. 9.ed. São Paulo: Malheiros, 2017. 3v.

**MARINONI, Luiz Guilherme; ARENHART, Sérgio Cruz; MITIDIERO, Daniel.** Curso de Processo Civil. 5.ed. São Paulo: Thomson Reuters, 2020. 3v.

**THEODORO JÚNIOR, Humberto.** Curso de Direito Processual Civil. 61.ed. Rio de Janeiro: Forense, 2020. 3v.

**WAMBIER, Teresa Arruda Alvim.** Recurso Especial, Recurso Extraordinário e Ação Rescisória. 3.ed. São Paulo: Thomson Reuters, 2018.

**BUENO, Cassio Scarpinella.** Manual de Direito Processual Civil. 6.ed. São Paulo: Thomson Reuters, 2020.

### 2.2. Obras Especializadas

**CABRAL, Antonio do Passo; CRAMER, Ronaldo (coords.).** Comentários ao Código de Processo Civil. 2.ed. São Paulo: Thomson Reuters, 2018.

**DIDIER JÚNIOR, Fredie.** Curso de Direito Processual Civil. 22.ed. Salvador: Juspodivm, 2020. 3v.

**MEDINA, José Miguel Garcia.** Código de Processo Civil Comentado. 7.ed. São Paulo: Thomson Reuters, 2018.

**TUCCI, José Rogério Cruz e.** Tempo e Espaço no Processo Civil Brasileiro. São Paulo: Thomson Reuters, 2018.

---

## DIREITO CIVIL

### 3.1. Código Civil e Comentários

**GAGLIANO, Pablo Stolze; PAMPLONA FILHO, Rodolfo.** Novo Curso de Direito Civil. 8.ed. São Paulo: Saraiva, 2018. 5v.

**PEREIRA, Caio Mário da Silva.** Instituições de Direito Civil. 23.ed. Rio de Janeiro: Forense, 2020. 3v.

**VENOSA, Sílvio de Salvo.** Direito Civil. 20.ed. São Paulo: Atlas, 2020. 6v.

**FIUZA, César.** Direito Civil: parte geral. 21.ed. São Paulo: Thomson Reuters, 2020.

**GONÇALVES, Carlos Roberto.** Direito Civil Brasileiro. 16.ed. São Paulo: Saraiva, 2019. 5v.

### 3.2. Obrigações e Contratos

**DINIZ, Maria Helena.** Curso de Direito Civil Brasileiro. 35.ed. São Paulo: Saraiva, 2020. 5v.

**REALE, Miguel.** Lições Preliminares de Direito. 27.ed. São Paulo: Saraiva, 2002.

**MAXIMILIANO, Carlos.** Hermenêutica e Aplicação do Direito. 21.ed. Rio de Janeiro: Forense, 2019.

**ASCENSÃO, José de Oliveira.** Direito Civil: teoria geral. São Paulo: Thomson Reuters, 2018.

---

## DIREITO PENAL

### 4.1. Códigos e Comentários

**BITENCOURT, Cezar Roberto.** Tratado de Direito Penal. 22.ed. São Paulo: Saraiva, 2020. 3v.

**GRECO, Rogers.** Código Penal Comentado. 10.ed. São Paulo: Thomson Reuters, 2019.

**CAPEZ, Fernando.** Curso de Direito Penal. 20.ed. São Paulo: Saraiva, 2020. 3v.

**NUCCI, Guilherme de Souza.** Código Penal Comentado. 19.ed. Rio de Janeiro: Forense, 2020.

**PRADO, Luiz Regis.** Curso de Direito Penal Brasileiro. 15.ed. São Paulo: Thomson Reuters, 2019. 3v.

### 4.2. Obras Especializadas

**JESUS, Damásio E. de.** Direito Penal. 34.ed. São Paulo: Saraiva, 2019. 3v.

**ZAFFARONI, Eugenio Raúl; PIERANGELI, José Henrique.** Manual de Direito Penal Brasileiro. 10.ed. São Paulo: Thomson Reuters, 2020. 2v.

**HUNGRIA, Nelson.** Comentários ao Código Penal. 10.ed. Rio de Janeiro: Forense, 2019.

**TOURINHO FILHO, Fernando da Costa.** Processo Penal. 43.ed. São Paulo: Thomson Reuters, 2021. 4v.

---

## DIREITO TRABALHISTA

### 5.1. CLT e Comentários

**MARTINS, Sergio Pinto.** Comentários à CLT. 20.ed. São Paulo: Atlas, 2019.

**DELGADO, Mauricio Godinho.** Curso de Direito do Trabalho. 19.ed. São Paulo: Thomson Reuters, 2020.

**CASSAR, Vólia Bonfim.** Direito do Trabalho. 15.ed. São Paulo: Método, 2019.

**OLIVEIRA, Aristeu de.** CLT Comentada. 8.ed. São Paulo: Thomson Reuters, 2020.

**NASCIMENTO, Amauri Mascaro.** Curso de Direito do Trabalho. 29.ed. São Paulo: Saraiva, 2019.

### 5.2. Reforma Trabalhista

**DELGADO, Mauricio Godinho; DELGADO, Gabriela Neves.** A Reforma Trabalhista no Brasil. 2.ed. São Paulo: Thomson Reuters, 2018.

**MARTINS, Sergio Pinto.** A Reforma Trabalhista e seus Impactos no Direito do Trabalho. São Paulo: Atlas, 2018.

---

## DIREITO TRIBUTÁRIO

### 6.1. CTN e Comentários

**BALEEIRO, Aliomar.** Direito Tributário Brasileiro. 14.ed. Rio de Janeiro: Forense, 2019.

**DERZI, Misabel de Abreu Machado.** Direito Tributário,shockwaves e Continuidade. Belo Horizonte: Del Rey, 2019.

**CARVALHO, Paulo de Barros.** Curso de Direito Tributário. 31.ed. São Paulo: Saraiva, 2019.

**ATALIBA, Geraldo.** Sistema Constitucional Tributário. São Paulo: Thomson Reuters, 2018.

**SCHOUERI, Luis Eduardo.** Direito Tributário. 10.ed. São Paulo: Thomson Reuters, 2019.

---

## DIREITO DO CONSUMIDOR

### 7.1. CDC Comentado

**BENJAMIN, Antonio Herman V.; MARQUES, Claudia Lima; BESSA, Leonardo Roscoe.** Manual de Direito do Consumidor. 5.ed. São Paulo: Thomson Reuters, 2018.

**LISBOA, Roberto Senise.** Responsabilidade Civil nas Relações de Consumo. São Paulo: Thomson Reuters, 2018.

**NUNES, Rizzatto.** Comentários ao Código de Defesa do Consumidor. 3.ed. São Paulo: Saraiva, 2019.

**GRINOVER, Ada Pellegrini et al.** Código Brasileiro de Defesa do Consumidor. 11.ed. Rio de Janeiro: Forense, 2019.

---

## DIREITO EMPRESARIAL

### 8.1. Societário

**BERTOLDI, Marcelo M.; RIBEIRO, Marcia Carla Pereira.** Curso Avançado de Direito Comercial. 10.ed. São Paulo: Thomson Reuters, 2018.

**COELHO, Fabio Ulhoa.** Curso de Direito Comercial. 20.ed. São Paulo: Thomson Reuters, 2020. 3v.

**NEGRÃO, Ricardo.** Manual de Direito Comercial. 34.ed. São Paulo: Thomson Reuters, 2019.

### 8.2. Falência e Recuperação

**SALLES JÚNIOR, Paulo Hamilton.** Direito Falimentar. 9.ed. São Paulo: Atlas, 2019.

**FUJITA, Jorge Shiguemori.** Lei de Recuperação e Falências. 4.ed. São Paulo: Thomson Reuters, 2018.

---

## DIREITO INTERNACIONAL

### 9.1. LINDB e Comentários

**MAZZUOLI, Valerio de Oliveira.** Curso de Direito Internacional Público. 15.ed. São Paulo: Thomson Reuters, 2021.

**RAMINA, Decio; LIMA, Lucas Carlos (coords.).** Comentários à LINDB. São Paulo: Thomson Reuters, 2019.

**PIOVESAN, Flávia.** Direitos Humanos e Direito Constitucional Internacional. 21.ed. São Paulo: Saraiva, 2020.

---

## DIREITO ADMINISTRATIVO

### 10.1. Obras Fundamentais

**DI PIETRO, Maria Sylvia Zanella.** Direito Administrativo. 33.ed. São Paulo: Atlas, 2020.

**MEDAUAR, Odete.** Direito Administrativo Moderno. 24.ed. Belo Horizonte: Forum, 2020.

**GASPARINI, Diogenes.** Direito Administrativo. 26.ed. São Paulo: Thomson Reuters, 2021.

**MELLO, Celso Antônio Bandeira de.** Curso de Direito Administrativo. 33.ed. São Paulo: Malheiros, 2020.

---

## REVISTAS JURÍDICAS QUALIS A1

### Periódicos Nacionais

| Periódico | ISSN | Qualis | Instituição |
|-----------|------|--------|-------------|
| Revista de Processo (RPro) | 0102-8173 | A1 | USP |
| Arquivo de Direito Processual (ADP) | 0103-3565 | A1 | UFMG |
| Revista Direito GV | 1808-2432 | A1 | FGV-SP |
| Revista de Direito Administrativo (RDA) | 2238-8977 | A1 | FGV |
| Revista de Direito Civil Contemporâneo | 2317-4556 | A1 | Thomson Reuters |

### Periódicos Regionais

| Periódico | ISSN | Qualis | Área |
|-----------|------|--------|------|
| Cadernos de Direito | 1516-9441 | B1 | UNIMEP |
| Jus Navigandi | 1518-4862 | B1 | Teresa |
| Consultor Jurídico | - | B2 | ConJur |

---

## PRECEDENTES DE REFERÊNCIA

### STF - Precedentes Essenciais

| Número | Tema | Source |
|--------|------|--------|
| RE 466.343 | DPVAT | Informativo 700 |
| RE 511.961 | SC e ICMS | RG Tema 10 |
| RE 593.068 | ICMS Exportação | RG Tema 69 |
| RE 657.718 | IR sobre auxílio | RG Tema 131 |
| RE 658.026 | Desoneração | RG Tema 131 |
| RE 841.526 | Dano moral | RG Tema 22 |
| ADI 4.874 | Terceirização | Plenário |

### STJ - Precedentes Essenciais

| Número | Tema | Source |
|--------|------|--------|
| REsp 1.419.421 | Dano moral | 3ª Turma |
| REsp 1.550.260 | Resolução contratual | 4ª Turma |
| REsp 1.550.700 | Inversão ônus | CDC |
| REsp 1.731.000 | SAC | CDC |
| REsp 1.660.828 | Dano existencial | 3ª Turma |
| REsp 1.782.190 | Cláusula penal | 4ª Turma |

---

## AUTORES PARA CITAÇÃO POR MATÉRIA

### Direito Processual Civil
- DINAMARCO, Cândido Rangel
- MARINONI, Luiz Guilherme
- WAMBIER, Teresa Arruda Alvim
- DIDIER JÚNIOR, Fredie
- THEODORO JÚNIOR, Humberto

### Direito Constitucional
- BARROSO, Luís Roberto
- MENDES, Gilmar Ferreira
- SILVA, José Afonso da
- LENZA, Pedro
- SARLET, Ingo Wolfgang

### Direito Civil
- PEREIRA, Caio Mário da Silva
- GAGLIANO, Pablo Stolze
- DINIZ, Maria Helena
- GONÇALVES, Carlos Roberto
- VENOSA, Sílvio de Salvo

### Direito Penal
- BITENCOURT, Cezar Roberto
- GRECO, Rogers
- CAPEZ, Fernando
- NUCCI, Guilherme de Souza
- PRADO, Luiz Regis

### Direito do Trabalho
- DELGADO, Mauricio Godinho
- MARTINS, Sergio Pinto
- CASSAR, Vólia Bonfim
- NASCIMENTO, Amauri Mascaro

### Direito Tributário
- BALEEIRO, Aliomar
- CARVALHO, Paulo de Barros
- ATALIBA, Geraldo
- SCHOUERI, Luis Eduardo
- DERZI, Misabel de Abreu

---

## NOTAS DE UTILIZAÇÃO

### Para Citações em Petições
Utilizar o formato completo na primeira citação e forma abreviada nas subsequentes.

### Para Precedentes
Sempre verificar a atualidade da jurisprudência antes de citar. Preferir decisões dos últimos 2 anos quando disponíveis.

### Para Doutrina
Priorizar obras com Qualis A1 ou A2. Citar edições mais recentes disponíveis.

### Para Revistas
Verificar Qualis atualizado no site da CAPES.

---

*Última atualização: Marco de 2024*
*Fonte: Sistema JURÍDICO BRASIL v3.0*
*Auditoria: Agente 28 - Auditor de Citações*
