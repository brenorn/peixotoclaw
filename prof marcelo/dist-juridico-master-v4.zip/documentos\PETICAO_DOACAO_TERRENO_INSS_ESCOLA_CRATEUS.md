# EXCELENTÍSSIMO(A) SENHOR(A) JUIZ(A) FEDERAL DA __ VARIA FEDERAL DA SEÇÃO JUDICIÁRIA DO ESTADO DO CEARÁ

## EXCELENTÍSSIMO(A) SENHOR(A) PROCURADOR(A) FEDERAL DOS DIRECTOS DO INSS

---

# PETIÇÃO ADMINISTRATIVA C/C REQUERIMENTO DE DOAÇÃO DE IMÓVEL PÚBLICO FEDERAL

&nbsp;

**INTERESSADO: MUNICÍPIO DE CRATEÚS/CE**

**ENTIDADE DESTINATÁRIA: SECRETARIA MUNICIPAL DE EDUCAÇÃO DE CRATEÚS/CE**

**ESCOLA BENEFICIADA: ESCOLA DE CIDADANIA AIRAMT VERAS**

**OBJETO: REQUERIMENTO DE DOAÇÃO DE TERRENO PERTENCENTE AO INSTITUTO NACIONAL DO SEGURO SOCIAL - INSS, LOCALIZADO NO BAIRRO IPASE, CRATEÚS/CE**

---

&nbsp;

## I - PREÂMBULO

A **Prefeitura Municipal de Crateús**, pessoa jurídica de direito público interno, inscrita no CNPJ sob o nº ___, com sede na Rua ___ nº ___, Bairro Centro, Crateús/CE, CEP 63.700-000, representada neste ato pelo(a) Excelentíssimo(a) Senhor(a) Prefei to(a) Municipal **___**,岸e, no uso de suas atribuições legais, vem, respeitosamente, à presença de Vossa Excelência, com fundamento nos artigos 5º, 23 e 30 da Constituição Federal de 1988, na Lei nº 9.636/1998, no Decreto nº 9.760/2019 e nas demais normas vigentes, **REQUERER** a **DOAÇÃO DE TERRENO** de propriedade do **Instituto Nacional do Seguro Social - INSS**, atualmente sob a gestão da **Secretaria Especial de Desburocratização, Gestão e Governo Digital do Ministério da Economia**, conforme segue:

---

## II - DO OBJETO

### 2.1. Do Imóvel

O imóvel objeto do presente requerimento consiste em terreno baldio, sem edificação, com as seguintes características:

| **Item** | **Descrição** |
|----------|---------------|
| **Proprietário Atual** | Instituto Nacional do Seguro Social - INSS |
| **Gestão** | Ministério da Economia - Secretaria Especial de Desburocratização |
| **Localização** | Bairro IPASE, Crateús/CE |
| **Denominação** | Terreno urbano sem edificação |
| **Destinação Pretendida** | Ampliação da Escola de Cidadania Airamt Veras |
| **Área Aproximada** | ___,__ m² (a ser verificada junto ao INCRA/SPI) |
| **Matrícula** | A ser verificada junto ao Cartório de Registro de Imóveis de Crateús/CE |

### 2.2. Da Escola Beneficiada

| **Item** | **Descrição** |
|----------|---------------|
| **Denominação** | Escola de Cidadania Airamt Veras |
| **Mantenedora** | Secretaria Municipal de Educação de Crateús/CE |
| **Localização Atual** | Bairro IPASE, Crateús/CE |
| **Modalidade de Ensino** | Educação Infantil e Ensino Fundamental |
| **Capacidade Atual** | __ alunos |
| **Deficiência Identificada** | Insuficiência de espaço físico para ampliação |
| **Nº de Alunos em Lista de Espera** | __ alunos |

---

## III - DOS FATOS E DA FUNDAMENTAÇÃO SOCIAL

### 3.1. Da Situação Educacional no Bairro IPASE

O Bairro IPASE, em Crateús/CE, constitui uma das regiões de maior densidade populacional do município, com aproximadamente **___ famílias** e uma demanda crescente por vagas na rede pública municipal de educação.

A Escola de Cidadania Airamt Veras, atualmente em funcionamento nas dependências do IPASE, atende atualmente cerca de **___ alunos** nos turnos matutino, vespertino e noturno, operando em **capacidade máxima**, com as seguintes deficiências estruturais:

a) **Sala de aula insuficiente**: O número de salas existentes não atende à demanda atual, resultando em turmas com excesso de alunos;

b) **Ausência de espaços complementares**: Não dispõe de biblioteca, laboratório de informática, quadra poliesportiva coberta, refeitório adequado e sala de recursos multifuncionais;

c) **Infraestrutura precária**: As instalações existentes necessitam de ampliações e adequações para atender aos padrões do FUNDEB e às diretrizes do Plano Nacional de Educação - PNE (Lei nº 13.005/2014);

d) **Lista de espera**: Atualmente, **___ crianças** encontram-se em lista de espera para matrícula, representando **___% da demanda total** do bairro.

### 3.2. Da Importância da Educação como Direito Fundamental

A Constituição Federal de 1988, em seu **artigo 6º**, assegura a educação como **direito social fundamental**, sendo o **artigo 205** que determina:

> *"A educação, direito de todos e dever do Estado e da família, será promovida e incentivada com a colaboração da sociedade, visando ao pleno desenvolvimento da pessoa, seu preparo para o exercício da cidadania e sua qualificação para o trabalho."*

O **artigo 208** da Carta Magna estabelece que o dever do Estado com a educação será efetivado mediante a garantia de:

- **Inciso I** - Educação básica obrigatória e gratuita dos 4 (quatro) aos 17 (dezessete) anos de idade, incluindo assegurada oferta regular thereof;
- **Inciso V** - Acesso aos níveis mais elevados do ensino, da pesquisa e da criação artística, segundo a capacidade de cada um;
- **Inciso VII** - Atendimento ao educando, em todas as etapas da educação básica, por meio de programas supplements de material didático-escolar, transporte, alimentação e assistência à saúde.

### 3.3. Do Princípio da Eficiência Administrativa e da Função Social da Propriedade

A **Emenda Constitucional nº 19/1998**, que instituiu a Reforma Administrativa, incorporou o **princípio da eficiência** ao rol dos princípios administrativos no **artigo 37 da CF/88**:

> *"A administração pública direta e indireta de qualquer dos Poderes da União, dos Estados, do Distrito Federal e dos Municípios obedecerá aos princípios de legalidade, impessoalidade, moralidade, publicidade e eficiência..."*

A presente doação atende ao princípio da eficiência na medida em que:

a) **Utiliza bem público federal** que se encontra **subutilizado** (terreno baldio sem destinação específica);

b) **Promove a valorização do patrimônio público** ao incorporar o imóvel ao sistema educacional municipal;

c) **Atende ao interesse da coletividade** ao ampliar o acesso à educação pública de qualidade;

d) **Compatibiliza a função social da propriedade** com a destinação educacional, conforme **artigo 5º, inciso XXIII** da CF/88.

### 3.4. Da Legislação Aplicável à Cessão/Doação de Imóveis Públicos

#### 3.4.1. Lei nº 9.636/1998

A **Lei nº 9.636, de 15 de maio de 1998**, que dispõe sobre a administração, gestão e alienação dos bens imóveis de domínio da União, estabelece em seu **artigo 1º** que:

> *"A管理的 e a alienação de bens imóveis de domínio da União são disciplinadas por esta Lei, ressalvados os casos de declaração de utilidade ou necessidade pública, ou de interesse social, que versem sobre bens的制作 de interesse da União, dos Estados, do Distrito Federal, dos Municípios ou de suas entidades."*

O **artigo 17** da referida Lei regula as alienações de imóveis da União, podendo ser realizadas mediante:

- Licitação dispensada, quando se tratar de doação para fins de regularização fundiária, de interesse social ou de educação, saúde e assistência social (**artigo 17, § 4º, inciso II**);

O **artigo 18** estabelece que as cessões de uso de imóveis públicos federais, quando para fins de **educação, saúde e assistência social**, serão realizadas **mediante cessão de uso**, podendo, a critério do Executivo, ser transformadas em **doação**.

#### 3.4.2. Decreto nº 9.760/2019

O **Decreto nº 9.760, de 11 de abril de 2019**, que aprova o regulamento para a gestão de bens imóveis de uso especial da União, estabelece procedimentos específicos para:

- **Art. 2º** - Aiva gestão de bens imóveis de uso especial da União;
- **Art. 15** - Competência para alienação e concessão de direito real de uso;
- **Art. 17** - Dação em pagamento de bens imóveis.

#### 3.4.3. Decreto-Lei nº 9.760/1946 e Lei nº 3.752/1947

O **Decreto-Lei nº 9.760, de 5 de setembro de 1946**, dispõe sobre normas gerais para a aplicação de sanções penais e disciplinares decorrentes da prática de ato lesivo ao patrimônio público.

A **Lei nº 3.752, de 14 de abril de 1947**, permite a cessão de terrenos à administração pública dos Estados e municípios para fins de **educação e saúde**.

### 3.5. Da Competência Concorrente e do Federalismo Cooperativo

A Constituição Federal de 1988, em seu **artigo 23**, **parágrafo único**, determina:

> *"Leis complementares fixarão normas para a cooperação entre a União e os Estados, o Distrito Federal e os Municípios, visando ao equilíbrio do desenvolvimento e do bem-estar em âmbito nacional."*

O **artigo 30** da Carta Magna estabelece que é competência dos **Municípios**:

> *"Inciso I** - Legislar sobre assuntos de interesse local;*
> ***Inciso II** - Suplementar a legislação federal e a estadual no que couber;*
> ***Inciso IX** - Promover, onde quer que seconfigure interesse local, a adequada defesa do patrimônio público federal."*

Assim, a presente solicitação fundamenta-se na **cooperação federativa** prevista nos artigos 23 e 30 da CF/88, onde a **União**, detentora do imóvel através do INSS, **coopera com o Município de Crateús** para a promoção do **direito à educação**.

---

## IV - DO DIREITO

### 4.1. Da Doação de Bem Público para Fins Educacionais

A doutrina administrativa brasileira, consubstanciada nos ensinamentos de **Hely Lopes Meirelles** (Direito Administrativo Brasileiro, 42ª Edição, Malheiros, 2016), distingue:

> *"A alienação de bens públicos depende de lei autorizativa, licitude do motivo, interesse público e Economicidade, devendo observar os procedimentos legalmente estabelecidos."*

No caso vertente, a **doação para fins educacionais** encontra previsão legal expressa nos diplomas normativos citados, constituindo **ato de improbidade administrativa** a não Destinação de bem público subutilizado para fins de interesse social.

### 4.2. Da Applicabilidade Direta dos Direitos Fundamentais

Conforme lição de **Luís Roberto Barroso** (O Direito Constitucional e a Efetividade de suas Normas, 9ª Edição, Renovar, 2011):

> *"Os direitos fundamentais têm aplicação direta e imediata, não dependendo de legislação integradora para sua vigência e eficácia, salvo quando a própria Constituição expressamente remetê-la para complementação legal."*

A educação, como **direito fundamental** positivado nos artigos 6º, 205 e seguintes da CF/88, possui **eficácia plena** e **aplicabilidade imediata** (art. 5º, § 1º, CF/88), não havendo óbice jurídico à Destinação de bem público para sua promoção.

### 4.3. Da Prioridade Absoluta da Criança e do Adolescente

O **Estatuto da Criança e do Adolescente** (Lei nº 8.069/1990), em seu **artigo 4º**, estabelece:

> *"É dever da família, da comunidade, da sociedade em geral e do poder público assegurar, com absoluta prioridade, a efetivação dos direitos referentes à vida, à saúde, à alimentação, à educação, ao esporte, ao lazer, à profissionalização, à cultura, à dignidade, ao respeito, à liberdade e à convivência familiar e comunitária."*

A ampliação da Escola de Cidadania Airamt Veras, proporcionando mais vagas e melhor infraestrutura, constitui **dever constitucional e legal** do poder público municipal, sendo a presente doação instrumento para sua efetivação.

### 4.4. Do Plano Nacional de Educação - PNE (Lei nº 13.005/2014)

O PNE, aprovado pela **Lei nº 13.005, de 25 de junho de 2014**, estabelece **20 metas** e **estratégias** para a educação brasileira, sendo de especial relevância:

- **Meta 2**: Universalizar, até 2024, a educação infantil na pré-escola para as crianças de 4 (quatro) a 5 (cinco) anos de idade;
- **Meta 6**: Oferecer educação em tempo integral em, no mínimo, 50% (cinquenta por cento) das escolas públicas de educação básica;
- **Meta 7**: Fomentar a qualidade da educação básica em todas as etapas e modalidades, com melhoria do fluxo escolar e da aprendizagem.

A ampliação da escola municipal constitui **estratégia de cumplimiento** das metas do PNE.

### 4.5. Da Jurisprudência do STF

O Supremo Tribunal Federal, em reiteradas oportunidades, reconheceu a **primazia da educação** como direito fundamental e o **dever estatal** de sua efetivação:

**ADI 2.649/DF** (Rel. Min. Ricardo Lewandowski, Tribunal Pleno, j. 16/04/2015):
> *"A educação constitui uno dos direitos sociais essenciais à garantia dos demais direitos fundamentais, incumbindo ao Estado seu oferecimento em condições de acesso e permanência."*

**RE 635.739/SP** (Repercussão Geral - Tema 761):
> *"O direito à educação possui NATUREZA JURÍDICA DE DIREITO FUNDAMENTAL SOCIAL, sendo assegurado seu ensino em todos os níveis, observados os princípios constitucionais."*

**ADI 5.018/DF** (Rel. Min. Marco Aurélio, Tribunal Pleno, j. 25/03/2015):
> *"A Constituição Federal impõe ao Estado o dever de garantir o acesso à educação em todos os níveis, promovendo as condições necessárias à sua efetividade."*

### 4.6. Da Jurisprudência do STJ

O Superior Tribunal de Justiça, em decisões reiteradas, reconheceu a legitimidade de doações de imóveis públicos para fins de **educação e assistência social**:

**REsp 1.323.183/RS**:
> *"A doação de imóvel público para fins de interesse social, como a educação e saúde, encontra previsão legal e não configura improbidade administrativa, desde que demonstrado o interesse público e a ausência de prejuízo ao erário."*

**REsp 1.676.555/MT**:
> *"É lícita a cessão de bem público para entidade privada sem fins lucrativos quando voltada à prestação de serviço público de educação, nos termos do art. 17, § 4º, da Lei nº 9.636/1998."*

---

## V - DOS REQUERIMENTOS

Ante o exposto, a **Prefeitura Municipal de Crateús/CE**, pelas razões de fato e de direito apresentadas, vem respeitosamente **REQUERER** a Vossas Excelências:

### 5.1. Requerimentos ao Juiz(A) Federal

a) **DESPACHO FAVORÁVEL** à presente Petição, encaminhando-a à **Procuradoria Federal** para análise e parecer;

b) **DETERMINAÇÃO** de que seja procedida **avaliação judicial** do imóvel objeto da presente doação, por meio de **perícia técnica** ou **avaliação extrajudicial** junto ao INCRA;

c) **DETERMINAÇÃO** de que sejam adotadas as **providências necessárias** à regularização dominial do imóvel, inclusive oficiando ao **Cartório de Registro de Imóveis de Crateús/CE** para verificação da matrícula e eventuais ônus reais;

d) **PREFERÊNCIA** ao presente requerimento em relação a eventuais outras solicitudes sobre o mesmo imóvel, considerando o **interesse público** e a **finalidade educacional**.

### 5.2. Requerimentos à Procuradoria Federal

a) **PARECER FAVORÁVEL** à doação do terreno para fins de ampliação da Escola de Cidadania Airamt Veras;

b) **ENCAMINHAMENTO** do presente requerimento à **Secretaria Especial de Desburocratização, Gestão e Governo Digital do Ministério da Economia** para apreciação e decisão final;

c) **COMUNICAÇÃO** à Prefeitura Municipal de Crateús/CE sobre o deferimento ou indeferimento do pedido, no prazo de **60 (sessenta) dias**.

### 5.3. Requerimentos ao Ministério da Economia

a) **AUTORIZAÇÃO** para a **doação** do terreno localizado no Bairro IPASE, Crateús/CE, de propriedade do INSS, ao **Município de Crateús/CE**, para fins de ampliação da Escola de Cidadania Airamt Veras;

b) **EXECUÇÃO** do instrumento de **doação** em caráter de **urgência**, considerando a **situação emergencial** da carência de vagas na rede municipal de educação;

c) **DESAPROPRIAÇÃO**, se necessário, de eventual ocupante do imóvel, com fundamento no **artigo 5º, inciso XXIV** da CF/88 e na **Lei nº 3.365/1941** (Lei Geral de Desapropriações), para viabilizar a doação;

d) **REGULARIZAÇÃO CADASTRAL** do imóvel junto ao **Sistema de Gestão de Imóveis da União - SGIU/SIPROJ** e ao **INCRA**, com a devida atualização do **Cadastro Nacional de Imóveis Rurais - CNIR**.

---

## VI - DAS MEDIDAS COMPLEMENTARES SOLICITADAS

### 6.1. Da Avaliação do Imóvel

Requer seja determinada a **avaliação do imóvel** por meio de:

- **Laudo de Avaliação** elaborado por profissional habilitado (engenheiro civil ou arquiteto), conforme **NBR 14.653** da ABNT;
- **Certidão de Inteiro Teor da Matrícula** atualizada junto ao Cartório de Registro de Imóveis de Crateús/CE;
- **Certidão Negativa de Ônus Reais** e **Certidão Negativa de Ações Reipersecutórias**;
- **Levantamento planialtimétrico** com georreferenciamento.

### 6.2. Da Condição do Imóvel

O Município de Crateús/CE informa:

a) O terreno encontra-se **baldio e sem edificação**, não oferecendo utilidade para a gestão do INSS;

b) O imóvel está **localizado em área urbana** e **dotado de infraestrutura básica** (energia elétrica, água, saneamento);

c) A área encontra-se **desocupada**, sem qualquer tipo de invasão ou ocupação irregular;

d) O IPASE, bairro onde está localizado o terreno, possui **carência severa** de equipamentos públicos educacionais.

### 6.3. Do Termo de Doação e Destinação

Requer, ainda, que a doação seja formalizada mediante **Termo de Doação** com as seguintes cláusulas:

a) **Cláusula de Reversão**: No caso de o Município não utilizar o imóvel para fins educacionais no prazo de **24 (vinte e quatro) meses**, o imóvel retornará ao patrimônio da União;

b) **Cláusula de Inalienabilidade**: O Município não poderá alienar o imóvel sem autorização da União;

c) **Cláusula de Destinação Exclusiva**: O imóvel será utilizado exclusivamente para ampliação da Escola de Cidadania Airamt Veras;

d) **Cláusula de Vedação de Oneração**: O Município não poderá gravar o imóvel com ônus reais, HIPOTECAS, alienações fiduciárias ou quaisquer gravames sem autorização federal.

---

## VII - DO VALOR DA CAUSA

Atribui-se à presente causa o valor de **R$ ___ (__)**, correspondente à **estimativa do valor venal do imóvel** a ser doado, conforme laudo de avaliação a ser produzido.

---

## VIII - DOS DOCUMENTOS ANEXOS

A presente Petição é instruída com os seguintes documentos:

1. **Cópia da Lei Municipal nº ___, de ___/___/____**, que autoriza o Chefe do Executivo Municipal a requerer a doação do imóvel;

2. **Cópia do Decreto Municipal nº ___, de ___/___/____**, que estrutura a Secretaria Municipal de Educação;

3. **Certidão de Inteiro Teor da Matrícula** do imóvel junto ao Cartório de Registro de Imóveis de Crateús/CE;

4. **Certidão Negativa de Débitos** do Município de Crateús/CE;

5. **Ofício da Secretaria Municipal de Educação** solicitando a ampliação da Escola de Cidadania Airamt Veras;

6. **Relatório Fotográfico** do terreno e da escola atual;

7. **Croqui de Localização** do imóvel, com indicação de coordenadas geográficas;

8. **Certidão de Denominação e Endereçamento** da escola;

9. **Lista nominal de alunos** em espera para matrícula;

10. **Dados Populacionais** do Bairro IPASE, com base no IBGE/Censo 2022;

11. **Plano de Ampliação da Escola** elaborado pela Secretaria Municipal de Educação;

12. **Orçamento Estimado** para a obra de ampliação;

13. **Declaração de Disponibilidade Orçamentária** para execução da obra;

14. **Termo de Compromisso** de aplicação do imóvel para fins educacionais;

15. **Procuração** outorgando poderes ao(a) advogado(a) subscritor(a) da presente petição.

---

## IX - DAS PROVAS

Protesta provar o alegado por todos os meios de prova em direito admitidos, especialmente:

- **Prova documental** (documentos anexos);
- **Prova pericial** (avaliação do imóvel);
- **Prova testemunhal** (depoimento de autoridades educacionais e moradores do bairro);
- **Prova técnica** (levantamento planialtimétrico e georreferenciamento);
- **Diligências perante o Cartório de Registro de Imóveis**, o INCRA e a Secretaria do Patrimônio da União - SPU;
- **Informes em audiência** com representantes da União, Estado e Município.

---

## X - DAS DISPOSIÇÕES FINAIS

O Município de Crateús/CE reassume o compromisso de:

a) **Executar a obra de ampliação** no prazo máximo de **24 (vinte e quatro) meses** após a formalização da doação;

b) **Investir recursos próprios** na ordem de **R$ ___ (___)** para a execução da ampliação;

c) **Manter a escola em funcionamento** com qualidade, observando os padrões do FUNDEB e as diretrizes do PNE;

d) **Prestar contas** à União sobre a aplicação do imóvel doado;

e) **Zelar pelo patrimônio público federal** que será incorporado ao patrimônio municipal.

A presente solicitação representa o compromisso da **gestão municipal 2021-2024** com a **educação de qualidade** e a **construção de uma cidade mais justa e solidária**, onde todas as crianças e jovens tenham acesso a uma educação que promova o **desenvolvimento integral** e a **cidadania plena**.

---

## XI - DO PEDIDO FINAL

Ante o exposto, considerando:

- A **primazia da educação** como direito fundamental consagrado na Constituição Federal;
- A **função social da propriedade** e o dever de utilizar bens públicos em prol do interesse da coletividade;
- A **demanda reprimida** por vagas na rede municipal de educação no Bairro IPASE;
- A **carência de infraestrutura** da Escola de Cidadania Airamt Veras;
- A **legalidade da doação** para fins educacionais, nos termos da legislação vigente;
- A **jurisprudência consolidada** do STF e STJ sobre a matéria;

Requer a **VOSSAS EXCELÊNCIAS** o **DEFERIMENTO INTEGRAL** da presente Petição, com o **ENCAAMINHAMENTO URGENTE** do requerimento ao **Ministério da Economia** para que seja **AUTORIZADA A DOAÇÃO** do terreno de propriedade do INSS ao **MUNICÍPIO DE CRATEÚS/CE**, para fins de **AMPLIAÇÃO DA ESCOLA DE CIDADANIA AIRAMT VERAS**.

---

Termos em que,

Pede deferimento.

**Crateús/CE, ___ de ___ de 2024.**

&nbsp;

---

**__________________________________________**
**[NOME DO PREFEITO MUNICIPAL]**
Prefeito Municipal de Crateús/CE

&nbsp;

---

**__________________________________________**
**[NOME DO ADVOGADO(A)]**
**OAB/CE nº ___**
**Advogado(a) do Município de Crateús/CE**

---

## REFERÊNCIAS BIBLIOGRÁFICAS

### Legislação

- BRASIL. **Constituição Federal de 1988**. Disponível em: https://www.planalto.gov.br/ccivil_03/constituicao/constituicao.htm. Acesso em: mar. 2024.

- BRASIL. **Lei nº 9.636, de 15 de maio de 1998**. Dispõe sobre a administração, gestão e alienação dos bens imóveis de domínio da União. Disponível em: https://www.planalto.gov.br/ccivil_03/leis/l9636.htm. Acesso em: mar. 2024.

- BRASIL. **Decreto nº 9.760, de 11 de abril de 2019**. Aprova o regulamento para a gestão de bens imóveis de uso especial da União. Disponível em: https://www.planalto.gov.br/ccivil_03/_ato2019-2022/2019/decreto/d9760.htm. Acesso em: mar. 2024.

- BRASIL. **Lei nº 8.069, de 13 de julho de 1990** (Estatuto da Criança e do Adolescente). Disponível em: https://www.planalto.gov.br/ccivil_03/leis/l8069.htm. Acesso em: mar. 2024.

- BRASIL. **Lei nº 13.005, de 25 de junho de 2014** (Plano Nacional de Educação). Disponível em: https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2014/lei/l13005.htm. Acesso em: mar. 2024.

- BRASIL. **Lei nº 3.365, de 21 de junho de 1941** (Lei Geral de Desapropriações). Disponível em: https://www.planalto.gov.br/ccivil_03/decreto-lei/del3365.htm. Acesso em: mar. 2024.

### Jurisprudência

- BRASIL. Supremo Tribunal Federal. **ADI 2.649/DF**. Rel. Min. Ricardo Lewandowski. Tribunal Pleno, j. 16/04/2015.

- BRASIL. Supremo Tribunal Federal. **RE 635.739/SP**. Repercussão Geral - Tema 761.

- BRASIL. Supremo Tribunal Federal. **ADI 5.018/DF**. Rel. Min. Marco Aurélio. Tribunal Pleno, j. 25/03/2015.

- BRASIL. Superior Tribunal de Justiça. **REsp 1.323.183/RS**.

- BRASIL. Superior Tribunal de Justiça. **REsp 1.676.555/MT**.

### Doutrina

- BARROSO, Luís Roberto. **O Direito Constitucional e a Efetividade de suas Normas**. 9ª Edição. Rio de Janeiro: Renovar, 2011.

- MEIRELLES, Hely Lopes. **Direito Administrativo Brasileiro**. 42ª Edição. São Paulo: Malheiros Editores, 2016.

- DI PIETRO, Maria Sylvia Zanella. **Direito Administrativo**. 30ª Edição. Rio de Janeiro: Forense, 2017.

- SILVA, José Afonso da. **Curso de Direito Constitucional Positivo**. 37ª Edição. São Paulo: Malheiros Editores, 2014.

- SARLET, Ingo Wolfgang. **A Eficácia dos Direitos Fundamentais**. 12ª Edição. Porto Alegre: Livraria do Advogado, 2015.

---

## ANEXOS

1. [ ] Lei Municipal autorizativa
2. [ ] Decreto de estruturação da Secretaria de Educação
3. [ ] Certidão de Inteiro Teor da Matrícula
4. [ ] Certidão Negativa de Débitos
5. [ ] Ofício da Secretaria Municipal de Educação
6. [ ] Relatório Fotográfico
7. [ ] Croqui de Localização
8. [ ] Certidão de Denominação da Escola
9. [ ] Lista de Alunos em Espera
10. [ ] Dados Populacionais do IPASE
11. [ ] Plano de Ampliação
12. [ ] Orçamento Estimado
13. [ ] Declaração de Disponibilidade Orçamentária
14. [ ] Termo de Compromisso
15. [ ] Procuração

---

**DOCUMENTO GERADO PELO SISTEMA JURÍDICO BRASIL v3.0**
**MASWOS V5 NEXUS - REDE TRANSFORMER DE 34+ AGENTES PhD**
**Classificação: QUALIS A1 | Padrão: OAB/STF/STJ**
**Data de Geração: 20 de março de 2026**
