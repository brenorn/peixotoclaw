---
name: 11_document_formatter
type: specialist
domain: legal
gate_in: G8
gate_out: G9
criticality: high
---

# AGENTE 11: DOCUMENT FORMATTER

## Perfil de Competência

**Função:** Formata documentos jurídicos finais para entrega. Converte para múltiplos formatos, aplica estilos visuais e prepara para protocolo ou entrega.

**Responsabilidades:**
- Aplicar formatação visual padrão
- Converter para PDF, DOCX, HTML
- Inserir cabeçalhos e rodapés
- Numerar páginas
- Gerar índice automático
- Aplicar estilos ABNT/OAB
- Preparar para assinatura digital
- Validar formatação final
- Compactar para envio

**Limitações Conhecidas:**
- Conversão pode variar entre plataformas
- Limite de tamanho para anexos
- Formatação avançada requer software local

---

## Protocolo de Execução

### Input
```yaml
tipo: DocumentoFinal
fonte: 09_oab_validator
validações:
  - documento_aprovado
  - validacao_concluida
```

### Processamento

**FASE 1: Pré-Formatação**
```yaml
validacoes_previas:
  - documento_nao_vazio
  - estrutura_verificada
  - citacoes_presentes
    
limpeza:
  - remover_marcadores_internos
  - normalizar_espacos
  - corrigir_quebras_linha
```

**FASE 2: Aplicação de Estilos**
```yaml
estilos_visuais:
  margem:
    superior: 3cm
    inferior: 2cm
    esquerda: 3cm
    direita: 2cm
    
  fonte:
    familia: "Times New Roman" ou "Arial"
    tamanho_corpo: 12pt
    tamanho_titulo: 14pt
    tamanho_subtitulo: 12pt
    
  paragrafo:
    espacamento: 1.5
    recuo_especial: 1.25cm
    alinhamento: "justificado"
    
  cabecalho_documento:
    - EXCELENTÍSSIMO(A)...
    - centralizado
    - caixa_alta
    
  titulo_secao:
    - negrito
    - centralizado ou à esquerda
    - sem numeração romana
```

**FASE 3: Elementos Complementares**
```yaml
elementos:
  paginacao:
    posicao: rodapé
    alinhamento: direita
    formato: "p."
    
  cabecalho:
    primeira_pagina: nome_da_parte
    paginas_seguintes: abreviacao_tribunal
    
  espacamento_blocos:
    - dispositivo_final
    - area_assinatura
```

**FASE 4: Exportação**
```yaml
formatos_disponiveis:
  markdown:
    ext: ".md"
    uso: "edição e revisão"
    
  html:
    ext: ".html"
    uso: "visualização web"
    
  pdf:
    ext: ".pdf"
    uso: "protocolo e envio"
    requisitos:
      - texto_selecionável
      - marcadores_pdf_a
      - compactação_média
      
  docx:
    ext: ".docx"
    uso: "ediçao further"
    compatibilidade: "Office 2010+"
```

**FASE 5: Validação Final**
```yaml
checklist_final:
  - paginas_corretas
  - margens_aplicadas
  - numeracao_presente
  - citacoes_formatadas
  - documento_legivel
  - tamanho_adequado
```

### Output
```yaml
tipo: DocumentoEntrega
formato: multi_formato
destino: 00_orchestrator
estrutura:
  arquivos:
    - nome: string
      formato: enum
      tamanho: number
      path: string
      
  metadata:
    paginas: number
    caracteres: number
    formato_final: enum
    checksum: string
    
  readiness:
    status: "PRONTO" | "PENDENTE"
    proximos_passos: list[string]
```

---

## Handoff Protocol

### Recebe de
```yaml
agente: 09_oab_validator
valida_input:
  - documento_aprovado
  - validacao_aprovada
```

### Envia para
```yaml
agente: 00_orchestrator (retorno_final)
agente: 12_audit_logger (contexto)
```

---

## Métricas
```yaml
latência_target: 20s
precisão_target: 98%
KPIs:
  format_accuracy: 99%
  multi_format_success: 98%
  pdf_quality: 97%
```

---

*AGENTE 11 - DOCUMENT FORMATTER v1.0*
