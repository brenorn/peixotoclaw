# AGENTE N18: DOCTRINE VALIDATOR
## Validação Doutrinária - Autores e Obras

**ID:** N18
**Sistema:** juridico-brasil-nexus
**Camada:** Analysis (Fase 3-4)
**Gate:** G3
**Função:** Valida referências doutrinárias com autores reconhecidos

---

## CLASSIFICAÇÃO DE AUTORES

### Nível Excelência

```yaml
niveis:
  phd_summa:
    criterio: "Reconhecimento nacional e internacional"
    exemplos:
      - "Celso Duvivier de Oliveira Albuquerque"
      - "Luis Roberto Barroso"
      - "Ingo Wolfgang Sarlet"
      
  phd:
    criterio: "Reconhecimento nacional"
    exemplos:
      - "Carlos Roberto Gonçalves"
      - "Maria Helena Diniz"
      - "Vicente Greco Filho"
```

---

## ÍNDICE DE AUTORES POR ÁREA

### Direito Constitucional
```yaml
constitucional:
  classicos:
    - "Barroso, Luis Roberto"
    - "Mendes, Gilmar Ferreira"
    - "Silva, José Afonso da"
    - "Lenza, Pedro"
    - "Sarlet, Ingo Wolfgang"
```

### Direito Civil
```yaml
civil:
  - "Pereira, Caio Mário da Silva"
  - "Gonçalves, Carlos Roberto"
  - "Diniz, Maria Helena"
  - "Venosa, Sílvio de Salvo"
  - "Gagliano, Pablo Stolze"
```

### Direito Administrativo
```yaml
administrativo:
  - "Di Pietro, Maria Sylvia Zanella"
  - "Medauar, Odete"
  - "Carvalho Filho, José dos Santos"
  - "Figueiredo, Lúcia Valle"
```

---

## REGRAS DE VALIDAÇÃO

```
Para cada REFERENCIA:

□ Autor existe na literatura jurídica?
□ Obra foi publicada no ano citado?
□ Obra é reconhecida na área?
□ Citação está no contexto correto?
□ Não há referência a obra genérica?

SE autor não reconhecido:
→ FLAG como "Necessita verificação"
→ Recomendar fonte alternativa
```

---

## OUTPUT

```json
{
  "doctrine_validation": {
    "id": "uuid",
    "data": "YYYY-MM-DD",
    "total_referencias": 25,
    "validas": 24,
    "invalidas": 1,
    "detalhes": [
      {
        "autor": "Luis Roberto Barroso",
        "obra": "Curso de Direito Constitucional"
        "ano": 2012,
        "editora": "Saraiva",
        "status": "VALIDA",
        "nivel": "PHD_SUMMA"
      }
    ],
    "score_conformidade": 96
  }
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N18 - Doctrine Validator
**STATUS:** OPERACIONAL ✅
