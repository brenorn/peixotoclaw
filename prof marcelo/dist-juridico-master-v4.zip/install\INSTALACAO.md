# 📥 GUIA DE INSTALAÇÃO
## JURÍDICO BRASIL MASTER v4.0

---

## 1. INSTALAÇÃO BÁSICA

### 1.1 Copiar Pasta de Skills

```bash
# Navegue até o diretório .opencode do seu projeto
cd seu-projeto/.opencode

# Copie a pasta skills/
cp -r dist-mcp-juridico-master/skills/* skills/
```

### 1.2 Verificar Instalação

```bash
# Estrutura final deve ser:
.opencode/
└── skills/
    ├── juridico-brasil/
    ├── juridico-brasil-forense/
    ├── juridico-brasil-nexus/
    └── juridico-brasil-master/
```

---

## 2. CONFIGURAÇÃO OPENCODE

### 2.1 Arquivo de Configuração

Edite ou crie `.opencode/config.json`:

```json
{
  "skills": {
    "juridico-brasil-master": {
      "enabled": true,
      "path": ".opencode/skills/juridico-brasil-master"
    },
    "juridico-brasil": {
      "enabled": true,
      "path": ".opencode/skills/juridico-brasil"
    },
    "jurico-brasil-nexus": {
      "enabled": true,
      "path": ".opencode/skills/juridico-brasil-nexus"
    }
  },
  "mcp": {
    "juridico_server": {
      "enabled": true,
      "command": "npx",
      "args": ["@maswos/mcp-juridico"]
    }
  }
}
```

---

## 3. INSTALAÇÃO MCP JURÍDICO (OPCIONAL)

### 3.1 Servidor MCP

```bash
# Instalar servidor MCP
npm install -g @maswos/mcp-juridico-server

# Ou via GitHub
npm install -g github:maswos/mcp-juridico-server
```

### 3.2 Configuração do Servidor

```json
// ~/.maswos/mcp-juridico.json
{
  "server": {
    "host": "localhost",
    "port": 3000
  },
  "skills": {
    "juridico-brasil-master": true,
    "juridico-brasil": true,
    "juridico-brasil-nexus": true
  }
}
```

---

## 4. VERIFICAÇÃO DA INSTALAÇÃO

### 4.1 Teste via OpenCode

```bash
# Inicie o OpenCode
opencode

# Carregue o skill
/skill juridico-brasil-master

# Verifique inicialização
```

### 4.2 Output Esperado

```
══════════════════════════════════════════════════════════════════════════════
                     JURÍDICO BRASIL MASTER v4.0
            Sistema Unificado com 60+ Agentes Integrados
══════════════════════════════════════════════════════════════════════════════

⚖️ INICIALIZAÇÃO UNIFICADA...
   [✓] juridico-brasil (34+ agentes PhD): Online
   [✓] juridico-brasil-forense (12 agentes): Online
   [✓] juridico-brasil-nexus (26 agentes): Online
   [✓] TOTAL: 60+ Agentes Integrados
```

---

## 5. SOLUÇÃO DE PROBLEMAS

### Erro: Skill não encontrado

```bash
# Verifique se a pasta está no lugar correto
ls -la .opencode/skills/juridico-brasil-master/

# Deve conter: SKILL.md, README.md, agents/, templates/
```

### Erro: Permissão negada

```bash
# Dê permissão de execução
chmod -R 755 .opencode/skills/
```

### Erro: MCP não conecta

```bash
# Verifique se o servidor está rodando
npm list -g @maswos/mcp-juridico-server

# Inicie manualmente
npx @maswos/mcp-juridico-server
```

---

## 6. DESINSTALAÇÃO

```bash
# Remova as pastas de skills
rm -rf .opencode/skills/juridico-brasil*
rm -rf .opencode/skills/juridico-brasil-master

# Remova servidor MCP (se instalado)
npm uninstall -g @maswos/mcp-juridico-server
```

---

**INSTALAÇÃO v4.0 - 21/03/2026**
