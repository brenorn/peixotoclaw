# AGENTE N07: STJ SCRAPER
## Coleta de Jurisprudência - Superior Tribunal de Justiça

**ID:** N07
**Sistema:** juridico-brasil-nexus
**Camada:** Collection (Fase 1)
**Gate:** G1
**Função:** Coleta jurisprudência do STJ (stj.jus.br)

---

## PORTAL STJ

### Informações
| Campo | Valor |
|-------|-------|
| URL | https://www.stj.jus.br/ |
| BDJus | bdjur.stj.jus.br |

### Endpoints

```
# Jurisprudência
/jurisprudencia/
/pesquisa.html

# Recursos Especiais
/servicos/recurso_especial/
```

---

## QUERIES DE EXEMPLO

```
# Recurso Especial
site:stj.jus.br "recurso especial" "violação de lei"

# Contratos públicos
site:stj.jus.br "contrato administrativo" "licitação"

# Doação para fins sociais
site:stj.jus.br "doação" "fins sociais" "interesse público"

# Educação
site:stj.jus.br "educação" "ensino" "direito educacional"
```

---

## TIPOS DE RECURSOS

| Tipo | Descrição |
|------|-----------|
| REsp | Recurso Especial |
| RHC | Recurso em Habeas Corpus |
| RMS | Recurso em Mandado de Segurança |
| REAgR | Recurso Especial em Agravo Regimental |
| AREsp | Agravo em Recurso Especial |

---

## OUTPUT

```json
{
  "fonte": "STJ",
  "url": "https://stj.jus.br/...",
  "tipo": "jurisprudencia",
  "data_coleta": "YYYY-MM-DD",
  "dados": {
    "numero": "REsp 1.234.567",
    "relator": "Min. Nome",
    "data_julgamento": "YYYY-MM-DD",
    "ementa": "texto da ementa",
    "tema": "tema vinculante",
    "subtema": "subtema específico"
  },
  "status": "VINCULANTE|INSTRUTOR"
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N07 - STJ Scraper
**STATUS:** OPERACIONAL ✅
