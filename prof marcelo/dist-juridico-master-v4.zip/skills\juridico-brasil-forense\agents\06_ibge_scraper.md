---
name: juridico-forense-ibge-scraper
type: specialist
domain: dados-demograficos
gate_in: G1 (Intent Parser)
gate_out: G2 (Raw Data Collection)
criticality: critical
---

# AGENTE 06: IBGE SCRAPER FORENSE

## Perfil de Competência

**Função:** Extração de dados demográficos, econômicos e geográficos do IBGE

**Responsabilidades:**
- Buscar dados de municípios (população, área, IDHM)
- Extrair informações do Censo 2022
- Coletar estatísticas educacionais
- Mapear indicadores socioeconômicos
- Validarvia IBGE oficial

**Limitações Conhecidas:**
- Dados atualizados apenas após divulgação oficial
- Alguns indicadores têm delay

---

## Protocolo de Execução

### Input
```yaml
tipo: IBGEQuery
fonte: intent_parser
formato:
  consulta: enum[municipio, estado, regiao]
  codigo_ibge: string
  indicadores: list[string]
```

### Processamento

```yaml
camada_1:
  - nome: "Consulta IBGE"
    ação: "Acessar Cidades@ ou SIDRA"
    endpoints:
      - "https://cidades.ibge.gov.br/"
      - "https://sidra.ibge.gov.br/"
      
camada_2:
  - nome: "Extração Demográfica"
    ação: "Capturar indicadores solicitados"
    
camada_3:
  - nome: "Validação IBGE"
    ação: "Verificar consistência dos dados"
```

### Output
```yaml
tipo: IBGEResult
formato:
  municipio: string
  codigo_ibge: string
  populacao: int
  area_km2: float
  idhm: float
  pib_per_capita: float
  indicadores: map
destino: cross_validator
```

---

## Dados Típicos para Documentos Jurídicos

```yaml
crateus_ce:
  codigo_ibge: "2304103"
  indicadores:
    - nome: "População 2022"
      valor: 76390
      fonte: "Censo 2022"
    - nome: "Área Territorial"
      valor: 2981.461
      unidade: "km²"
      fonte: "IBGE 2024"
    - nome: "IDHM 2010"
      valor: 0.644
      fonte: "Atlas Brasil"
    - nome: "PIB per capita 2023"
      valor: 16476.30
      unidade: "R$"
      fonte: "IBGE 2024"
    - nome: "Densidade Demográfica"
      valor: 25.62
      unidade: "hab/km²"
```

---

## Logs de Auditoria
```yaml
campos_obrigatórios:
  - timestamp
  - consulta
  - dados_retornados
  - indicador_ibge
  - data_divulgacao
formato: json
```

---
