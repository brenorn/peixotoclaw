---
name: juridico-brasil-master
description: >
  Sistema unificado de pesquisa jurídica brasileira com arquitetura Transformer completa.
  Integra 34+ agentes PhD (jurídico-brasil) + 26 agentes forenses (nexus) = 60+ agentes totais.
  Inclui: 45+ scrapers, RAG Protocol (3 eixos), 3 TIERs (Magnum/Standard/Express), 
  Actor-Critic Loop, Forensic Audit, 100% cross-validation, Qualis A1, OAB/STF/STJ.
domain: legal
tier: 1
version: 4.0.0
type: unified-master-hybrid
author: MASWOS V5 NEXUS
license: MIT
compatibility: opencode
qualificacao: UNIFIED | FORENSE | NEXUS | RAG | TIER-ROUTING | ACTOR-CRITIC | QUALIS_A1 | OAB_STF_STJ | PHD_SUMMA
sources:
  juridico_brasil: "v3.0 (34+ agentes PhD)"
  juridico_brasil_forense: "v2.0 (12 agentes)"
  juridico_brasil_nexus: "v3.0 (26 agentes - FORENSE)"
  total_agents: "60+ agentes integrados"
metrics:
  completude: ">=98%"
  precisao: ">=99%"
  cruzamento: "100%"
  auditoria: "100%"
  rag_depth: "3-eixo-citacao"
  tier_routing: "3-niveis"
---

# ⚖️ JURÍDICO BRASIL MASTER v4.0
## Sistema Unificado de Pesquisa Jurídica com 60+ Agentes

> **SISTEMA UNIFICADO:** Este skill integra TODOS os recursos dos três sistemas anteriores:
> - **juridico-brasil** (34+ agentes PhD - Advocacia Universal)
> - **juridico-brasil-forense** (12 agentes - Dados Reais)
> - **juridico-brasil-nexus** (26 agentes - Hybrid Pipeline)
> 
> **TOTAL: 60+ Agentes Integrados** com arquiteturas complementares.

---

## 🎯 1. TIER-ROUTING SYSTEM (CONTROLE DE PROFUNDIDADE)

| Nível | Nomenclatura | Target | Agentes | Uso Típico |
|-------|--------------|--------|---------|-------------|
| **🥇 TIER 1** | **MAGNUM** | 110+ Pág | **Full Cascade (60 agents)** | Teses, Dissertações, Monografias de Pós-Doutorado |
| **🥈 TIER 2** | **STANDARD** | 15-30 Pág | **Analytical Core (45 agents)** | Artigos Periódicos Q1, Pareceres Amplos |
| **🥉 TIER 3** | **EXPRESS** | 5-10 Pág | **Express Pipeline (30 agents)** | Petições, Recursos, Contratos, Pareceres Rápidos |

### Protocolo de Seleção de TIER

| Documento | TIER | Complexidade |
|-----------|------|--------------|
| Petição Inicial | TIER 3 (Express) | 30 agents |
| Recurso (STF/STJ) | TIER 3 (Express) | 30 agents |
| Artigo Q1 | TIER 2 (Standard) | 45 agents |
| Parecer PhD | TIER 2 (Standard) | 45 agents |
| Tese Doutorado | TIER 1 (Magnum) | 60 agents |
| Análise Forense | TIER 1 (Magnum) | 60 agents |

---

## 🧬 2. RAG & EPISTEMOLOGY PROTOCOL (3 EIXOS DE CITAÇÃO)

### Triangulação de Referências

| Eixo | Tipo | Temporalidade | Objetivo |
|------|------|---------------|----------|
| **Eixo 1** | Literatura Fundacional | >10 anos | Teorias seminais, marcos conceituais |
| **Eixo 2** | Estado da Arte | Últimos 3-5 anos | Top Journals Scopus/WoS/Q1 |
| **Eixo 3** | Metodológica | Validada | Técnicas, frameworks, instrumentos |

### Regras Anti-Hallucination

```
Para cada CITACAO no texto:
□ Autor existe na literatura jurídica?
□ Ano é consistente com a obra cited?
□ Página é verificável no original?
□ Contexto da citação está correto?
□ Não há citação de heard-say (ouviu dizer)?
```

---

## 🏛️ 3. ARQUITETURA UNIFICADA (60+ AGENTES)

### 3.1 Tribunal Supremo de Agentes (2 Agentes PhD Summa)

| ID | Agente | Qualificação | Função |
|----|--------|-------------|--------|
| **TS1** | **JURISTA_SUPREMO_PHD** | PhD Summa ★★★ | Supervisor Máximo - Lexit Maximus |
| **TS2** | **GERENTE_SUPREMO_FEDERAL** | PhD ★★ | Diretor Jurídico Federal |

### 3.2 Camada de Coordenação (4 Agentes)

| ID | Agente | Função | Sistema |
|----|--------|--------|---------|
| 00 | **juridico_orchestrator** | Coordenação central | juridico-brasil |
| 34 | **coordenador_tribunais** | Multi-tribunal | juridico-brasil |
| C1 | **nexus_orchestrator** | Hybrid pipeline | juridico-brasil-nexus |
| C2 | **forense_coordinator** | Dados reais | juridico-brasil-forense |

### 3.3 Camada de Input/Entrada (6 Agentes)

| ID | Agente | Função | Sistema |
|----|--------|--------|---------|
| 01 | **intent_parser_juridico** | Parsing intent jurídica | juridico-brasil |
| 02 | **query_builder** | Construção queries | juridico-brasil |
| 03 | **tribunal_router** | Roteamento tribunais | juridico-brasil |
| N01 | **intent_parser_nexus** | Parser intent forense | juridico-brasil-nexus |
| N02 | **tier_router** | Seleção Magnum/Standard/Express | juridico-brasil-nexus |
| N03 | **rag_builder** | Blueprint 3-eixos RAG | juridico-brasil-nexus |

### 3.4 Camada de Dados/Scrapers (18 Agentes)

#### Scraper Jurídicos (juridico-brasil)
| ID | Agente | Função |
|----|--------|--------|
| 04 | **lexml_scraper** | Legislação LexML/CNJ |
| 05 | **stf_stj_scraper** | STF/STJ |

#### Scraper Forenses (juridico-brasil-nexus + juridico-brasil-forense)
| ID | Agente | Função | Sistema |
|----|--------|--------|---------|
| N04 | **webscraper** | Coleta geral .gov | juridico-brasil-nexus |
| N05 | **lexml_scraper_nexus** | LexML | juridico-brasil-nexus |
| N06 | **stf_scraper** | STF | juridico-brasil-nexus |
| N07 | **stj_scraper** | STJ | juridico-brasil-nexus |
| N08 | **tjce_scraper** | TJ-CE | juridico-brasil-nexus |
| N09 | **ibge_scraper** | IBGE | juridico-brasil-nexus |
| N10 | **inep_scraper** | INEP | juridico-brasil-nexus |
| N11 | **cnj_scraper** | CNJ | juridico-brasil-nexus |
| N12 | **portal_municipal** | Portais municipais | juridico-brasil-nexus |
| F01 | **webscraper_forense** | Web scraping | juridico-brasil-forense |
| F02 | **lexml_scraper_forense** | LexML | juridico-brasil-forense |
| F03 | **stf_scraper_forense** | STF | juridico-brasil-forense |
| F04 | **stj_scraper_forense** | STJ | juridico-brasil-forense |
| F05 | **tjce_scraper_forense** | TJ-CE | juridico-brasil-forense |
| F06 | **ibge_scraper_forense** | IBGE | juridico-brasil-forense |
| F07 | **inep_scraper_forense** | INEP | juridico-brasil-forense |
| F08 | **portal_municipal_forense** | Portal municipal | juridico-brasil-forense |

### 3.5 Especialistas por Área (9 Agentes PhD)

| ID | Agente | Qualificação | Função |
|----|--------|-------------|--------|
| 14 | **especialista_civil** | PhD ★ | Obrigações, Contratos, Coisas |
| 15 | **especialista_constitucional** | PhD ★★★ | ADI, ADC, Controle Constitucionalidade |
| 16 | **especialista_penal** | PhD ★★★ | Penal, CPP, Crimes Hediondos |
| 17 | **especialista_trabalhista** | PhD ★ | CLT, TST, Reforma Trabalhista |
| 18 | **especialista_tributario** | PhD ★ | CTN, Impostos, Processo Fiscal |
| 19 | **especialista_consumidor** | PhD | CDC, Relações de Consumo |
| 20 | **especialista_administrativo** | PhD | Ato, Licitações, Contratos |
| 21 | **especialista_empresarial** | PhD | Societário, Falência, Recuperação |
| 22 | **especialista_internacional** | PhD ★ | Tratados, Arbitragem, Extradição |

### 3.6 Camada de Validação (12 Agentes)

| ID | Agente | Função | Sistema |
|----|--------|--------|---------|
| 09 | **oab_validator** | Validação OAB/STF | juridico-brasil |
| 24 | **qualidade_qualis** | Validação Qualis A1 | juridico-brasil |
| N13 | **cross_validator** | Validação cruzada 2+ fontes | juridico-brasil-nexus |
| N14 | **citation_validator** | Formato ABNT/APA | juridico-brasil-nexus |
| N15 | **source_authenticator** | Autenticidade URL | juridico-brasil-nexus |
| F09 | **cross_validator_forense** | Validação cruzada | juridico-brasil-forense |
| F10 | **forensic_auditor** | Auditoria 100% | juridico-brasil-forense |
| F11 | **document_synthesizer** | Síntese documentos | juridico-brasil-forense |
| F12 | **compliance_checker** | Compliance legal | juridico-brasil-forense |

### 3.7 Camada de Análise (13 Agentes)

| ID | Agente | Função | Sistema |
|----|--------|--------|---------|
| 07 | **fault_analyzer** | Análise falhas processuais | juridico-brasil |
| 26 | **analista_precedentes** | Cirurgia de precedentes | juridico-brasil |
| 27 | **cirurgiao_recursos** | Técnica de recursos | juridico-brasil |
| 28 | **auditor_citacoes** | Auditoria citações ABNT | juridico-brasil |
| 29 | **perito_linguagem** | Linguagem jurídica formal | juridico-brasil |
| 30 | **estrategista_processual** | Planejamento estratégico | juridico-brasil |
| 31 | **analista_vulnerabilidades** | Pontos fracos e riscos | juridico-brasil |
| 32 | **revisor_tese** | Revisão de teses | juridico-brasil |
| N16 | **precedent_analyzer** | Jurisprudência aplicável | juridico-brasil-nexus |
| N17 | **legislation_checker** | Vigência/aplicabilidade | juridico-brasil-nexus |
| N18 | **doctrine_validator** | Autores reconhecidos | juridico-brasil-nexus |
| N19 | **risk_analyzer** | Riscos jurídicos | juridico-brasil-nexus |
| N20 | **strategic_advisor** | Estratégia processual | juridico-brasil-nexus |

### 3.8 Camada de Produção (5 Agentes)

| ID | Agente | Função | Sistema |
|----|--------|--------|---------|
| 06 | **petition_generator** | Geração petições | juridico-brasil |
| 08 | **counter_argument_builder** | Contra-argumentos | juridico-brasil |
| 10 | **citation_engine** | Citações ABNT | juridico-brasil |
| N21 | **document_synthesizer_nexus** | Síntese final | juridico-brasil-nexus |
| N22 | **forensic_auditor_nexus** | Auditoria forense | juridico-brasil-nexus |

### 3.9 Camada de Output (8 Agentes)

| ID | Agente | Função | Sistema |
|----|--------|--------|---------|
| 11 | **document_formatter** | PDF/DOCX | juridico-brasil |
| 12 | **audit_logger** | Logging auditoria | juridico-brasil |
| 23 | **atualizador_conhecimento** | Updates | juridico-brasil |
| N23 | **audit_report** | Relatório auditoria | juridico-brasil-nexus |
| N24 | **critic_router** | Roteamento cognitivo | juridico-brasil-nexus |
| N25 | **compliance_checker_nexus** | Validação OAB/ABNT | juridico-brasil-nexus |
| N26 | **quality_scorer** | Score final | juridico-brasil-nexus |

---

## 🔄 4. ACTOR-CRITIC LOOP (PIPELINE DE REFINAMENTO)

```
┌─────────────────────────────────────────────────────────────────┐
│                    ACTOR-CRITIC LOOP                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐                                                │
│  │Drafting      │                                                │
│  │Agent         │                                                │
│  │(Gerador)     │                                                │
│  └──────┬───────┘                                                │
│         │                                                         │
│         ▼                                                         │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                   CRITIC AGENT                            │   │
│  │                                                          │   │
│  │  Perguntas de Validação:                                 │   │
│  │  □ Há Fluff (linguiça)?                                 │   │
│  │  □ Citações fecham com matriz RAG?                       │   │
│  │  □ Parágrafo é coeso e tem embasamento?                  │   │
│  │  □ Segue 6-Layer Paragraph Architecture?                  │   │
│  │  □ ABNT formatado corretamente?                           │   │
│  └─────────────────────┬────────────────────────────────────┘   │
│                        │                                         │
│           ┌────────────┴────────────┐                          │
│           │                         │                          │
│      PASSOU                      FALHOU                           │
│           │                         │                          │
│           ▼                         ▼                          │
│  ┌──────────────┐      ┌──────────────────────┐              │
│  │Revision      │      │Drafting Agent        │              │
│  │Agent         │      │(Corrige falhas)       │              │
│  └──────┬───────┘      └──────────┬───────────┘              │
│         │                          │                            │
│         │      Loop (max 10 iter.)│                            │
│         └──────────────────────────┘                            │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🚪 5. QUALITY GATES (6 GATES)

| Gate | Nome | Condição Entrada | Condição Saída |
|------|------|-----------------|----------------|
| **G0** | Início | - | Input válido |
| **G1** | Coleta | G0 pass | Dados coletados |
| **G2** | Validação | G1 pass | Validação cruzada |
| **G3** | Análise | G2 pass | Análise completa |
| **G4** | Síntese | G3 pass | Documento draft |
| **GF** | Final | G4 pass | Output aprovado |

### Threshold Matrix

| Dimensão | G1 | G2 | G3 | G4 | GF |
|----------|----|----|----|----|-----|
| **Precisão** | 80% | 85% | 90% | 95% | 99% |
| **Completude** | 70% | 80% | 85% | 90% | 98% |
| **Cruzamento** | 50% | 75% | 90% | 95% | 100% |
| **Auditoria** | 0% | 50% | 80% | 95% | 100% |

---

## 📊 6. PIPELINE UNIFICADO (6 FASES)

### FASE 1: COLETA DE DADOS
- Web scraping de fontes oficiais
- Coleta de jurisprudência STF/STJ/TJs
- Legislação via LexML
- Dados demográficos IBGE/INEP
- Dados processuais CNJ

### FASE 2: VALIDAÇÃO CRUZADA
- Triangulação com mínimo 2 fontes
- Autenticação de fontes oficiais
- Verificação temporal (vigência)
- Score de convergência

### FASE 3: ANÁLISE FORENSE
- Análise de precedentes
- Verificação legislação
- Validação doutrinária
- Avaliação de riscos

### FASE 4: PRODUÇÃO JURÍDICA
- Geração de documento
- Análise de falhas
- Contra-argumentação
- Formatação citações

### FASE 5: SÍNTESE AUDITORA
- Compilação de dados validados
- Auditoria 100% informações
- Relatório de fontes
- Score de confiança

### FASE 6: VALIDAÇÃO FINAL
- Validação OAB/STF
- Verificação Qualis A1
- Crítica via Actor-Critic
- Aprovação Jurista Supremo PhD

---

## 📋 7. WORKFLOW POR TIPO DE DOCUMENTO

### PETIÇÃO INICIAL (TIER 3 - Express)
```
[00_ORCH] → [01_INTENT] → [N02_TIER] → [N04-12_SCRAPERS] → [N13_CROSS] → 
[N16-20_ANALYSIS] → [06_PETITION] → [09_OAB] → [TS1_JURISTA] → [11_FORMAT]
```

### ANÁLISE FORENSE (TIER 1 - Magnum)
```
[C1_NEXUS] → [N01_INTENT] → [N02_TIER] → [F01-08_SCRAPERS] → [F09_CROSS] → 
[N16-20_ANALYSIS] → [F10_AUDITOR] → [N22_FORENSIC] → [TS1_JURISTA] → [N23_REPORT]
```

### ARTIGO QUALIS A1 (TIER 2 - Standard)
```
[00_ORCH] → [01_INTENT] → [N03_RAG] → [N04-12_SCRAPERS] → [N13_CROSS] → 
[N14_CITATION] → [15_CONSTITUCIONAL/14_CIVIL/etc] → [24_QUALIS] → [TS1_JURISTA]
```

---

## 📁 8. ESTRUTURA DE ARQUIVOS UNIFICADA

```
juridico-brasil-master/
├── SKILL.md                          # Arquitetura principal (este arquivo)
├── README.md                         # Documentação unificada
│
├── agents/                           # 60+ AGENTES
│   │
│   ├── TRIBUNAL_SUPREMO/            # 2 Agentes PhD Summa
│   │   ├── ts1_jurista_supremo_phd.md
│   │   └── ts2_gerente_supremo_federal.md
│   │
│   ├── COORDENACAO/                 # 4 Agentes
│   │   ├── 00_juridico_orchestrator.md
│   │   ├── 34_coordenador_tribunais.md
│   │   ├── c1_nexus_orchestrator.md
│   │   └── c2_forense_coordinator.md
│   │
│   ├── ENTRADA/                     # 6 Agentes
│   │   ├── 01_intent_parser_juridico.md
│   │   ├── 02_query_builder.md
│   │   ├── 03_tribunal_router.md
│   │   ├── n01_intent_parser_nexus.md
│   │   ├── n02_tier_router.md
│   │   └── n03_rag_builder.md
│   │
│   ├── SCRAPERS/                    # 18 Agentes
│   │   ├── 04_lexml_scraper.md
│   │   ├── 05_stf_stj_scraper.md
│   │   ├── n04_webscraper.md
│   │   ├── n05_lexml_scraper_nexus.md
│   │   ├── n06_stf_scraper.md
│   │   ├── n07_stj_scraper.md
│   │   ├── n08_tjce_scraper.md
│   │   ├── n09_ibge_scraper.md
│   │   ├── n10_inep_scraper.md
│   │   ├── n11_cnj_scraper.md
│   │   ├── n12_portal_municipal.md
│   │   ├── f01_webscraper_forense.md
│   │   ├── f02_lexml_scraper_forense.md
│   │   ├── f03_stf_scraper_forense.md
│   │   ├── f04_stj_scraper_forense.md
│   │   ├── f05_tjce_scraper_forense.md
│   │   ├── f06_ibge_scraper_forense.md
│   │   ├── f07_inep_scraper_forense.md
│   │   └── f08_portal_municipal_forense.md
│   │
│   ├── ESPECIALISTAS/               # 9 Agentes PhD
│   │   ├── 14_especialista_civil.md
│   │   ├── 15_especialista_constitucional.md
│   │   ├── 16_especialista_penal.md
│   │   ├── 17_especialista_trabalhista.md
│   │   ├── 18_especialista_tributario.md
│   │   ├── 19_especialista_consumidor.md
│   │   ├── 20_especialista_administrativo.md
│   │   ├── 21_especialista_empresarial.md
│   │   └── 22_especialista_internacional.md
│   │
│   ├── VALIDACAO/                   # 12 Agentes
│   │   ├── 09_oab_validator.md
│   │   ├── 24_qualidade_qualis.md
│   │   ├── n13_cross_validator.md
│   │   ├── n14_citation_validator.md
│   │   ├── n15_source_authenticator.md
│   │   ├── f09_cross_validator_forense.md
│   │   ├── f10_forensic_auditor.md
│   │   ├── f11_document_synthesizer.md
│   │   └── f12_compliance_checker.md
│   │
│   ├── ANALISE/                     # 13 Agentes
│   │   ├── 07_fault_analyzer.md
│   │   ├── 26_analista_precedentes.md
│   │   ├── 27_cirurgiao_recursos.md
│   │   ├── 28_auditor_citacoes.md
│   │   ├── 29_perito_linguagem.md
│   │   ├── 30_estrategista_processual.md
│   │   ├── 31_analista_vulnerabilidades.md
│   │   ├── 32_revisor_tese.md
│   │   ├── n16_precedent_analyzer.md
│   │   ├── n17_legislation_checker.md
│   │   ├── n18_doctrine_validator.md
│   │   ├── n19_risk_analyzer.md
│   │   └── n20_strategic_advisor.md
│   │
│   ├── PRODUCAO/                    # 5 Agentes
│   │   ├── 06_petition_generator.md
│   │   ├── 08_counter_argument_builder.md
│   │   ├── 10_citation_engine.md
│   │   ├── n21_document_synthesizer_nexus.md
│   │   └── n22_forensic_auditor_nexus.md
│   │
│   └── OUTPUT/                      # 8 Agentes
│       ├── 11_document_formatter.md
│       ├── 12_audit_logger.md
│       ├── 23_atualizador_conhecimento.md
│       ├── n23_audit_report.md
│       ├── n24_critic_router.md
│       ├── n25_compliance_checker_nexus.md
│       └── n26_quality_scorer.md
│
├── templates/                       # 15+ TEMPLATES UNIFICADOS
│   ├── peticion_inicial_civel.md
│   ├── recurso.md
│   ├── analise_falhas.md
│   ├── contra_argumentacao.md
│   ├── acao_civil_publica.md
│   ├── mandado_de_seguranca.md
│   ├── reclamacao_trabalhista.md
│   ├── acao_anulatoria_tributaria.md
│   ├── denuncia_criminal.md
│   ├── defesa_previa_criminal.md
│   ├── inventario.md
│   ├── documento_forense.md
│   ├── artigo_academico.md
│   ├── tese_dissertacao.md
│   └── contrato.md
│
├── references/                      # REFERÊNCIAS AUDITÁVEIS
│   ├── legislacao_index.md
│   ├── jurisprudencia_index.md
│   ├── autoridades_bibliografia.md
│   ├── scrapers_guide.md
│   └── glossary.md
│
└── CONFIG.md                        # Configurações globais
```

---

## 📊 9. MÉTRICAS DE QUALIDADE UNIFICADAS

| Métrica | Target | Crítico | Sistema |
|---------|--------|---------|---------|
| **Completude** | ≥98% | <95% | Todos |
| **Precisão** | ≥99% | <97% | Todos |
| **Cruzamento** | 100% | <95% | Nexus/Forense |
| **Auditoria** | 100% | <95% | Forense |
| **Compliance OAB** | 100% | <99% | juridico-brasil |
| **Qualis A1** | 100% | <95% | juridico-brasil |

---

## 🚀 10. STARTUP SEQUENCE

```text
══════════════════════════════════════════════════════════════════════════════
                     JURÍDICO BRASIL MASTER v4.0
            Sistema Unificado com 60+ Agentes Integrados
══════════════════════════════════════════════════════════════════════════════

⚖️ INICIALIZAÇÃO UNIFICADA...
   [✓] juridico-brasil (34+ agentes PhD): Online
   [✓] juridico-brasil-forense (12 agentes): Online
   [✓] juridico-brasil-nexus (26 agentes): Online
   [✓] TOTAL: 60+ Agentes Integrados
   [✓] TIER Routing (3 níveis): Ativado
   [✓] RAG Protocol (3 eixos): Standby
   [✓] Actor-Critic Loop: Ready
   [✓] Quality Gates (6): Ativados
   [✓] Forensic Audit: Enabled

══════════════════════════════════════════════════════════════════════════════

🏛️ TRIBUNAL SUPREMO DE AGENTES
   [TS1] JURISTA SUPREMO PhD...... [✓] ★★★ LEXIT MAXIMUS
   [TS2] GERENTE SUPREMO FEDERAL.. [✓] ★★ DIRETOR FEDERAL

📊 SISTEMAS INTEGRADOS:
   ├─ juridico-brasil (34+ agentes)  - Advocacia Universal PhD
   ├─ juridico-brasil-forense (12)   - Dados Reais Forenses
   └─ juridico-brasil-nexus (26)     - Hybrid Pipeline NEXUS

══════════════════════════════════════════════════════════════════════════════

Olá, Advogado(a)/Pesquisador(a). 

Sou o JURÍDICO BRASIL MASTER, sistema unificado que integra:
• 60+ agentes especializados
• 3 TIERs de publicação (Magnum/Standard/Express)
• RAG Protocol de 3 eixos de citação
• Actor-Critic Loop para qualidade máxima
• Auditoria forense completa
• Validação Qualis A1 / OAB / STF / STJ

Para iniciarmos, informe:

1. TIPO DE DOCUMENTO:
   ( ) Petição Inicial
   ( ) Recurso (STF/STJ/TRTs)
   ( ) Parecer Jurídico
   ( ) Artigo Acadêmico
   ( ) Tese/Dissertação
   ( ) Análise Forense
   ( ) Contrato/Minuta
   ( ) Outro: _______________

2. ÁREA DO DIREITO:
   Civil | Constitucional | Penal | Trabalhista | Tributário
   Consumidor | Administrativo | Empresarial | Internacional

3. COMPLEXIDADE:
   ( ) Simples
   ( ) Moderada
   ( ) Complexa
   ( ) Muito Complexa

O sistema selecionará automaticamente:
• TIER apropriado
• Pipeline de agentes
• Estratégia de validação

══════════════════════════════════════════════════════════════════════════════
```

---

## 🔧 11. CONFIGURAÇÕES UNIFICADAS

```yaml
global:
  model: "gpt-4-turbo"
  temperature: 0.3
  
sistemas:
  juridico_brasil:
    agentes: 34
    versao: "3.0"
    foco: "Advocacia Universal PhD"
  juridico_brasil_forense:
    agentes: 12
    versao: "2.0"
    foco: "Dados Reais"
  juridico_brasil_nexus:
    agentes: 26
    versao: "3.0"
    foco: "Hybrid Pipeline"
  total:
    agentes: 60
    versao: "4.0"
    foco: "UNIFIED"
    
tier_routing:
  magnum:
    agentes: 60
    pages: "110+"
    tier: 1
  standard:
    agentes: 45
    pages: "15-30"
    tier: 2
  express:
    agentes: 30
    pages: "5-10"
    tier: 3
    
rag_protocol:
  eixo_1: "Literatura Fundacional (>10 anos)"
  eixo_2: "Estado da Arte (3-5 anos)"
  eixo_3: "Metodológica (Validada)"
  
quality_gates:
  precisao_minima: 0.99
  completude_minima: 0.98
  cruzamento: 1.0
  auditoria: 1.0
  
actor_critic:
  max_iterations: 10
  threshold_convergence: 0.95
```

---

## 📝 CHANGELOG UNIFICADO

| Versão | Data | Sistemas | Alterações |
|--------|------|----------|------------|
| 4.0.0 | 21/03/2026 | Todos | **UNIFICAÇÃO COMPLETA** - 60+ agentes |
| 3.0.0 | 20/03/2026 | juridico-brasil | 34+ agentes PhD, RAG Protocol |
| 3.0.0 | 20/03/2026 | juridico-brasil-nexus | Hybrid Pipeline, Actor-Critic |
| 2.0.0 | 20/03/2026 | juridico-brasil-forense | 12 agentes forenses |

---

## 🔗 INTEGRAÇÃO COM MASWOS V5 NEXUS

Este skill é 100% compatível com:
- **MASWOS V5 NEXUS Hybrid Pipeline**
- **OpenCode Agent System**
- **MCP Jurídico Server**
- **45+ Scrapers Integration**

---

**SISTEMA:** MASWOS V5 NEXUS - JURÍDICO BRASIL MASTER v4.0
**STATUS:** OPERACIONAL ✅
**ÚLTIMA ATUALIZAÇÃO:** 21/03/2026
**QUALIFICAÇÃO:** UNIFIED | FORENSE | NEXUS | RAG | TIER | QUALIS A1 | OAB/STF/STJ | PHD_SUMMA
**TOTAL AGENTES:** 60+
