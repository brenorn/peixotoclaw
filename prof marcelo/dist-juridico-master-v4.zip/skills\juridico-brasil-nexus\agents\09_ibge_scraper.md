# AGENTE N09: IBGE SCRAPER
## Coleta de Dados Demográficos e Socioeconômicos

**ID:** N09
**Sistema:** juridico-brasil-nexus
**Camada:** Collection (Fase 1)
**Gate:** G1
**Função:** Coleta dados do IBGE (ibge.gov.br, Cidades@, SIDRA)

---

## FONTES IBGE

| Fonte | URL | Dados |
|-------|-----|-------|
| IBGE Cidades | cidades.ibge.gov.br | Panorama municipal |
| SIDRA | sidra.ibge.gov.br | Bases de dados |
| IBGE Estados | estados.ibge.gov.br | Dados estaduais |
| Downloads | ftp.ibge.gov.br | Bases completas |

---

## DADOS COLETADOS POR MUNICÍPIO

### Dados Gerais
```yaml
municipio:
  - nome
  - codigo_ibge (7 dígitos)
  - mesorregiao
  - microrregiao
  - municipio_regiao
  - altitude
  - superficie_km2
```

### Demografia
```yaml
demografia:
  - populacao_estimada
  - populacao_censo
  - taxa_urbanizacao
  - densidade_demografica
```

### IDHM
```yaml
idhm:
  - idhm_geral
  - idhm_longevidade
  - idhm_educacao
  - idhm_renda
  - faixa_idhm
```

### Economia
```yaml
economia:
  - pib
  - pib_per_capita
  - pib_agropecuaria
  - pib_industria
  - pib_servicos
  - pib_gestao_publica
```

---

## QUERIES DE EXEMPLO

```
# Crateús Ceará
site:ibge.gov.br "Crateús" "Ceará" "IBGE"
site:cidades.ibge.gov.br "Crateús" "panorama"

# IDHM Crateús
site:ibge.gov.br "Crateús" "IDHM" "municipios"

# PIB per capita
site:ibge.gov.br "Ceará" "PIB" "per capita"
```

---

## OUTPUT

```json
{
  "fonte": "IBGE",
  "url": "https://cidades.ibge.gov.br/...",
  "tipo": "dados_demograficos",
  "data_coleta": "YYYY-MM-DD",
  "dados": {
    "municipio": "Crateús",
    "codigo_ibge": 2304103,
    "estado": "Ceará",
    "populacao_2022": 76390,
    "area_km2": 2981.461,
    "idhm_2010": 0.644,
    "pib_2020": 1260000000,
    "pib_per_capita_2020": 16476.30
  },
  "metadados": {
    "completude": 98,
    "precisao": 99,
    "data_referencia": "2022"
  }
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N09 - IBGE Scraper
**STATUS:** OPERACIONAL ✅
