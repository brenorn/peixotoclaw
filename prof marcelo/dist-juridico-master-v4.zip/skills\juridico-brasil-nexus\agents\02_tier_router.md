# AGENTE 02: TIER ROUTER
## Seleção de TIER - Magnum/Standard/Express

**ID:** N02
**Sistema:** juridico-brasil-nexus
**Camada:** Input/Entrada
**Gate:** G0
**Função:** Seleciona automaticamente o TIER apropriado baseado na complexidade

---

## SISTEMA DE TIER-ROUTING

### 1. Definição de TIERs

| TIER | Nome | Páginas | Agentes | Tempo Est. | Custo |
|------|------|---------|---------|------------|-------|
| **🥇 1** | MAGNUM | 110+ | 60 | 45-60min | Alto |
| **🥈 2** | STANDARD | 15-30 | 45 | 20-30min | Médio |
| **🥉 3** | EXPRESS | 5-10 | 30 | 10-15min | Baixo |

### 2. Critérios de Seleção

```yaml
tier_selection:
  magnum:
    documentos:
      - "tese de doutorado"
      - "dissertação de mestrado"
      - "monografia de pós-doutorado"
      - "parecer phD expandido"
      - "artigo completo Q1"
    complexidade:
      min: 8
      max: 10
    features:
      - "6-Layer Paragraph Architecture"
      - "Full RAG (3 eixos)"
      - "60 agentes"
      - "Actor-Critic Loop Completo"
      
  standard:
    documentos:
      - "artigo periódico Q1/Q2"
      - "parecer jurídico"
      - "memorial"
      - "análise jurisprudencial"
    complexidade:
      min: 4
      max: 7
    features:
      - "RAG (2 eixos)"
      - "45 agentes"
      - "Actor-Critic Loop Parcial"
      
  express:
    documentos:
      - "petição inicial"
      - "contestação"
      - "recurso simples"
      - "contrato"
      - "procuração"
    complexidade:
      min: 1
      max: 3
    features:
      - "RAG (1 eixo)"
      - "30 agentes"
      - "Validação OAB"
```

### 3. Algoritmo de Seleção

```
FUNÇÃO selecionar_tier(input):
    
    // Análise de complexidade
    complexidade = calcular_complexidade(input)
    
    // Análise de tipo de documento
    tipo = identificar_tipo_documento(input)
    
    // Análise de palavras-chave
    keywords = extrair_keywords(input)
    
    // Score baseado em regras
    score_magnum = 0
    score_standard = 0
    score_express = 0
    
    SE complexidade >= 8 OU contem(keywords, "tese", "doutorado"):
        score_magnum += 50
        
    SE complexidade >= 4 OU contem(keywords, "artigo", "parecer"):
        score_standard += 50
        
    SE complexidade <= 3 OU contem(keywords, "petição", "recurso"):
        score_express += 50
        
    // Seleção final
    SE score_magnum > score_standard E score_magnum > score_express:
        RETORNAR "magnum"
    SENAO SE score_standard > score_express:
        RETORNAR "standard"
    SENAO:
        RETORNAR "express"
```

### 4. Overrides Manuais

O usuário pode forçar um TIER específico:

```yaml
overrides:
  force_magnum:
    trigger: "/magnum" ou "modo completo"
  force_standard:
    trigger: "/standard" ou "modo médio"
  force_express:
    trigger: "/express" ou "modo rápido"
```

---

## CONFIGURAÇÃO DE PIPELINE POR TIER

### TIER 1 - MAGNUM (60 Agentes)

```
Pipeline Completo:
[00]Orch → [01]Intent → [02]Tier → [03]RAG → 
[04-12]Scrapers → [13-15]Validators → 
[16-20]Analysis → [21-23]Synthesis → 
[24-26]Output → [TS1]Jurista PhD
```

### TIER 2 - STANDARD (45 Agentes)

```
Pipeline Reduzido:
[01]Intent → [02]Tier → [04-08]Scrapers → 
[13-14]Validators → [16-18]Analysis → 
[21]Synthesis → [24-25]Output
```

### TIER 3 - EXPRESS (30 Agentes)

```
Pipeline Rápido:
[01]Intent → [04-06]Scrapers → 
[13]CrossValidator → [06]Petition → 
[09]OABValidator → [11]Formatter
```

---

## MATRIZ DE FEATURES POR TIER

| Feature | Magnum | Standard | Express |
|---------|--------|----------|---------|
| 6-Layer Paragraph | ✓ | ✗ | ✗ |
| RAG 3 Eixos | ✓ | ✓ | ✗ |
| Actor-Critic Loop | ✓ | ✓ | ✗ |
| 100+ Páginas | ✓ | ✗ | ✗ |
| Qualis A1 | ✓ | ✓ | ✗ |
| Validação OAB | ✓ | ✓ | ✓ |
| Cross-Validation 2+ | ✓ | ✓ | ✓ |
| Forensic Audit | ✓ | ✗ | ✗ |

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N02 - Tier Router
**STATUS:** OPERACIONAL ✅
