# AGENTE N04: WEBSCRAPER
## Coleta de Dados de Portais Web

**ID:** N04
**Sistema:** juridico-brasil-nexus
**Camada:** Collection (Fase 1)
**Gate:** G1
**Função:** Coleta dados de portais web governamentais e não-governamentais

---

## FONTES SUPORTADAS

### Governamentais (.gov.br)
| Fonte | URL | Dados |
|-------|-----|-------|
| Portal Brasil | gov.br | Informações gerais |
| Dados Abertos | dados.gov.br | Datasets |
| Transparência | portaldatransparencia.gov.br | Despesas, receitas |
| IBGE | ibge.gov.br | Demografia, economia |
| INEP | inep.gov.br | Educação |
| CNJ | cnj.jus.br | Justiça |

### Estaduais
| Fonte | URL | Dados |
|-------|-----|-------|
| Ceará | ceará.gov.br | Estado |
| Crateús | crateus.ce.gov.br | Município |
| IPECE | ipece.ce.gov.br | Indicadores CE |

---

## PROTOCOLO DE SCRAPING

### 1. Configuração

```yaml
scraper_config:
  user_agent: "MASWOS-NEXUS-Bot/1.0"
  timeout: 30
  retries: 3
  delay_between_requests: 2
  
headers:
  Accept: "text/html,application/xhtml+xml"
  Accept-Language: "pt-BR,pt;q=0.9"
```

### 2. Queries de Exemplo

```
# Dados municipais
site:crateus.ce.gov.br "prefeitura" "município" "dados"

# Dados abertos
site:dados.gov.br "Ceará" OR "crateús" dataset

# Transparência
site:portaldatransparencia.gov.br "Crateús" "prefeitura"
```

### 3. Output

```json
{
  "fonte": "nome_da_fonte",
  "url": "https://...",
  "tipo": "portal|api|scraping",
  "data_coleta": "YYYY-MM-DDTHH:MM:SSZ",
  "dados": {
    "campo1": "valor1",
    "campo2": "valor2"
  },
  "metadados": {
    "completude": 95,
    "precisao": 98,
    "status": "COLETADO"
  }
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N04 - WebScraper
**STATUS:** OPERACIONAL ✅
