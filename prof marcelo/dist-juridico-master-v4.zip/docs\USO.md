# 📖 GUIA DE USO
## JURÍDICO BRASIL MASTER v4.0

---

## 1. CARREGAMENTO DE SKILLS

### 1.1 Skill Principal (Recomendado)

```bash
/skill juridico-brasil-master
```

### 1.2 Skills Específicos

```bash
/skill juridico-brasil              # Advocacia universal
/skill juridico-brasil-forense      # Dados forenses
/skill juridico-brasil-nexus        # Hybrid pipeline
```

---

## 2. COMANDOS PRINCIPAIS

### 2.1 Geração de Petição

```
Use juridico-brasil para gerar petição inicial de danos morais 
contra banco X, comarca São Paulo, valor R$ 50.000
```

### 2.2 Análise de Precedente

```
Use juridico-brasil para analisar o RE 635.739 do STF 
sobre natureza da educação
```

### 2.3 Pesquisa Forense

```
Use juridico-brasil-nexus para pesquisar dados do município 
de Crateús/CE via IBGE e INEP
```

### 2.4 Artigo Acadêmico

```
Use juridico-brasil para gerar artigo Qualis A1 sobre 
responsabilidade civil digital
```

### 2.5 Auditoria de Documento

```
Use juridico-brasil-forense para auditar documento jurídico 
com validação de fontes
```

---

## 3. PARÂMETROS DE TIER

### TIER 1 - MAGNUM (110+ páginas)
```
TIER: magnum
→ Use para: Teses, dissertações, artigos completos
→ Agentes: 60+
→ Tempo: 45-60 min
```

### TIER 2 - STANDARD (15-30 páginas)
```
TIER: standard
→ Use para: Artigos Q1, pareceres amplos
→ Agentes: 45
→ Tempo: 20-30 min
```

### TIER 3 - EXPRESS (5-10 páginas)
```
TIER: express
→ Use para: Petições, recursos simples
→ Agentes: 30
→ Tempo: 10-15 min
```

---

## 4. FLUXO DE TRABALHO

### 4.1 Petição com Dados Forenses

```
1. Carregar skill
   /skill juridico-brasil-nexus

2. Informar tipo de documento
   "Gere petição inicial de doação de terreno INSS 
    para escola em Crateús/CE"

3. Sistema executa:
   → Intent Parser (identifica intent)
   → Tier Router (seleciona TIER)
   → Scrapers (coleta dados IBGE/INEP)
   → Cross Validator (valida 2+ fontes)
   → Petition Generator (gera documento)
   → OAB Validator (valida formato)
   → Quality Scorer (calcula score)

4. Output: Petição com score de qualidade
```

### 4.2 Artigo com RAG Protocol

```
1. Carregar skill
   /skill juridico-brasil-master

2. Informar tipo de documento
   "Gere artigo Qualis A1 sobre proteção de dados 
    pessoais no setor público"

3. Sistema executa:
   → Intent Parser
   → RAG Builder (3 eixos de citação)
   → Scrapers (doutrina + jurisprudência)
   → Article Generator
   → Citation Validator (ABNT)
   → Qualis Validator
   → Jurista Supremo PhD (supervisão)

4. Output: Artigo com score Qualis
```

---

## 5. VALIDAÇÃO E RATINGS

### Ratings de Qualidade

| Rating | Score | Significado |
|--------|-------|-------------|
| **Lexit Maximus** | 97-100 | Pronto para protocolo imediato |
| **Aprovado** | 90-96 | Pronto com ajustes mínimos |
| **Aprovado c/Ressalvas** | 80-89 | Revisão menor necessária |
| **Revisão Necessária** | 65-79 | Reformulação substancial |
| **Rejeitado** | <65 | Rebase completo |

---

## 6. EXEMPLOS PRÁTICOS

### 6.1 Petição Civil

```
Prompt:
"Use juridico-brasil para gerar contestação em ação de 
indenização por danos morais, réu Banco do Brasil, 
comarca Fortaleza/CE, valor R$ 30.000"
```

### 6.2 Recurso STJ

```
Prompt:
"Use juridico-brasil para elaborar recurso especial contra 
decisão do TJ-CE sobre responsabilidade civil, número do 
processo XXXXX-XX.2023.8.06.XXXX"
```

### 6.3 Parecer Administrativo

```
Prompt:
"Use juridico-brasil-nexus para gerar parecer sobre 
viabilidade de doação de terreno público para ampliação 
de escola municipal em Crateús/CE"
```

### 6.4 Análise Forense

```
Prompt:
"Use juridico-brasil-forense para auditar petição inicial 
verificando todas as fontes citadas e propondo melhorias"
```

---

## 7. FONTES DE DADOS

### Fontes Oficiais Automáticas

- **IBGE**: Demografia, IDHM, PIB
- **INEP**: Dados educacionais
- **STF/STJ**: Jurisprudência
- **LexML**: Legislação
- **CNJ**: Dados processuais

### Portais Regionais

- TJ-CE, IPECE, Portal Crateús

---

## 8. FORMATAÇÃO DE SAÍDA

### PDF/DOCX
```
O documento final pode ser exportado em:
- PDF (para protocolo)
- DOCX (para edição)
- Markdown (para revisão)
```

---

**GUIA DE USO v4.0 - 21/03/2026**
