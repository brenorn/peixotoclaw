# TEMPLATE: MANDADO DE SEGURANÇA

## Estrutura Completa

```
EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) DE DIREITO DA {VARA} DA COMARCA DE {COMARCA}/{ESTADO}
{OU}
EXCELENTÍSSIMO(A) SENHOR(A) {AUTORIDADE COATORA}

{IMPETRANTE}, [QUALIFICAÇÃO COMPLETA], [/proc-se], vem, respeitosamente, à presença de Vossa Excelência impetrar

## MANDADO DE SEGURANÇA

em face de {AUTORIDADE COATORA}, na qualidade de [CARGO], tudo conforme exposição a seguir:

---

### I – DOS FATOS

{Impetição do ato apontado como ilegal ou abuso de poder}

---

### II – DO DIREITO

#### II.1 – Do Direito Líquido e Certo

A petição está instruída com {DOCUMENTOS COMPROBATÓRIOS}, que demonstram, de plano, o direito líquido e certo do impetrante.

#### II.2 – Da Ilegalidade do Ato

{O ato apontado como ilegal, indicando dispositivos violados}

#### II.3 – Do Abuso de Poder

{Se aplicável: demonstração do abuso de poder}

---

### III – DO PEDIDO

Ante o exposto, requer:

a) A concessão da {TUTELA CAUTELAR | LIMINAR} para {PEDIDO};

b) A ordem de {CANCELAMENTO | ANULAÇÃO | CONCESSÃO} de {ATO};

c) {OUTROS PEDIDOS};

---

Termos em que,
Pede deferimento.

{local}, {data}

_______________________________
{NOME DO ADVOGADO}
{OAB/ESTADO} {NÚMERO}
```
