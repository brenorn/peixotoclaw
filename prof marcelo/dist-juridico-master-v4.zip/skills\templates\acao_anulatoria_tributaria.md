# TEMPLATE: AÇÃO ANULATÓRIA TRIBUTÁRIA

## Estrutura Completa

```
EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) DE DIREITO DA {VARA} FEDERAL DA SUBSEÇÃO JUDICIÁRIA DE {COMARCA}/{ESTADO}

{CONTRIBUINTE}, [QUALIFICAÇÃO COMPLETA], [/proc-se],[/endereço_para_intimação],[/e-mail],[/cnpj/cpf], representado por seu advogado ao final subscrito, vem à presença de Vossa Excelência propor a presente

## AÇÃO ANULATÓRIA C/C DECLARATÓRIA DE INEXISTÊNCIA DE RELAÇÃO JURÍDICA TRIBUTÁRIA

em face da UNIÃO (MINISTÉRIO DA FAZENDA), representada pela {AUTORIDADE FISCAL}, pelos fatos e fundamentos a seguir expostos:

---

### I – DA SÍNTESE FÁTICA

{O lançamento tributário impugnado}

---

### II – DA IMPUGNAÇÃO ADMINISTRATIVA

(Apresentação da impugnação e resultado)

---

### III – DO DIREITO

#### III.1 – Da Inexistência do Fato Gerador
{Fundamentação}

#### III.2 – Da Inobservância do Princípio da Legalidade
{Fundamentação (Art. 97, CTN)}

#### III.3 – Da Correta Interpretação da Lei
{Fundamentação}

---

### IV – DO PEDIDO

Ante o exposto, requer:

a) A concessão de {TUTELA CAUTELAR | LIMINAR};

b) A declaração de nulidade do lançamento contido no Auto de Infração nº {NÚMERO};

c) A condenação da requerida ao pagamento de {HONORÁRIOS};

---

### V – DO VALOR DA CAUSA

Atribui-se à causa o valor de R$ {VALOR}.

---

Termos em que,
Pede deferimento.

{local}, {data}

_______________________________
{NOME DO ADVOGADO}
{OAB/UF} {NÚMERO}
```
