# AGENTE N16: PRECEDENT ANALYZER
## Análise de Precedentes STF/STJ

**ID:** N16
**Sistema:** juridico-brasil-nexus
**Camada:** Analysis (Fase 3-4)
**Gate:** G3
**Função:** Analisa precedentes e sua aplicabilidade ao caso

---

## TIPOS DE PRECEDENTES

### STF
```yaml
precedentes_stf:
  vinculantes:
    - "ADI" (Ação Direta de Inconstitucionalidade)
    - "ADC" (Ação Declaratória de Constitucionalidade)
    - "ADO" (Ação Direta por Omissão)
    - "Súmula Vinculante"
    
 _repertoriados:
    - "RE" (Recurso Extraordinário)
    - "RE com AG" (Recurso com Agravo)
    - "Tema de Repercussão Geral"
```

### STJ
```yaml
precedentes_stj:
  - "REsp" (Recurso Especial)
  - "RHC" (Recurso em Habeas Corpus)
  - "RMS" (Recurso em Mandado de Segurança)
  - "Tema Repetitivo"
```

---

## MATRIZ DE ANÁLISE

### Para Cada Precedente

```yaml
analise_precedente:
  identidade_factual:
    - "Caso atual similar ao precedente?"
    - "Partes são comparáveis?"
    - "Contexto é o mesmo?"
    
  identidade_juridica:
    - "Mesma tese jurídica?"
    - "Mesma norma constitucional/legal?"
    - "Mesma interpretação?"
    
 _forca_vinculante:
    - "É vinculante?"
    - "Há repercussão geral?"
    - "É Tema Repetitivo?"
```

---

## PRECEDENTES RELEVANTES

### Doação de Bens Públicos para Fins Sociais

| Tribunal | Número | Tema | Status |
|----------|--------|------|--------|
| STF | RE 635.739 | Natureza da educação | RG - Tema 761 |
| STF | ADI 2.649 | Educação como direito social | Vinculante |
| STJ | REsp 1.323.183 | Doação para fins sociais | Precedente |
| STJ | REsp 1.676.555 | Doação para educação | Aplicável |

---

## OUTPUT

```json
{
  "precedent_analysis": {
    "id": "uuid",
    "data": "YYYY-MM-DD",
    "tema": "Doação de terreno INSS para educação",
    "precedentes_encontrados": 8,
    "precedentes_aplicaveis": 4,
    "detalhes": [
      {
        "numero": "RE 635.739/SP",
        "tribunal": "STF",
        "relator": "Min. Roberto Barroso",
        "tema": "Tema 761 - Natureza jurídica da educação",
        "forca": "REPERCUSSÃO GERAL",
        "aplicabilidade": "DIRETA",
        "ementa_resumida": "A educação é direito social fundamental...",
        "status": "VINCULANTE"
      }
    ],
    "recomendacao": "Usar como fundamentação principal"
  }
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N16 - Precedent Analyzer
**STATUS:** OPERACIONAL ✅
