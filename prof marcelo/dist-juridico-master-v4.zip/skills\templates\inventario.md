# TEMPLATE: INVENTÁRIO

## Estrutura Completa

```
EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) DE DIREITO DA {VARA} DE {SUCESSÕES / ÓRFÃOS / FAMÍLIA} DA COMARCA DE {COMARCA}/{ESTADO}

{INVENTARIANTE}, [QUALIFICAÇÃO], [/endereço], [/cpf], [/grau_parentesco_com_FALECIDO], [/estado_civil], [/profissão], [/filiação], [/naturalidade], [/nascimento], viúvo(a) {OU solteiro(a)} de {NOME}, [/proc-se], vem à presença de Vossa Excelência requerer

## INVENTÁRIO

do espólio de {FALECIDO}, [/cpf_cpf], [/nascimento_falecimento], [/data_falecimento], [/local_falecimento], [/estado_civil_ao_falecer], [/regime_bens], [/documentos_órgãos], [/procuração ousubstabelecimento se representado], pelos fatos e fundamentos:

---

### I – DO FALECIMENTO

O(A) {FALECIDO(A)} faleceu em {DATA}, às {HORA}, em {LOCAL}, conforme Certidão de Óbito nº {NÚMERO}, expedida pelo {CARTÓRIO}.

---

### II – DOS HERDEIROS

São herdeiros do(a) falecido(a):

1. {NOME}, [CPF], [GRAU_PARENTESCO], [ESTADO_CIVIL], [RESIDÊNCIA]
2. {NOME}, [CPF], [GRAU_PARENTESCO], [ESTADO_CIVIL], [RESIDÊNCIA]

---

### III – DOS BENS

O espólio é constituído dos seguintes bens:

| Item | Descrição | Valor |
|------|-----------|-------|
| 1 | {IMÓVEL: endereço, matrícula} | R$ xxx |
| 2 | {VEÍCULO: placa, chassi} | R$ xxx |
| 3 | {DINHEIRO: banco, conta} | R$ xxx |

Valor total do inventário: R$ {VALOR_EXTENSO} (R$ {VALOR}).

---

### IV – DO DIREITO

O requerente é {Cônjuge/Herdeiro direto} e possui interesse legítimo no inventário.

---

### V – DOS PEDIDOS

Ante o exposto, requer:

a) A abertura do inventário;

b) A nomeação do requerente como inventariante;

c) A expedição de formal de penhora;

d) A {HABILITAÇÃO / EXCLUSÃO} de herdeiros;

---

Termos em que,
Pede deferimento.

{local}, {data}

_______________________________
{INVENTARIANTE}
CPF: {NÚMERO}
```
