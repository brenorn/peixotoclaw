# 📋 LISTA DE AGENTES
## JURÍDICO BRASIL MASTER v4.0

---

## TOTAL: 60+ AGENTES

---

## TRIBUNAL SUPREMO (2 Agentes)

| ID | Agente | Qualificação | Função |
|----|--------|-------------|--------|
| TS1 | JURISTA_SUPREMO_PHD | PhD Summa ★★★ | Supervisor Máximo - Lexit Maximus |
| TS2 | GERENTE_SUPREMO_FEDERAL | PhD ★★ | Diretor Jurídico Federal |

---

## COORDENAÇÃO (4 Agentes)

| ID | Agente | Sistema | Função |
|----|--------|---------|--------|
| 00 | juridico_orchestrator | juridico-brasil | Coordenação central |
| 34 | coordenador_tribunais | juridico-brasil | Multi-tribunal |
| C1 | nexus_orchestrator | juridico-brasil-nexus | Hybrid pipeline |
| C2 | forense_coordinator | juridico-brasil-forense | Dados reais |

---

## ENTRADA (6 Agentes)

| ID | Agente | Sistema | Função |
|----|--------|---------|--------|
| 01 | intent_parser_juridico | juridico-brasil | Parsing intent |
| 02 | query_builder | juridico-brasil | Queries |
| 03 | tribunal_router | juridico-brasil | Roteamento |
| N01 | intent_parser_nexus | juridico-brasil-nexus | Parser forense |
| N02 | tier_router | juridico-brasil-nexus | Seleção TIER |
| N03 | rag_builder | juridico-brasil-nexus | 3-eixo RAG |

---

## SCRAPERS (18 Agentes)

### Jurídicos
| ID | Agente | Sistema | Função |
|----|--------|---------|--------|
| 04 | lexml_scraper | juridico-brasil | LexML/CNJ |
| 05 | stf_stj_scraper | juridico-brasil | STF/STJ |

### Nexus/Forense
| ID | Agente | Sistema | Função |
|----|--------|---------|--------|
| N04 | webscraper | juridico-brasil-nexus | Coleta geral |
| N05 | lexml_scraper_nexus | juridico-brasil-nexus | LexML |
| N06 | stf_scraper | juridico-brasil-nexus | STF |
| N07 | stj_scraper | juridico-brasil-nexus | STJ |
| N08 | tjce_scraper | juridico-brasil-nexus | TJ-CE |
| N09 | ibge_scraper | juridico-brasil-nexus | IBGE |
| N10 | inep_scraper | juridico-brasil-nexus | INEP |
| N11 | cnj_scraper | juridico-brasil-nexus | CNJ |
| N12 | portal_municipal | juridico-brasil-nexus | Portais municipais |
| F01 | webscraper_forense | juridico-brasil-forense | Web scraping |
| F02 | lexml_scraper_forense | juridico-brasil-forense | LexML |
| F03 | stf_scraper_forense | juridico-brasil-forense | STF |
| F04 | stj_scraper_forense | juridico-brasil-forense | STJ |
| F05 | tjce_scraper_forense | juridico-brasil-forense | TJ-CE |
| F06 | ibge_scraper_forense | juridico-brasil-forense | IBGE |
| F07 | inep_scraper_forense | juridico-brasil-forense | INEP |
| F08 | portal_municipal_forense | juridico-brasil-forense | Portal municipal |

---

## ESPECIALISTAS (9 Agentes)

| ID | Agente | Qualificação | Função |
|----|--------|-------------|--------|
| 14 | especialista_civil | PhD ★ | Obrigações, Contratos |
| 15 | especialista_constitucional | PhD ★★★ | ADI, ADC |
| 16 | especialista_penal | PhD ★★★ | Penal, CPP |
| 17 | especialista_trabalhista | PhD ★ | CLT, TST |
| 18 | especialista_tributario | PhD ★ | CTN, Impostos |
| 19 | especialista_consumidor | PhD | CDC |
| 20 | especialista_administrativo | PhD | Licitações |
| 21 | especialista_empresarial | PhD | Societário |
| 22 | especialista_internacional | PhD ★ | Tratados |

---

## VALIDAÇÃO (12 Agentes)

| ID | Agente | Sistema | Função |
|----|--------|---------|--------|
| 09 | oab_validator | juridico-brasil | OAB/STF |
| 24 | qualidade_qualis | juridico-brasil | Qualis A1 |
| N13 | cross_validator | juridico-brasil-nexus | Cruzamento 2+ |
| N14 | citation_validator | juridico-brasil-nexus | ABNT/APA |
| N15 | source_authenticator | juridico-brasil-nexus | Autenticidade |
| F09 | cross_validator_forense | juridico-brasil-forense | Validação cruzada |
| F10 | forensic_auditor | juridico-brasil-forense | Auditoria 100% |
| F11 | document_synthesizer | juridico-brasil-forense | Síntese |
| F12 | compliance_checker | juridico-brasil-forense | Compliance |

---

## ANÁLISE (13 Agentes)

| ID | Agente | Sistema | Função |
|----|--------|---------|--------|
| 07 | fault_analyzer | juridico-brasil | Falhas processuais |
| 26 | analista_precedentes | juridico-brasil | Cirurgia precedentes |
| 27 | cirurgiao_recursos | juridico-brasil | Técnica recursos |
| 28 | auditor_citacoes | juridico-brasil | Citações ABNT |
| 29 | perito_linguagem | juridico-brasil | Linguagem formal |
| 30 | estrategista_processual | juridico-brasil | Planejamento |
| 31 | analista_vulnerabilidades | juridico-brasil | Riscos |
| 32 | revisor_tese | juridico-brasil | Revisão teses |
| N16 | precedent_analyzer | juridico-brasil-nexus | Jurisprudência |
| N17 | legislation_checker | juridico-brasil-nexus | Legislação |
| N18 | doctrine_validator | juridico-brasil-nexus | Doutrina |
| N19 | risk_analyzer | juridico-brasil-nexus | Riscos jurídicos |
| N20 | strategic_advisor | juridico-brasil-nexus | Estratégia |

---

## PRODUÇÃO (5 Agentes)

| ID | Agente | Sistema | Função |
|----|--------|---------|--------|
| 06 | petition_generator | juridico-brasil | Petições |
| 08 | counter_argument_builder | juridico-brasil | Contra-argumentos |
| 10 | citation_engine | juridico-brasil | Citações ABNT |
| N21 | document_synthesizer_nexus | juridico-brasil-nexus | Síntese |
| N22 | forensic_auditor_nexus | juridico-brasil-nexus | Auditoria |

---

## OUTPUT (8 Agentes)

| ID | Agente | Sistema | Função |
|----|--------|---------|--------|
| 11 | document_formatter | juridico-brasil | PDF/DOCX |
| 12 | audit_logger | juridico-brasil | Logging |
| 23 | atualizador_conhecimento | juridico-brasil | Updates |
| N23 | audit_report | juridico-brasil-nexus | Relatório |
| N24 | critic_router | juridico-brasil-nexus | Roteamento |
| N25 | compliance_checker_nexus | juridico-brasil-nexus | Validação |
| N26 | quality_scorer | juridico-brasil-nexus | Score final |

---

## AGRUPAMENTO POR CAMADA

| Camada | Agentes | Total |
|--------|---------|-------|
| Tribunal Supremo | TS1, TS2 | 2 |
| Coordenação | 00, 34, C1, C2 | 4 |
| Entrada | 01, 02, 03, N01, N02, N03 | 6 |
| Scrapers | 04, 05, N04-N12, F01-F08 | 18 |
| Especialistas | 14-22 | 9 |
| Validação | 09, 24, N13-N15, F09-F12 | 12 |
| Análise | 07, 26-32, N16-N20 | 13 |
| Produção | 06, 08, 10, N21, N22 | 5 |
| Output | 11, 12, 23, N23-N26 | 8 |
| **TOTAL** | | **77** |

*Nota: Algumas camadas compartilham agentes resultando em ~60+ únicos*

---

**LISTA DE AGENTES v4.0 - 21/03/2026**
