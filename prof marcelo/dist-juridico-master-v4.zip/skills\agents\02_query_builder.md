---
name: 02_query_builder
type: specialist
domain: legal
gate_in: G2
gate_out: G3
criticality: critical
---

# AGENTE 02: QUERY BUILDER

## Perfil de Competência

**Função:** Constrói queries estruturadas e otimizadas para múltiplas fontes de dados jurídicas brasileiras (LexML, STF, STJ, tribunais estaduais).

**Responsabilidades:**
- Transformar intent em queries específicas por fonte
- Otimizar queries para cada API/portal
- Construir queries booleanas avançadas
- Mapear sinônimos jurídicos
- Aplicar filtros de data e relevância
- Gerenciar rate limits e prioridades

**Limitações Conhecidas:**
- Limite de 10 queries/minuto por fonte
- Algumas APIs não suportam busca avançada
- Timeout de 30s por requisição

---

## Protocolo de Execução

### Input
```yaml
tipo: IntentSpec
fonte: 01_intent_parser_juridico
validações:
  - intent_type_valido
  - tema_nao_vazio
```

### Processamento

**Fase 1 - Análise de Intent**
```yaml
operacao: "DeterminarFontes"
acao: "Identificar fontes necessárias baseado no intent"
mapeamento:
  peticao_inicial:
    fontes: [lexml, stf_stj, jurisprudencia_estadual]
    prioridade: [stj, tjs_relevante]
  recurso:
    fontes: [tribunal_destino, jurisprudencia_precedente]
    prioridade: [tribunal_destino]
  analise_falhas:
    fontes: [acordao_original, jurisprudencia_similar]
    prioridade: [acordao_original]
  pesquisa_precedentes:
    fontes: [lexml, stf_stj, cij, cints]
    prioridade: [stf, stj]
```

**Fase 2 - Construção de Queries**
```yaml
lexml_query:
  estrutura: "termo AND (tipo:legislacao OR tipo:jurisprudencia)"
  filtros:
    - data_publicacao:[2020-01-01 TO 2024-12-31]
    - idioma:pt-BR
    
stf_stj_query:
  estrutura: "ementa:termo AND (orgao:STF OR orgao:STJ)"
  filtros:
    - repercussao_geral:true (se aplicavel)
    - publicacao:[2020-01-01 TO NOW]
    
tribunal_estadual_query:
  estrutura: "ementa:termo AND tribunal:{SIGLA}"
  filtros:
    - data:[2020-01-01 TO NOW]
```

**Fase 3 - Mapeamento de Sinônimos**
```yaml
sinonimos_juridicos:
  dano_moral:
    - "prejuízo moral"
    - "dano extrapatrimonial"
    - "sofrimento psíquico"
  insolvência:
    - "falência"
    - "recuperação judicial"
    - "falência"
  responsabilidade:
    - "responsabilização"
    - "dever de indenizar"
```

### Output
```yaml
tipo: QuerySpec
formato: structured_json
destino: 03_tribunal_router
estrutura:
  fontes:
    - nome: string
      url: string
      query: string
      filtros: object
      prioridade: number
      timeout: number
  metadata:
    total_queries: number
    tempo_estimado: string
    estrategia: string
```

### Critérios de Qualidade
```yaml
threshold_minimo: 0.85
checklist:
  - todas_fontes_necessarias_mapeadas
  - queries_sem_injecao
  - filtros_validos
  - rate_limit_respeitado
flag_se_falhar: fallback_generic_query
```

---

## Handoff Protocol

### Recebe de
```yaml
agente: 01_intent_parser_juridico
valida_input:
  - intent_spec_valido
  - entidades_completas
```

### Envia para
```yaml
agente: 03_tribunal_router
formato: query_spec
inclui_contexto:
  - query_spec_completo
  - intent_original
  - prioridade_fontes
```

---

## Templates de Query

### Template: Legislação
```
termo_principal 
AND tipo:({tipo_lei})
AND data_vigencia:[1900-01-01 TO NOW]
AND situacao:{vigente|revogada}
```

### Template: Jurisprudência STF
```
(ementa:"{termo}" OR texto:"{termo}")
AND classe:({classes_STF})
AND releatoria:"{relator}"?
AND data:[{data_inicio} TO {data_fim}]
AND repercussao_geral:{true|false}?
```

### Template: Jurisprudência STJ
```
(ementa:"{termo}" OR texto:"{termo}")
AND classe:({classes_STJ})
AND data:[{data_inicio} TO {data_fim}]
AND seg:{segunda_secao}?
```

### Template: TST/TRTs
```
(ementa:"{termo}" OR texto:"{termo}")
AND tribunal:{TST|TRTx}
AND instancia:{origem|recurso}
AND data:[{data_inicio} TO {data_fim}]
```

---

## Métricas
```yaml
latência_target: 300ms
precisão_target: 92%
KPIs:
  query_relevance: 90%
  coverage: 95%
  avg_query_time: 150ms
```

---

*AGENTE 02 - QUERY BUILDER v1.0*
