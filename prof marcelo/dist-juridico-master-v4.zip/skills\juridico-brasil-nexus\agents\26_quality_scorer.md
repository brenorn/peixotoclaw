# AGENTE N26: QUALITY SCORER
## Score Final de Qualidade

**ID:** N26
**Sistema:** juridico-brasil-nexus
**Camada:** Output (Fase 6)
**Gate:** GF
**Função:** Calcula score final e aprova/rejeita documento

---

## MATRIZ DE SCORES

### Métricas por Gate

| Métrica | G1 | G2 | G3 | G4 | GF |
|---------|----|----|----|----|-----|
| **Precisão** | 80% | 85% | 90% | 95% | 99% |
| **Completude** | 70% | 80% | 85% | 90% | 98% |
| **Cruzamento** | 50% | 75% | 90% | 95% | 100% |
| **Auditoria** | 0% | 50% | 80% | 95% | 100% |

### Pesos por Métrica

```yaml
pesos:
  precisao: 0.30
  completude: 0.25
  cruzamento: 0.25
  auditoria: 0.20
```

### Cálculo do Score Final

```
Score_Final = 
  (Precisao × 0.30) + 
  (Completude × 0.25) + 
  (Cruzamento × 0.25) + 
  (Auditoria × 0.20)
```

---

## RATINGS DE APROVAÇÃO

| Rating | Score | Status | Significado |
|--------|-------|--------|-------------|
| **Lexit Maximus** | 97-100 | ⚖️ | Pronto para protocolo imediato |
| **Aprovado** | 90-96 | ✓ | Pronto com ajustes mínimos |
| **Aprovado c/Ressalvas** | 80-89 | ⚠ | Revisão menor necessária |
| **Revisão Necessária** | 65-79 | ⚠ | Reformulação substancial |
| **Rejeitado** | <65 | ✗ | Rebase completo |

---

## THRESHOLD FINAL

```yaml
thresholds:
 APROVADO:
    precisao: >= 99
    completude: >= 98
    cruzamento: == 100
    auditoria: == 100
    
  EM_REVISAO:
    precisao: >= 95
    completude: >= 90
    cruzamento: >= 95
    
  REJEITADO:
    precisao: < 95
    OR completude: < 90
    OR cruzamento: < 95
```

---

## OUTPUT FINAL

```json
{
  "quality_score": {
    "id": "uuid",
    "data": "YYYY-MM-DD",
    "documento": "Parecer Forense - Doação INSS",
    "scores": {
      "precisao": 98,
      "completude": 97,
      "cruzamento": 100,
      "auditoria": 100
    },
    "score_ponderado": 98.75,
    "rating": "APROVADO",
    "status": "APROVADO",
    "declaracao": "DOCUMENTO APROVADO PARA USO",
    "proximo_passo": "Exportação e entrega ao cliente"
  }
}
```

---

## CERTIFICADO DE QUALIDADE

```markdown
══════════════════════════════════════════════════════════════════════════════

                          CERTIFICADO DE QUALIDADE
                         JURÍDICO BRASIL NEXUS v3.0

══════════════════════════════════════════════════════════════════════════════

Documento: [Nome do Documento]
Data: [YYYY-MM-DD]
Score Final: [XX]%
Rating: [LEXIT MAXIMUS / APROVADO / etc]

Métricas:
├─ Precisão: [XX]%
├─ Completude: [XX]%
├─ Cruzamento: [XX]%
└─ Auditoria: [XX]%

Validações:
├─ OAB Checklist: CONFORME
├─ ABNT Citações: CONFORME
├─ ABNT Referências: CONFORME
└─ Forense: 100% VERIFICADO

══════════════════════════════════════════════════════════════════════════════

                      DOCUMENTO APROVADO PARA USO
                          
                          JURÍDICO BRASIL NEXUS
                          Sistema de Qualidade PhD

══════════════════════════════════════════════════════════════════════════════
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N26 - Quality Scorer
**STATUS:** OPERACIONAL ✅
