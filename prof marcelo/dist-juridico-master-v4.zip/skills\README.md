# ⚖️ JURÍDICO BRASIL v3.0

### Sistema de Advocacia Universal PhD Summa

---

> **⚠️ AVISO CIENTÍFICO:** Este sistema é uma ferramenta de apoyo jurídico. Todo documento gerado deve ser revisado por profissional habilitado perante a OAB. O sistema não substitui o julgamento humano.

---

## 🚀 INSTALAÇÃO RÁPIDA (2 min)

### Windows
```batch
1. Extraia juridico-brasil-v3.0.zip
2. Copie a pasta para .opencode/skills/
3. Execute install.bat
```

### Linux/Mac
```bash
1. unzip juridico-brasil-v3.0.zip
2. cp -r juridico-brasil-v3.0/.opencode/skills/
3. chmod +x juridico-brasil-v3.0/install.sh && ./juridico-brasil-v3.0/install.sh
```

### Uso
```
/skill juridico-brasil
```

---

## ⚠️ TRANSPARÊNCIA CIENTÍFICA

### Limitações e Mitigações

| Limitação | Impacto | Como Mitigamos |
|-----------|---------|----------------|
| Jurisprudência pode estar desatualizada | Decisões mudam constantemente | Agente 23 atualiza banco de dados |
| Citações podem conter vieses de seleção | Escolha de precedentes é parcial | Revisão humana obrigatória |
| Modelos podem gerar informações incorretas | "Alucinação" de dados | Validação OAB + Sistema PhD |
| Não substitui advogado | Decisões finais são humanas | Sistema de apoyo, não substituto |

### Protocolo de Uso Seguro

1. ✅ Use como ferramenta de pesquisa
2. ✅ Use como gerador de rascunhos
3. ✅ Sempre revise com profissional OAB
4. ❌ Não envie sem revisão humana
5. ❌ Não use como único fundamento

---

## 💡 O QUE TORNAR O SISTEMA ÚNICO

### 1. Jurista Supremo PhD (Agente 25)
Primeiro "juiz" virtual com autoridade para reprovar documentos. Avalia em **7 dimensões** e pode conceder **Lexit Maximus** (aprovação máxima de 97-100 pontos).

### 2. 34 Agentes Especializados
Cada agente é um especialista em uma função:
- 🔬 Cirurgiões de precedentes (Análise ratio decidendi)
- 📋 Auditores de citações (Verificação ABNT)
- 📝 Peritos em linguagem jurídica (Norma culta)
- 🎯 Estrategistas processuais (Planejamento)
- 🛡️ Analistas de vulnerabilidades (Riscos)

### 3. Índice de Autoridades Reais
**100+ referências bibliográficas** de autores reconhecidos:
- Barroso, Mendes, Dinamarco, Marinoni
- Caio Mário, Stolze, Bitencourt
- Todos com ISSN verificado e Qualis classificado

### 4. Ratings de Aprovação Claros

| Rating | Score | O que significa |
|--------|-------|----------------|
| ⚖️ **Lexit Maximus** | 97-100 | Pode usar imediatamente |
| ✅ **Aprovado** | 90-96 | Ajuste mínimo recomendado |
| ⚠️ **Aprovado c/Ressalvas** | 80-89 | Revisão necessária |
| ❌ **Rejeitado** | <80 | Reformular completamente |

---

## 📋 COMANDOS DE USO (Exemplos)

### Gerar Documentos
```
" Gere petição inicial de danos morais contra banco X"
" Gere defesa prévia em ação penal por furto"
" Gere recurso de apelação cível contra sentença"
```

### Analisar
```
" Analise o RE 1.000.000 do STF"
" Audite todas as citações do meu documento"
" Identifique falhas processuais no acórdão"
```

### Pesquisar
```
" Encontre precedentes STF sobre desconsideração de personalidade"
" Busque jurisprudência STJ sobre danos morais em 2024"
" Pesquise leis sobre proteção de dados LGPD"
```

### Contra-Argumentar
```
" Construa contra-argumentação para tese de prescrição"
" Rebata argumento de boa-fé processual do réu"
```

---

## 🏛️ TRIBUNAIS SUPORTADOS

| Tribunal | O que busca |
|----------|-------------|
| **STF** | Acórdãos, ADIs, ADCs, Repercussão Geral |
| **STJ** | Recursos Especiais, Repetitivos |
| **TST** | Recursos, Súmulas |
| **TJs** | TJSP, TJRJ, TJMG e demais |
| **TRFs** | Todas as 5 regiões |
| **Outros** | TSE, STM, CARF |

---

## ⚖️ ÁREAS DO DIREITO COBERTAS

- ✅ Constitucional (ADI, ADC, Controle)
- ✅ Civil (Obrigações, Contratos, Coisas)
- ✅ Penal (CP, CPP, Crimes Hediondos)
- ✅ Trabalhista (CLT, TST)
- ✅ Tributário (CTN, Impostos)
- ✅ Consumidor (CDC)
- ✅ Administrativo (Licitações, Ato)
- ✅ Empresarial (Societário, Falência)
- ✅ Internacional (Tratados, Arbitragem)
- ✅ Família, Ambiental, Digital

---

## 📁 ESTRUTURA DO PACOTE

```
juridico-brasil-v3.0/
├── SKILL.md              # Arquitetura técnica completa
├── README.md             # Este arquivo (guia rápido)
├── REFERENCIAS.md        # Teoria e fundamentação
├── agents/               # 35 agentes especializados
│   ├── 25_jurista_supremo_phd.md  # ★ Supervisor máximo
│   └── ... (34 outros)
├── templates/             # 11 modelos prontos
│   ├── peticion_inicial_civel.md
│   ├── recurso.md
│   └── ...
└── references/           # Base de conhecimento
    ├── autoridades_bibliografia.md  # ★ 100+ refs
    ├── jurisprudencia_index.md
    └── ...
```

---

## 🏆 QUALIFICAÇÕES DO SISTEMA

| Certificação | O que garante |
|--------------|---------------|
| **OAB** | Padrão de petições brasileiras |
| **STF** | Critérios de admissibilidade |
| **STJ** | Jurisprudência atualizada |
| **QUALIS A1** | Referências acadêmicas verificadas |
| **PhD Summa** | Supervisão máxima do sistema |

---

## 🔄 ATUALIZAÇÕES AUTOMÁTICAS

O sistema verifica automaticamente:
- 📜 Novas leis publicadas no DOU
- ⚖️ Mudanças jurisprudenciais STF/STJ
- 📋 Novas Súmulas Vinculantes
- 🎯 Precedentes de Repercussão Geral

---

## 📊 DADOS DO SISTEMA

| Métrica | Valor |
|---------|-------|
| Agentes | 34+ |
| Templates | 11 |
| Referências Bibliográficas | 100+ |
| Áreas do Direito | 12 |
| Tribunais | 10+ |
| Versão | 3.0.0 |

---

## 📞 SUPORTE

- **Email:** suporte@maswos.com.br
- **Issues:** GitHub Issues do projeto
- **Documentação:** Pasta /references/

---

## 📜 LICENÇA

MIT License - Uso livre para fins educacionais e comerciais.

---

## 🔬 NOTA CIENTÍFICA

Este sistema implementa uma arquitetura **Transformer** com **34+ agentes** para simulação de processos jurídicos. As saídas são geradas por modelos de linguagem e **devem ser verificadas** antes de uso profissional.

**Citação sugerida:**
```
JURÍDICO BRASIL v3.0. Sistema de Advocacia Universal PhD Summa. 
MASWOS V5 NEXUS, 2024.
```

---

## 📚 DOCUMENTAÇÃO COMPLEMENTAR

Para fundamentação teórica completa (arquitetura Transformer, matemática dos agentes, etc.), consulte:
- `SKILL.md` - Arquitetura técnica detalhada
- `REFERENCIAS.md` - Teoria e bibliografia acadêmica

---

**⚖️ JURÍDICO BRASIL v3.0**  
*Ferramenta de Apoyo Jurídico com IA*  
*Revisão humana obrigatória | Não substitui advogado*
