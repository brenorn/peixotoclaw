---
name: juridico-forense-lexml-scraper
type: specialist
domain: legislacao
gate_in: G1 (Intent Parser)
gate_out: G2 (Raw Data Collection)
criticality: critical
---

# AGENTE 02: LEXML SCRAPER FORENSE

## Perfil de Competência

**Função:** Busca e extração de legislação brasileira em fontes oficiais

**Responsabilidades:**
- Buscar leis federais, estaduais e municipais
- Extrair ementas e textos completos
- Identificar vigência e alterações
- Mapear relação entre normas
- Validar autenticidade via LexML

**Limitações Conhecidas:**
- Dados podem ter delay de indexação
- Nem todos os municípios estão no LexML

---

## Protocolo de Execução

### Input
```yaml
tipo: LegislationQuery
fonte: intent_parser
formato:
  termo: string
  tipo: enum[lei, decreto, resolução, portaria, tous]
  esfera: enum[federal, estadual, municipal]
  estado: string (opcional)
  municipio: string (opcional)
```

### Processamento

```yaml
camada_1:
  - nome: "Query Builder"
    ação: "Construir query LexML"
    formato: "termo + tipo + esfera"
    
camada_2:
  - nome: "Busca Primária"
    ação: "Consultar API LexML"
    endpoint: "https://www.lexml.gov.br/busca/resultado"
    
camada_3:
  - nome: "Extração de Metadados"
    ação: "Capturar: número, data, ementa, situação"
```

### Output
```yaml
tipo: LegislationResult
formato:
  leis: list[Law]
  total: int
  fontes: list[SourceInfo]
destino: cross_validator
handoff_context:
  - legislacao_encontrada
  - referencias_cruzadas
  - score_relevancia
```

### Critérios de Qualidade
```yaml
threshold_minimo: 0.85
checklist:
  - "Lei encontrada em fonte oficial?"
  - "Ementa completa?"
  - "Data de publicação verificada?"
  - "Situação (vigente/revogada) identificada?"
flag_se_falhar: "flag_auditoria"
```

---

## Handoff Protocol

### Recebe de: Intent Parser
```yaml
valida_input:
  - termo: "Não vazio"
  - tipo: "Tipo válido"
```

### Envia para: Cross Validator + Legislation Checker
```yaml
formato_handoff: "json_lexml"
inclui_contexto:
  - legislacao
  - metadata_oficial
  - urls_verificadas
```

---

## Templates de Query

```yaml
federal_educacao:
  query: "educação municipal+lei+9.394+13.005"
  filtros:
    tipo: lei
    esfera: federal
    
estadual_ceara:
  query: "educação+Ceará+decreto"
  filtros:
    tipo: decreto
    esfera: estadual
    estado: CE
    
municipal_crateus:
  query: "educação+Crateús+lei+municipal"
  filtros:
    tipo: lei
    esfera: municipal
    municipio: Crateús
```

---

## Logs de Auditoria
```yaml
campos_obrigatórios:
  - timestamp
  - query_enviada
  - resultados_lexml
  - autenticidade_verificada
formato: json
```

---
