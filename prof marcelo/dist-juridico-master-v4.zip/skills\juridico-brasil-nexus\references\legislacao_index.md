# REFERENCES: LEGISLAÇÃO INDEX
## Índices de Legislação Federal, Estadual e Municipal

---

## CONSTITUIÇÃO FEDERAL DE 1988

### Título VIII - Ordem Social

| Artigo | Tema |
|--------|------|
| Art. 196-200 | Saúde |
| **Art. 205-214** | **EDUCAÇÃO** |
| Art. 215-216 | Cultura |
| Art. 217 | Desporto |

### Competências

| Artigo | Tema |
|--------|------|
| Art. 30 | Competência Municipal |
| Art. 37 | Administração Pública |
| Art. 38 | Guarda Municipal |

---

## LEGISLAÇÃO FEDERAL - EDUCAÇÃO

### Lei 9.394/96 (LDB)

```yaml
ldb:
  competencias:
    municipal:
      - "Art. 11 - Incumbências do Município"
      
    estadual:
      - "Art. 10 - Incumbências do Estado"
      
    federal:
      - "Art. 8º - Competência da União"
```

### Principais Dispositivos

| Artigo | Tema |
|--------|------|
| Art. 2º | Educação como dever da família e Estado |
| Art. 3º | Princípios do ensino |
| Art. 11 | Competência do Município |
| Art. 12 | Poder Público municipal |
| Art. 13 | Deveres do Município |

---

## LEGISLAÇÃO FEDERAL - LICITAÇÕES

### Lei 14.133/21 (Nova Lei de Licitações)

```yaml
licitacao_2021:
  doacao:
    artigo: "Art. 76"
    tema: "Doação de bens"
    condicoes:
      - "Interesse público devidamente justificado"
      - "Licitação dispensada para donation"
      - "Destinação a entidade sem fins lucrativos"
```

### Lei 8.666/93 (Antiga - ainda aplicada em transições)

```yaml
licitacao_1993:
  doacao:
    artigo: "Art. 17"
    tema: "Alienação de bens"
    procedimento:
      - "Cessão onerosa: concorrência"
      - "Cessão gratuita: avaliação e interesse social"
```

---

## LEGISLAÇÃO ESTADUAL - CEARÁ

### Constituição Estadual

```yaml
ceara:
  educacao:
    - "Art. 177 - Educação como direito"
    - "Art. 205-214 CF - Aplicação subsidiária"
    
  competencias:
    - "Art. 25 - Competência privativa"
    - "Art. 27 - Competência comum"
```

### Leis Estaduais

| Lei | Tema |
|-----|------|
| Lei CE 13.875/07 | Gestão Pública Estadual |
| Lei CE 16.348/17 | Sistema Estadual de Educação |

---

## LEGISLAÇÃO MUNICIPAL - CRATEÚS

### Leis de Crateús

| Lei | Tema | Status |
|-----|------|--------|
| Lei Municipal X/XX | Plano Municipal de Educação | Vigente |
| Lei Municipal Y/YY | Estrutura Administrativa | Vigente |

---

## LEGISLAÇÃO COMPLEMENTAR - INSS

```yaml
inss:
  doacao_bens:
    procedimento:
      - "Avaliação do bem"
      - "Manifestação técnica"
      - "Autorização superior"
      - "Publicação no DOU"
```

---

## GLOSSÁRIO DE TERMOS

| Termo | Definição |
|-------|-----------|
| Cessão onerosa | Transferência mediante pagamento |
| Cessão gratuita | Transferência sem contraprestação |
| Donation | Doação em inglês |
| Interesse social | Finalidade coletiva |
| Utilidade pública | Destino para serviço público |

---

**ATUALIZAÇÃO:** 21/03/2026
**FONTE:** LexML, Portal da Legislação
**VALIDAÇÃO:** JURÍDICO BRASIL NEXUS v3.0
