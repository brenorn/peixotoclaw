# TEMPLATE: ANÁLISE DE FALHAS PROCESSUAIS

## Relatório Estruturado

```
# RELATÓRIO DE ANÁLISE DE FALHAS PROCESSUAIS

## 1. IDENTIFICAÇÃO DO PROCESSO

| Campo | Valor |
|-------|-------|
| Número | {NÚMERO COMPLETO} |
| Classe | {CLASSE} |
| Tribunal | {TRIBUNAL} |
| Relator | {RELATOR} |
| Órgão Julgador | {ÓRGÃO} |
| Data Julgamento | {DATA} |
| Data Publicação | {DATA} |

---

## 2. TESE OBJETO DE ANÁLISE

{Descrição da tese principal apresentada no acórdão}

### 2.1 Questões Jurídicas Centrais
1. {Questão 1}
2. {Questão 2}
3. {Questão 3}

---

## 3. FALHAS IDENTIFICADAS

### 3.1 FALHAS CRÍTICAS

| Código | Tipo | Descrição | Fundamentação |
|--------|------|-----------|---------------|
| F001 | Material | {Erro de fato} | {Art./Precedente} |
| F002 | Jurídica | {Erro de direito} | {Art./Precedente} |

### 3.2 FALHAS high

| Código | Tipo | Descrição | Impacto |
|--------|------|-----------|---------|
| F003 | Processual | {Vício} | {Alto/Médio} |

---

## 4. ANÁLISE DETALHADA

### 4.1 Falha: {TÍTULO}
**Código:** F00X
**Severidade:** CRÍTICA/high/MÉDIA/BAIXA
**Localização:** {Parte do acórdão}

**Descrição:**
{Descrição objetiva da falha}

**Evidência:**
> "{Trecho do acórdão que demonstra a falha}"

**Contradição:**
- {Precedente 1}
- {Precedente 2}

**Precedentes Favoráveis:**
| Tribunal | Número | Tema | Data |
|----------|--------|------|------|
| STF | RE xxx | Tema RG xxx | 2024 |
| STJ | REsp xxx | {Tema} | 2023 |

---

## 5. CONTRA-ARGUMENTAÇÃO

### 5.1 {TÍTULO DO ARGUMENTO}

**Argumento:**
{Construção argumentativa}

**Fundamento Legal:**
- Art. {X}, {CÓDIGO}
- Art. {X}, {CONSTITUIÇÃO}

**Precedentes:**
- {Tribunal}, {Classe}, {Número}, Rel. Min. {Nome}

**Doutrina:**
{NOME}, {OBRA}, {PÁGINA}

### 5.2 {ARGUMENTO 2}
{...}

---

## 6. ESTRATÉGIA RECURSAL

### 6.1 Tipo de Recurso Recomendado
{Recurso Ordinário / Apelação / RE / REspec / Revista}

### 6.2 Preliminares
1. {Preliminar 1}
2. {Preliminar 2}

### 6.3 Mérito
{Novel tese}

### 6.4 Pedido
Requer o {provimento} do recurso para {finalidade}

### 6.5 Prazo Estimado
{Prazo em dias}

---

## 7. QUALIFICAÇÃO OAB

| Item | Status |
|------|--------|
| Revisão | [X] Realizada |
| Revisor | {Nome OAB} |
| Data Revisão | {Data} |
| Status | APROVADO / REVISÃO |

---

## 8. ANEXOS
1. {Anexo 1}
2. {Anexo 2}
```
