---
name: juridico-forense-stj-scraper
type: specialist
domain: jurisprudencia-superior
gate_in: G1 (Intent Parser)
gate_out: G2 (Raw Data Collection)
criticality: critical
---

# AGENTE 04: STJ SCRAPER FORENSE

## Perfil de Competência

**Função:** Busca e extração de jurisprudência do Superior Tribunal de Justiça

**Responsabilidades:**
- Buscar recursos especiais e ordinários
- Extrair decisões colegiadas e monocráticas
- Identificar teses firmadas
- Mapear divergência jurisprudencial
- Validar via STJ oficial

**Limitações Conhecidas:**
- Pesquisa limitada a 3 anos por padrão
- Alguns acórdãos podem estar em PDF

---

## Protocolo de Execução

### Input
```yaml
tipo: JurisprudenciaQuery
fonte: intent_parser
formato:
  termo: string
  classe: enum[REsp, RE, AgInt, RMS, etc]
  orgao: enum[Terceira Turma, Quarta Turma, etc]
```

### Processamento

```yaml
camada_1:
  - nome: "Query STJ"
    ação: "Consultar portal STJ"
    endpoint: "https://www.stj.jus.br/jurisprudencia"
    
camada_2:
  - nome: "Extração"
    ação: "Capturar processo, relator, decisão"
```

### Output
```yaml
tipo: STJResult
formato:
  processos: list[STJProcesso]
  tesis: list[string]
  divergencia: boolean
destino: cross_validator
```

---

## Templates de Busca

```yaml
doacao_imovel_municipal:
  termo: "doação imóvel público municipal educação"
  classes: ["REsp", "RMS"]
  
administrativo_contrato:
  termo: "contrato administrativo interesse público"
  classes: ["REsp", "AgInt"]
```

---

## Logs de Auditoria
```yaml
campos_obrigatórios:
  - timestamp
  - query_stj
  - processos
  - validacao_portal
formato: json
```

---
