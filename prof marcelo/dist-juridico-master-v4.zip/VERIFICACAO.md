# VERIFICAÇÃO DO PACOTE
## JURÍDICO BRASIL MASTER v4.0

---

Execute este script para verificar se o pacote está completo:

```powershell
# Verificar estrutura
$zipPath = "dist-juridico-master-v4.zip"
$tempPath = ".\temp_verify"

# Extrair
Expand-Archive -Path $zipPath -DestinationPath $tempPath -Force

# Verificar arquivos essenciais
$requiredFiles = @(
    "temp_verify\README.md",
    "temp_verify\docs\ARQUITETURA.md",
    "temp_verify\skills\juridico-brasil-master\SKILL.md",
    "temp_verify\skills\juridico-brasil\SKILL.md",
    "temp_verify\skills\juridico-brasil-nexus\SKILL.md",
    "temp_verify\skills\juridico-brasil-forense\SKILL.md"
)

$allOk = $true
foreach ($file in $requiredFiles) {
    if (Test-Path $file) {
        Write-Host "[OK] $file"
    } else {
        Write-Host "[FALHA] $file"
        $allOk = $false
    }
}

# Contar agentes
$agents = Get-ChildItem -Path "temp_verify\skills" -Recurse -Filter "*.md" | Measure-Object
Write-Host ""
Write-Host "Total de arquivos .md: $($agents.Count)"

# Limpar
Remove-Item -Path $tempPath -Recurse -Force

if ($allOk) {
    Write-Host ""
    Write-Host "VERIFICAÇÃO: SUCESSO - Pacote OK!"
} else {
    Write-Host ""
    Write-Host "VERIFICAÇÃO: FALHOU - Verifique o pacote"
}
```

---

## VERIFICAÇÃO MANUAL

Após extrair, confirme:

### Pasta principal
- [ ] `README.md` presente
- [ ] `docs/` com 4 arquivos
- [ ] `install/` com arquivos
- [ ] `skills/` com 4 sistemas

### Skills
- [ ] `juridico-brasil-master/SKILL.md`
- [ ] `juridico-brasil/SKILL.md`
- [ ] `juridico-brasil-nexus/SKILL.md`
- [ ] `juridico-brasil-forense/SKILL.md`

### Total esperado
- ~120 arquivos .md
- 4 SKILL.md
- 4 README.md

---

**VERIFICAÇÃO v4.0 - 21/03/2026**
