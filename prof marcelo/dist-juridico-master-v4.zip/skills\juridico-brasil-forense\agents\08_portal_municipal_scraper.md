---
name: juridico-forense-portal-municipal
type: specialist
domain: transparencia-municipal
gate_in: G1 (Intent Parser)
gate_out: G2 (Raw Data Collection)
criticality: high
---

# AGENTE 08: PORTAL MUNICIPAL SCRAPER

## Perfil de Competência

**Função:** Extração de dados de portais de transparência e secretarias municipais

**Responsabilidades:**
- Buscar leis municipais em portais oficiais
- Extrair dados de secretarias (Educação, Saúde, etc)
- Coletar informações de diários oficiais municipais
- Mapear estrutura organizacional
- Validarvia portal oficial

**Limitações Conhecidas:**
- Cada município tem estrutura diferente
- Alguns portais podem estar desatualizados

---

## Protocolo de Execução

### Input
```yaml
tipo: PortalQuery
fonte: intent_parser
formato:
  municipio: string
  estado: string
  orgao: enum[prefeitura, camara, secretaria]
  tipo_dado: enum[lei, decreto, portaria, licitacao, despesa]
```

### Processamento

```yaml
camada_1:
  - nome: "Identificação Portal"
    ação: "Mapear URL oficial do município"
    base: "https://{municipio}.{estado}.gov.br"
    
camada_2:
  - nome: "Navegação Portal"
    ação: "Acessar seção relevante"
    
camada_3:
  - nome: "Extração"
    ação: "Capturar dados solicitados"
```

### Output
```yaml
tipo: PortalResult
formato:
  municipio: string
  cnpj: string
  prefeito: string
  endereco: string
  telefones: list[string]
  leis: list[LeiMunicipal]
  secretarias: list[Secretaria]
destino: cross_validator
```

---

## Dados Típicos para Crateús/CE

```yaml
crateus_ce:
  portal: "https://www.crateus.ce.gov.br/"
  cnpj: "07.982.036/0001-67"
  prefeito: "Janaina Carla Farias"
  vice_prefeito: "Francisco Jose Bezerra"
  endereco: "Rua Galeria Gentil Cardoso, 20 - Centro"
  cep: "63.700-000"
  telefone: "(88) 3692-3315"
  email: "gabinete@crateus.ce.gov.br"
  horario: "Segunda a Sexta, 7:30 às 13:30"
  secretarias:
    educacao:
      nome: "Secretaria Municipal de Educação"
      titular: "Dilviana Márcia Penha Alves"
      cnpj: "06.073.170/0001-82"
      endereco: "Rua Manoel Augustinho, 544 - São Vicente"
      cep: "63.700-300"
      email: "gabineteseduc@crateus.ce.gov.br"
```

---

## Logs de Auditoria
```yaml
campos_obrigatórios:
  - timestamp
  - municipio
  - url_acessada
  - dados_extraidos
  - status_http
formato: json
```

---
