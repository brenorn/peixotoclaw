---
name: juridico-brasil-forense
description: Skill forense de pesquisa jurídica brasileira com arquitetura Transformer completa. Coleta dados REAIS de IBGE, INEP, portais de prefeituras, STF/STJ, LexML, diários oficiais. 20+ agentes granulares para validação cruzada, auditoria completa e síntese forense. Tipo: forense
domain: legal
subdomain: forense
tier: 1
version: 1.0.0
type: forense
author: MASWOS V5 NEXUS
license: MIT
compatibility: opencode
qualificacao: FORENSE | DADOS_REAIS | CROSS_VALIDATION | AUDIT_COMPLETO
metricas:
  completude: ">=95%"
  precisao: ">=98%"
  cruzamento: "100% fontes validadas"
  auditoria: "100% informacoes verificadas"
---

# SKILL: JURÍDICO BRASIL FORENSE v1.0
## Pesquisa Forense com Coleta de Dados Reais

> **ALERT:** Sistema FORENSE - Coleta dados REAIS de fontes oficiais brasileiras (IBGE, INEP, STF, STJ, LexML, portais de prefeituras). Cada dado é validado por cruzamento de no mínimo 2 fontes independentes.

> **ALERT:** Este skill opera sob padrão **AUDITORIA FORENSE v1.0**: Rastreabilidade Total, Reprodutibilidade, Validação Cruzada, Aprovação/Rejeição com Score de Confiança.

---

## ARQUITETURA TRANSFORMER

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    JURÍDICO BRASIL FORENSE - SKILL                      │
│                    (Arquitetura Transformer Completa)                   │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      INPUT ENCODER STACK                         │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐      │   │
│  │  │Intent Parser │→ │Query Builder │→ │Forensic Router   │      │   │
│  │  │Forense      │  │Real Data     │  │(03)              │      │   │
│  │  └──────┬───────┘  └──────┬───────┘  └────────┬─────────┘      │   │
│  └─────────┼─────────────────┼───────────────────┼─────────────────┘   │
│            │                 │                   │                     │
│            ▼                 ▼                   ▼                     │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      COLLECTION LAYER (FASE 1)                  │   │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌─────────────┐    │   │
│  │  │WebScraper│←→│LexML     │←→│STF       │←→│STJ          │    │   │
│  │  │(04)      │  │Scraper   │  │Scraper   │  │Scraper      │    │   │
│  │  │          │  │(05)      │  │(06)      │  │(07)         │    │   │
│  │  └──────────┘  └──────────┘  └──────────┘  └─────────────┘    │   │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌─────────────┐    │   │
│  │  │TJ-CE     │←→│IBGE      │←→│INEP      │←→│CNJ          │    │   │
│  │  │Scraper   │  │Scraper   │  │Scraper   │  │Scraper      │    │   │
│  │  │(08)      │  │(09)      │  │(10)      │  │(11)         │    │   │
│  │  └──────────┘  └──────────┘  └──────────┘  └─────────────┘    │   │
│  │                                                                 │   │
│  │  ┌──────────────────────────────────────────────────────────┐   │   │
│  │  │DadosAbertosScraper (12)                                  │   │   │
│  │  └──────────────────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                              │                                           │
│                              ▼                                           │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      VALIDATION LAYER (FASE 2)                  │   │
│  │  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌──────────┐│   │
│  │  │Cross       │→ │Citation    │→ │Precedent  │→ │Legislation│   │
│  │  │Validator   │  │Validator   │  │Analyzer   │  │Checker   ││   │
│  │  │(13)        │  │(14)        │  │(15)       │  │(16)      ││   │
│  │  └────────────┘  └────────────┘  └────────────┘  └──────────┘│   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                              │                                           │
│                              ▼                                           │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      ANALYSIS LAYER (FASE 3-4)                  │   │
│  │  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌──────────┐│   │
│  │  │Doctrine    │→ │Risk        │→ │Strategic   │→ │Compliance │   │
│  │  │Validator   │  │Analyzer    │  │Advisor     │  │Checker   ││   │
│  │  │(17)        │  │(18)        │  │(19)        │  │(20)      ││   │
│  │  └────────────┘  └────────────┘  └────────────┘  └──────────┘│   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                              │                                           │
│                              ▼                                           │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      SYNTHESIS LAYER (FASE 5)                    │   │
│  │  ┌──────────┐  ┌──────────┐  ┌────────────┐                   │   │
│  │  │Document   │  │Forensic   │  │Audit       │                   │   │
│  │  │Synthesizer│  │Auditor    │  │Report     │                   │   │
│  │  │(21)       │  │(22)       │  │(23)       │                   │   │
│  │  └──────────┘  └──────────┘  └────────────┘                   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                              │                                           │
│                              ▼                                           │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      OUTPUT LAYER (FASE 6)                      │   │
│  │  ┌────────────┐  ┌────────────┐  ┌────────────┐               │   │
│  │  │Quality     │  │Final       │  │Export      │               │   │
│  │  │Score       │  │Approval    │  │(JSON/PDF)  │               │   │
│  │  │(24)        │  │(25)        │  │(26)        │               │   │
│  │  └────────────┘  └────────────┘  └────────────┘               │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## PIPELINE DE 6 FASES

### FASE 1: COLETA BRUTA DE DADOS
- Coleta de dados de fontes primárias oficiais
- Web scraping de portais governamentais
- Busca em bases de dados legislativas
- Extração de jurisprudência de tribunais
- Coleta de dados estatísticos (IBGE, INEP, CNJ)

### FASE 2: VALIDAÇÃO DE FONTES
- Verificação de autenticidade das fontes
- Validação de URLs e portais oficiais
- Checagem de datas de publicação
- Verificação de institucionalidade

### FASE 3: CRUZAMENTO DE INFORMAÇÕES
- Comparação de dados entre múltiplas fontes
- Identificação de inconsistências
- Triangulação de informações
- Score de convergência entre fontes

### FASE 4: ANÁLISE DE CONSISTÊNCIA
- Validação de legislação referenced
- Verificação de precedentes aplicáveis
- Análise de doutrina especializada
- Avaliação de riscos jurídicos

### FASE 5: SÍNTESE AUDITORA
- Compilação de dados validados
- Geração de relatório forense
- Documentação de fontes e validações
- Score de confiança final

### FASE 6: APROVAÇÃO OU REJEIÇÃO
- Verificação de completude (≥95%)
- Verificação de precisão (≥98%)
- Aprovação final ou rejeição com motivo
- Geração de output formatado

---

## AGENTES FORENSES (26 AGENTES)

### AGENTES DE COLETA (FASE 1)

#### 01. WebScraper
- **Função:** Coleta dados de portais web diversos
- **Fontes:** Portais de prefeituras, сайты governamentais, portais de transparência
- **Output:** Dados brutos com metadados de origem

#### 02. LexMLScraper
- **Função:** Coleta legislação do portal LexML
- **Fontes:** LexML (lexml.gov.br)
- **Output:** Leis, decrees, códigos, súmulas
- **Query Exemplo:** `http://lexml.gov.br/legislacao/ref/sim/remete/2024-01-01/`

#### 03. STFScraper
- **Função:** Coleta jurisprudência do STF
- **Fontes:** portal.stf.jus.br, giross.stf.jus.br
- **Output:** Julgamentos, Informativos, Repertórios
- **Query Exemplo:** `site:portal.stf.jus.br "repercussão geral" "recurso extraordinário"`

#### 04. STJScraper
- **Função:** Coleta jurisprudência do STJ
- **Fontes:** stj.jus.br, bdjur.stj.jus.br
- **Output:** Recursos Especiais, Recursos Ordinários, Agravos
- **Query Exemplo:** `site:stj.jus.br "recurso especial" "violação de lei"`

#### 05. TJ_CEScraper
- **Função:** Coleta jurisprudência do TJ Ceará
- **Fontes:** tjce.jus.br
- **Output:** Acórdãos, decisões monocráticas
- **Query Exemplo:** `site:tjce.jus.br "apelação" "Ceará"`

#### 06. IBGEScraper
- **Função:** Coleta dados demográficos e socioeconômicos
- **Fontes:** ibge.gov.br, SIDRA, IBGE Cidades
- **Output:** População, IDHM, PIB, PIB per capita, taxa de urbanização
- **Query Exemplo:** `site:ibge.gov.br "Ceará" "IDHM" "municipios"`

#### 07. INEPScraper
- **Função:** Coleta dados educacionais
- **Fontes:** inep.gov.br, QEdu, SAEPE
- **Output:** Escolas, matrículas, IDEB, resultados ENEM, fluxo escolar
- **Query Exemplo:** `site:inep.gov.br "IDEB" "Fortaleza" "escolas"`

#### 08. CNJScraper
- **Função:** Coleta dados processuais e estatísticos
- **Fontes:** cnj.jus.br, Justiça Aberta, BNMP
- **Output:** Processos, varas, tribunais, sentenças, execução penal
- **Query Exemplo:** `site:cnj.jus.br "estatísticas" "processos" "TJ-CE"`

#### 09. DadosAbertosScraper
- **Função:** Coleta dados de portals de dados abertos
- **Fontes:** dados.gov.br, dados.ce.gov.br, portals municipais
- **Output:** Datasets diversos, licitações, contratos, execução orçamentária

### AGENTES DE VALIDAÇÃO (FASE 2)

#### 10. CrossValidator
- **Função:** Validação cruzada de informações
- **Método:** Triangulação com mínimo 2 fontes independentes
- **Output:** Score de convergência (0-100%)

#### 11. SourceAuthenticator
- **Função:** Autenticação de fontes
- **Verificação:** URL oficial, domínio governamental, data de publicação
- **Output:** Status de autenticidade

#### 12. TemporalValidator
- **Função:** Validação temporal
- **Verificação:** Data de vigência, vacância, revogação
- **Output:** Status de vigência

### AGENTES DE ANÁLISE (FASE 3-4)

#### 13. CitationValidator
- **Função:** Validação de citações jurídicas
- **Padrões:** ABNT, OAB, JSTOR
- **Output:** Citação formatada e validada

#### 14. PrecedentAnalyzer
- **Função:** Análise de precedentes
- **Verificação:** Reputação, aplicabilidade, força vinculante
- **Output:** Tese jurídica com precedentes

#### 15. LegislationChecker
- **Função:** Verificação de legislação
- **Verificação:** Constitutionalidade, vigência, aplicabilidade
- **Output:** Status legislativo

#### 16. DoctrineValidator
- **Função:** Validação doutrinária
- **Verificação:** Autores reconhecidos, publicações qualificadas
- **Output:** Referências doutrinárias validadas

#### 17. RiskAnalyzer
- **Função:** Análise de riscos jurídicos
- **Fatores:** Probabilidade, impacto, precedentes adversos
- **Output:** Score de risco (baixo/médio/alto)

#### 18. StrategicAdvisor
- **Função:** Orientação estratégica
- **Análise:** Melhor abordagem processual, recursos cabíveis
- **Output:** Recomendações estratégicas

#### 19. ComplianceChecker
- **Função:** Verificação de compliance
- **Verificação:** Conformidade legal, prazos, requisitos
- **Output:** Checklist de compliance

### AGENTES DE SÍNTESE (FASE 5)

#### 20. DocumentSynthesizer
- **Função:** Síntese de documentos forenses
- **Método:** Compilação de dados validados
- **Output:** Documento síntese

#### 21. ForensicAuditor
- **Função:** Auditoria forense completa
- **Verificação:** 100% das informações verificadas
- **Output:** Relatório de auditoria

#### 22. EvidenceCollector
- **Função:** Compilação de evidências
- **Método:** Agregação de fontes, validações, scores
- **Output:** Pacote de evidências

### AGENTES DE OUTPUT (FASE 6)

#### 23. QualityScorer
- **Função:** Cálculo de score de qualidade
- **Métricas:** Completude ≥95%, Precisão ≥98%, Cruzamento 100%
- **Output:** Score final

#### 24. ApprovalManager
- **Função:** Gerenciamento de aprovação
- **Critérios:** Threshold de qualidade atingido
- **Output:** Status (APROVADO/REJEITADO/EM REVISÃO)

#### 25. ReportGenerator
- **Função:** Geração de relatórios
- **Formatos:** JSON, PDF, Markdown
- **Output:** Relatório final

#### 26. ArchiveManager
- **Função:** Arquivamento de pesquisas
- **Método:** Armazenamento com metadados completos
- **Output:** Referência arquivada

---

## WORKFLOW FORENSE

### ETAPA 1: Coleta Bruta de Dados
```
1.1. Parser de intent identifica tipo de pesquisa
1.2. Query builder cria buscas otimizadas para cada fonte
1.3. Forensic router distribui para scrapers relevantes
1.4. Agentes de coleta executam em paralelo
1.5. Dados brutos armazenados com metadados
```

### ETAPA 2: Validação de Fontes
```
2.1. SourceAuthenticator verifica autenticidade
2.2. TemporalValidator verifica vigência
2.3. URLs e domínios validados
2.4. Fontes classificadas por confiabilidade
```

### ETAPA 3: Cruzamento de Informações
```
3.1. CrossValidator compara dados entre fontes
3.2. Identificação de divergências
3.3. Score de convergência calculado
3.4. Fontes conflitantes identificadas
```

### ETAPA 4: Análise de Consistência
```
4.1. PrecedentAnalyzer verifica aplicabilidade
4.2. LegislationChecker valida legislação
4.3. DoctrineValidator verifica doutrina
4.4. RiskAnalyzer avalia riscos
```

### ETAPA 5: Síntese Auditada
```
5.1. DocumentSynthesizer compila dados validados
5.2. ForensicAuditor verifica 100% das informações
5.3. EvidenceCollector organiza evidências
5.4. Relatório preliminar gerado
```

### ETAPA 6: Aprovação ou Rejeição
```
6.1. QualityScorer calcula score final
6.2. ApprovalManager verifica thresholds
6.3. Se APROVADO: ReportGenerator cria output final
6.4. Se REJEITADO: Retorna à fase 3 com flag de revisão
6.5. ArchiveManager arquiva resultado
```

---

## MÉTRICAS DE QUALIDADE

| Métrica | Target | Verificação |
|---------|--------|-------------|
| Completude | ≥95% | % de campos preenchidos / total esperado |
| Precisão | ≥98% | Dados corretos / total de dados coletados |
| Cruzamento | 100% | Fontes validadas / total de fontes utilizadas |
| Auditoria | 100% | Informações verificadas / total de informações |
| Confiança | ≥90% | Score médio de todas as validações |

### Thresholds de Aprovação
- **APROVADO:** Completude ≥95% AND Precisão ≥98% AND Cruzamento = 100%
- **EM REVISÃO:** Completude ≥80% OR Precisão ≥90% (revisão parcial)
- **REJEITADO:** Completude <80% OR Precisão <90% OR Cruzamento <80%

---

## TEMPLATE DE OUTPUT

### Estrutura de Resposta Forense

```json
{
  "pesquisa": {
    "id": "uuid-unico",
    "tipo": "jurisprudencia|legislacao|dados|estatistica",
    "data": "YYYY-MM-DDTHH:MM:SSZ",
    "tempo_processamento": "X.XXs"
  },
  "resultados": [
    {
      "fonte_primaria": {
        "nome": "Nome da Fonte",
        "url": "https://...",
        "tipo": "tribunal|legislativo|executivo|independente",
        "data_coleta": "YYYY-MM-DD",
        "dados": { ... }
      },
      "fonte_secundaria": {
        "nome": "Nome da Fonte de Cruzamento",
        "url": "https://...",
        "tipo": "tribunal|legislativo|executivo|independente",
        "data_coleta": "YYYY-MM-DD",
        "dados": { ... }
      },
      "score_confianca": 98,
      "status": "APROVADO|REJEITADO|EM REVISÃO",
      "cross_references": [
        {
          "fonte": "Nome",
          "campo": "campo_validado",
          "correspondencia": true|false
        }
      ],
      "metadados": {
        "completude": 98,
        "precisao": 99,
        "cruzamento": 100,
        "auditoria": 100
      }
    }
  ],
  "auditoria": {
    "total_fontes": 5,
    "fontes_aprovadas": 5,
    "fontes_rejeitadas": 0,
    "total_validacoes": 25,
    "validacoes_sucesso": 25,
    "score_auditoria": 100
  },
  "aprovacao": {
    "status": "APROVADO",
    "score_final": 97,
    "threshold_atendido": true,
    "revisoes_necessarias": 0
  }
}
```

### Exemplo de Output

```json
{
  "pesquisa": {
    "id": "f1a2b3c4-d5e6-7890-abcd-ef1234567890",
    "tipo": "dados",
    "data": "2024-03-15T14:30:00Z",
    "tempo_processamento": "4.23s"
  },
  "resultados": [
    {
      "fonte_primaria": {
        "nome": "IBGE Cidades - Fortaleza/CE",
        "url": "https://cidades.ibge.gov.br/brasil/fortaleza/panorama",
        "tipo": "executivo",
        "data_coleta": "2024-03-15",
        "dados": {
          "populacao": 2686612,
          "idh": 0.802,
          "idh_renda": 0.789,
          "idh_longevidade": 0.854,
          "idh_educacao": 0.763,
          "pib": 60923456,
          "pib_per_capita": 22678.43
        }
      },
      "fonte_secundaria": {
        "nome": "IPECE -Instituto de Pesquisa e Estratégia",
        "url": "https://ipece.ce.gov.br/indicadores/",
        "tipo": "independente",
        "data_coleta": "2024-03-15",
        "dados": {
          "populacao": 2686612,
          "idh": 0.802,
          "idh_educacao": 0.765
        }
      },
      "score_confianca": 97,
      "status": "APROVADO",
      "cross_references": [
        {
          "fonte": "IBGE",
          "campo": "populacao",
          "correspondencia": true
        },
        {
          "fonte": "IPECE",
          "campo": "idh",
          "correspondencia": true
        }
      ],
      "metadados": {
        "completude": 100,
        "precisao": 97,
        "cruzamento": 100,
        "auditoria": 100
      }
    }
  ],
  "auditoria": {
    "total_fontes": 2,
    "fontes_aprovadas": 2,
    "fontes_rejeitadas": 0,
    "total_validacoes": 8,
    "validacoes_sucesso": 8,
    "score_auditoria": 100
  },
  "aprovacao": {
    "status": "APROVADO",
    "score_final": 97,
    "threshold_atendido": true,
    "revisoes_necessarias": 0
  }
}
```

---

## EXEMPLOS DE QUERIES REAIS

### 1. Dados Demográficos - Município
**Query:** "Fortaleza Ceará população IDHM 2022 IBGE"
```
Fontes: IBGE Cidades, SIDRA, IPECE
Dados: População, IDHM (renda, longevidade, educação), PIB
Validação: Cruzamento com dados do IPECE
```

### 2. Dados Educacionais - Estado
**Query:** "Ceará IDEB 2021 escolas matrícula INEP"
```
Fontes: INEP, QEdu, SAEPE
Dados: IDEB por município, número de escolas, matrículas
Validação: Cruzamento com dados da SEDUC-CE
```

### 3. Jurisprudência - STF
**Query:** "repercussão geral STF direta de inconstitucionalidade 2023"
```
Fontes: portal.stf.jus.br, giross.stf.jus.br
Dados: ADIs, ADPs, ADCs com repercussão geral
Validação: Cruzamento com informativos STF
```

### 4. Jurisprudência - STJ
**Query:** "recurso especial STJ direito civil contrato 2023"
```
Fontes: stj.jus.br, bdjur.stj.jus.br
Dados: Recursos especiais, teses jurídicas
Validação: Cruzamento com jurisprudência consolidada
```

### 5. Legislação - LexML
**Query:** "lei complementar 101 gestão fiscal brasileira LexML"
```
Fontes: lexml.gov.br
Dados: LC 101/2000, regulamentações, alterações
Validação: Cruzamento com site da Casa Civil
```

### 6. Dados Processuais - CNJ
**Query:"estatísticas TJ-CE processos 2023 varas"
```
Fontes: cnj.jus.br, tjce.jus.br
Dados: Número de processos, varas,巫s
Validação: Cruzamento com dados do próprio tribunal
```

### 7. Dados Abertos - Portal Municipal
**Query:"Fortaleza CE licitações contratos 2023 dados abertos"
```
Fontes: dados.gov.br, transparencia.fortaleza.ce.gov.br
Dados: Licitações, contratos, execução orçamentária
Validação: Cruzamento com TCM-CE
```

### 8. Diários Oficiais
**Query:"Diário Oficial União DOU lei publicada março 2024"
```
Fontes: in.gov.br/diario-oficial-uniao
Dados: Leis, decrees, portarias publicadas
Validação: Cruzamento com site da Presidência
```

---

## FONTES DE DADOS SUPORTADAS

### Fontes Primárias Oficiais
| Fonte | URL | Tipo | Dados |
|-------|-----|------|-------|
| IBGE | ibge.gov.br | Executivo | Demografia, economia |
| INEP | inep.gov.br | Executivo | Educação |
| CNJ | cnj.jus.br | Judiciário | Processos, estatísticas |
| LexML | lexml.gov.br | Legislativo | Legislação federal/estadual |
| STF | portal.stf.jus.br | Judiciário | Jurisprudência |
| STJ | stj.jus.br | Judiciary | Jurisprudência |

### Fontes Secundárias
| Fonte | URL | Tipo | Dados |
|-------|-----|------|-------|
| IPECE | ipece.ce.gov.br | Estado | Indicadores estaduais |
| SEDUC | educacao.ce.gov.br | Estado | Educação estadual |
| TJ-CE | tjce.jus.br | Estado | Jurisprudência estadual |
| TCM-CE | tcm.ce.gov.br | Estado | Contas públicas |
| Dados.gov | dados.gov.br | Federal | Datasets abertos |

---

## CHECKLIST DE VALIDAÇÃO

### Coleta
- [ ] Dados coletados de fonte primária oficial
- [ ] URL da fonte validada
- [ ] Data de coleta registrada
- [ ] Metadados completos

### Validação
- [ ] Fonte autenticada
- [ ] Dados temporais validados
- [ ] Cruzamento executado
- [ ] Score de convergência >80%

### Análise
- [ ] Legislação referenced verificada
- [ ] Precedentes aplicáveis identificados
- [ ] Risco avaliado
- [ ] Compliance verificado

### Síntese
- [ ] 100% das informações verificadas
- [ ] Evidências compiladas
- [ ] Relatório gerado

### Aprovação
- [ ] Completude ≥95%
- [ ] Precisão ≥98%
- [ ] Cruzamento = 100%
- [ ] Score final ≥90%

---

## USO DO SKILL

### Invocação
```bash
# Pesquisa forense de dados
/search-forense --tipo dados --municipio "Fortaleza" --estado "CE"

# Pesquisa forense de jurisprudência
/search-forense --tipo jurisprudencia --tribunal "STF" --tema "constitucional"

# Pesquisa forense de legislação
/search-forense --tipo legislacao --termo "LC 101" --ano 2000
```

### Parâmetros
| Parâmetro | Descrição | Valores |
|-----------|-----------|---------|
| tipo | Tipo de pesquisa | dados, jurisprudencia, legislacao, estatistica |
| municipio | Município (para dados) | Nome do município |
| estado | Estado (sigla) | CE, SP, RJ, etc |
| tribunal | Tribunal | STF, STJ, TJ-CE, etc |
| tema | Tema jurídico | constitucional, civil, penal, etc |
| termo | Termo legislativo | Lei, decree, etc |
| ano | Ano de referência | 2024, 2023, etc |

---

## VERSION HISTORY

- v1.0.0 (2024-03-15): Lançamento inicial do skill forense com 26 agentes

---

## ESTRUTURA DE ARQUIVOS DO SKILL

```
juridico-brasil-forense/
├── SKILL.md                          # Arquitetura principal (este arquivo)
├── agents/                           # Agentes especializados
│   ├── 01_webscraper_forense.md    # WebScraper
│   ├── 02_lexml_scraper.md         # LexMLScraper
│   ├── 03_stf_scraper.md           # STFScraper
│   ├── 04_stj_scraper.md           # STJScraper
│   ├── 05_tjce_scraper.md          # TJ-CEScraper
│   ├── 06_ibge_scraper.md          # IBGEScraper
│   ├── 07_inep_scraper.md          # INEPScraper
│   ├── 08_portal_municipal_scraper.md # Portal Municipal
│   ├── 09_cross_validator.md        # CrossValidator
│   ├── 10_forensic_auditor.md      # ForensicAuditor
│   ├── 11_document_synthesizer.md   # DocumentSynthesizer
│   └── 12_compliance_checker.md    # ComplianceChecker
└── templates/
    └── documento_forense_template.md # Template de documento final
```

---

## REFERÊNCIAS OFICIAIS

### Governamentais
- IBGE: https://ibge.gov.br
- INEP: https://inep.gov.br
- CNJ: https://cnj.jus.br
- LexML: https://lexml.gov.br
- STF: https://portal.stf.jus.br
- STJ: https://stj.jus.br
- TJ-CE: https://tjce.jus.br
- FNDE: https://www.gov.br/fnde/
- IPECE: https://ipece.ce.gov.br
- Dados.gov: https://dados.gov.br

### Educacionais
- QEdu: https://qedu.org.br
- SAEPE: https://www.educacao.ce.gov.br/

### Transparência
- Portal da Transparência: https://portaldatransparencia.gov.br/
- Siconfi: https://siconfi.tesouro.gov.br/

### Portais de Ceará
- Crateús: https://www.crateus.ce.gov.br/
- Ceará: https://www.ceara.gov.br/

---

## TEMPLATES

### Template de Documento Forense
O arquivo `templates/documento_forense_template.md` contém o template completo para geração de documentos jurídicos auditados, incluindo:
- Cabeçalho forense com metadados
- Seções de dados do município
- Dados educacionais
- Fundamentação legal auditada
- Cruzamento de informações
- Checklist de validação
- Declaração de auditoria

---

## VERSION HISTORY

- v2.0.0 (2026-03-20): Integração de agentes forenses completos
  - 12 agentes especializados criados
  - Pipeline de 6 fases implementado
  - Template de documento forense adicionado
  - Cross-validation e auditoria implementados
- v1.0.0 (2024-03-15): Lançamento inicial do skill forense com 26 agentes

---

**SISTEMA:** MASWOS V5 NEXUS - JURÍDICO BRASIL FORENSE v2.0
**STATUS:** OPERACIONAL ✅
**ULTIMA ATUALIZAÇÃO:** 20/03/2026