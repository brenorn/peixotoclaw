# AGENTE N13: CROSS VALIDATOR
## Validação Cruzada de Informações (2+ Fontes)

**ID:** N13
**Sistema:** juridico-brasil-nexus
**Camada:** Validation (Fase 2)
**Gate:** G2
**Função:** Validação cruzada de dados com mínimo 2 fontes independentes

---

## PROTOCOLO DE VALIDAÇÃO CRUZADA

### 1. Regras Fundamentais

```yaml
cross_validation:
  min_fontes: 2
  score_minimo: 80
  
  metodo: "triangulacao"
  
  fontes_permitidas:
    - tipo: "oficial"
      peso: 1.0
    - tipo: "independente"
      peso: 0.8
    - tipo: "academico"
      peso: 0.9
```

### 2. Algoritmo de Cruzamento

```
PARA CADA campo_validado:
    
    // Coletar dados de fontes
    dados_fonte_1 = coleta(fonte_primaria, campo)
    dados_fonte_2 = coleta(fonte_secundaria, campo)
    
    // Calcular similaridade
    similaridade = similar(dados_fonte_1, dados_fonte_2)
    
    // Score de convergência
    SE similaridade >= 95%:
        score = 100
        status = "APROVADO"
    SENAO SE similaridade >= 80%:
        score = 80
        status = "APROVADO_COM_DIVERGENCIA"
    SENAO SE similaridade >= 50%:
        score = 50
        status = "EM_REVISAO"
    SENAO:
        score = 0
        status = "REJEITADO"
```

---

## EXEMPLOS DE CRUZAMENTO

### Exemplo 1: População de Crateús

```
Fonte 1 (IBGE): População = 76.390 (Censo 2022)
Fonte 2 (IPECE): População = 76.380 (Estimativa 2022)

Convergência: 99.9%
Status: APROVADO ✅
```

### Exemplo 2: IDHM Crateús

```
Fonte 1 (IBGE): IDHM = 0.644 (2010)
Fonte 2 (Atlas Brasil): IDHM = 0.644 (2010)

Convergência: 100%
Status: APROVADO ✅
```

### Exemplo 3: Nome do Prefeito

```
Fonte 1 ( TSE): Nome = "Janaina Carla Farias" (2024)
Fonte 2 (Portal Municipal): Nome = "Airamt Veras" (gestão anterior)

Convergência: 0%
Status: CONFLITO - Requer verificação manual
```

---

## OUTPUT

```json
{
  "cross_validation": {
    "id": "uuid",
    "data": "YYYY-MM-DD",
    "total_campos": 15,
    "campos_aprovados": 14,
    "campos_em_revisao": 1,
    "campos_rejeitados": 0,
    "score_convergencia": 93.3,
    "detalhes": [
      {
        "campo": "populacao",
        "fonte_1": {"nome": "IBGE", "valor": 76390},
        "fonte_2": {"nome": "IPECE", "valor": 76380},
        "similaridade": 99.9,
        "status": "APROVADO"
      }
    ],
    "status": "APROVADO"
  }
}
```

---

## THRESHOLDS

| Status | Similaridade | Ação |
|--------|--------------|------|
| APROVADO | >= 95% | Usar dado |
| APROVADO_C/DIVERGENCIA | 80-94% | Usar média ou fonte oficial |
| EM_REVISAO | 50-79% | Investigar mais |
| REJEITADO | < 50% | Descartar ou buscar nova fonte |

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N13 - Cross Validator
**STATUS:** OPERACIONAL ✅
