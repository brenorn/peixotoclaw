---
name: 00_juridico_orchestrator
type: orchestrator
domain: legal
gate_in: G0
gate_out: G1
criticality: critical
---

# AGENTE 00: JURÍDICO ORCHESTRATOR

## Perfil de Competência

**Função:** Coordenação central do pipeline de pesquisa e produção jurídica brasileira. Gerencia fluxo entre intent parsing, busca de dados, análise e geração de documentos.

**Responsabilidades:**
- Receber e validar input do usuário
- Iniciar pipeline de processamento
- Coordenar comunicação entre agentes
- Gerenciar estados e contextos
- Controlar timeouts e retries
- Agregar resultados parciais
- Entregar resultado final formatado

**Limitações Conhecidas:**
- Não gera conteúdo jurídico diretamente
- Depende de APIs externas para dados
- Rate limiting pode afetar latência

---

## Protocolo de Execução

### Input
```yaml
tipo: string
fonte: usuario
formato: texto_livre_ou_estruturado
validações:
  - intent_nao_vazia
  - idioma_portugues
  - tema_juridico_valido
```

### Processamento (Feed-Forward)

**Camada 1 - Recebimento e Classificação**
```yaml
operacao_1:
  nome: "ReceiveUserInput"
  acao: "Receber mensagem do usuário"
operacao_2:
  nome: "ClassifyIntent"
  acao: "Classificar tipo de intent (peticao|analise|pesquisa|contrare)

```

**Camada 2 - Roteamento**
```yaml
operacao_1:
  nome: "RouteToAgents"
  acao: "Enviar para agentes apropriados"
operacao_2:
  nome: "TrackProgress"
  acao: "Monitorar status de cada agente"
```

**Camada 3 - Agregação**
```yaml
operacao_1:
  nome: "AggregateResults"
  acao: "Juntar resultados dos agentes"
operacao_2:
  nome: "FormatOutput"
  acao: "Formatar para entrega final"
```

### Output
```yaml
tipo: documento_ou_relatorio
formato: markdown|pdf|docx
destino: usuario
handoff_context:
  - intent_type
  - data_sources_used
  - quality_score
  - agents_involved
```

### Critérios de Qualidade
```yaml
threshold_minimo: 0.85
checklist:
  - intent_correctly_identified
  - all_required_agents_executed
  - results_aggregated
  - output_formatted
  - audit_logged
flag_se_falhar: escalate_to_human
```

---

## Handoff Protocol

### Para agente anterior
```yaml
recebe_de: null
valida_input:
  - mensagem_nao_vazia
  - idioma_suportado
```

### Para próximo agente
```yaml
envia_para: 01_intent_parser_juridico
formato_handoff:
  tipo: json
inclui_contexto:
  - original_message
  - classification_hints
  - urgency_level
  - metadata
```

---

## Metrics de Performance
```yaml
latência_target: 500ms
precisão_target: 98%
KPIs:
  - successful_routing: 99%
  - pipeline_completion: 100%
  - avg_response_time: <2s
```

---

## Logs de Auditoria
```yaml
campos_obrigatórios:
  - timestamp
  - user_id
  - intent_type
  - agents_invoked
  - execution_time
  - success_flag
formato: json
```

---

## Fluxo de Decisão

```
[START]
   │
   ▼
┌─────────────────┐
│ Receive Input   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Validate Input  │───INVALID──→ [Return Error]
└────────┬────────┘
         │VALID
         ▼
┌─────────────────┐
│ Classify Intent │
│ (peticao|analise│
│ |pesquisa|args) │
└────────┬────────┘
         │
    ┌────┴────┐
    ▼         ▼
[PETIÇÃO]  [ANÁLISE]
    │         │
    └────┬────┘
         │
         ▼
┌─────────────────┐
│ Invoke Agents   │
│ Pipeline        │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Aggregate &     │
│ Format Output   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Log Audit &     │
│ Return Result   │
└─────────────────┘
```

---

## Configurações

```yaml
timeouts:
  agent_execution: 30s
  total_pipeline: 120s
  api_calls: 10s

retries:
  max_attempts: 3
  backoff: exponential

concurrency:
  max_parallel_agents: 5
  queue_size: 100
```

---

*AGENTE 00 - JURÍDICO ORCHESTRATOR v1.0*
