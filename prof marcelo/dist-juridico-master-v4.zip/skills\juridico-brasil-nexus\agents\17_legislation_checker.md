# AGENTE N17: LEGISLATION CHECKER
## Verificação de Legislação - Vigência e Aplicabilidade

**ID:** N17
**Sistema:** juridico-brasil-nexus
**Camada:** Analysis (Fase 3-4)
**Gate:** G3
**Função:** Verifica vigência, constitucionalidade e aplicabilidade de legislação

---

## TIPOS DE VERIFICAÇÃO

### 1. Vigência
```yaml
viencia:
  statuses:
    - "VIGENTE" - Lei em pleno vigor
    - "REVOGADA" - Expressa ou tácita
    - "VACATÓRIA" - Aguardando vacatio legis
    - "SUSPENSA" - Medida cautelar
    - "MODIFICADA" - Com alterações posteriores
```

### 2. Constitucionalidade
```yaml
constitucionalidade:
  verificacoes:
    - "Está dentro da competência?"
    - "Respeita matéria reservada?"
    - "Forma de publicação correta?"
    - "Não há vício de iniciativa?"
```

### 3. Aplicabilidade
```yaml
aplicabilidade:
  espacotemporal:
    - "Lei vigora no tempo?"
    - "Lei vigora no espaço?"
    - "Lei vigora para o caso?"
    
  hierarquia:
    - "Norma constitucional?"
    - "Lei ordinária?"
    - "Decreto regulamentar?"
```

---

## LEGISLAÇÃO RELEVANTE

### Doação de Bens Públicos

```yaml
legislacao_educacao:
  federal:
    - "CF/88, Art. 205-214 (Educação)"
    - "Lei 9.394/96 (LDB)"
    - "Lei 14.133/21 (Licitações)"
    
  estadual_ce:
    - "CE, Art. 177-205 (Educação)"
    - "Lei CE 13.875/07 (Gestão Pública)"
```

---

## OUTPUT

```json
{
  "legislation_check": {
    "id": "uuid",
    "data": "YYYY-MM-DD",
    "total_legislacao": 12,
    "vigente": 12,
    "revogada": 0,
    "detalhes": [
      {
        "norma": "CF/88, Art. 205",
        "tipo": "Constituição Federal",
        "status": "VIGENTE",
        "constitucionalidade": "CONSTITUCIONAL",
        "aplicabilidade": "DIRETA",
        "ementa": "A educação, direito social e dever do Estado..."
      },
      {
        "norma": "Lei 9.394/96, Art. 11",
        "tipo": "Lei Ordinária Federal",
        "status": "VIGENTE",
        "constitucionalidade": "CONSTITUCIONAL",
        "aplicabilidade": "DIRETA",
        "ementa": "Os Municípios incumbir-se-ão de..."
      }
    ],
    "score_conformidade": 100
  }
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N17 - Legislation Checker
**STATUS:** OPERACIONAL ✅
