# JURÍDICO BRASIL NEXUS v3.0
## Sistema Forense de Pesquisa Jurídica com Hybrid Pipeline

---

## DESCRIÇÃO

Sistema **NEXUS** de pesquisa jurídica brasileira com arquitetura **Transformer** completa. Integra:

- **45+ scrapers** para coleta de dados reais
- **RAG Protocol** de 3 eixos de citação
- **3 TIERs** de publicação (Magnum/Standard/Express)
- **Actor-Critic Loop** para qualidade máxima
- **6 Quality Gates** de validação
- **Auditoria forense** completa

---

## ESTRUTURA

```
juridico-brasil-nexus/
├── SKILL.md                    # Arquitetura principal
├── README.md                   # Este arquivo
│
├── agents/                     # 26 Agentes especializados
│   ├── 01_intent_parser.md    # Parser de intent
│   ├── 02_tier_router.md      # Seleção TIER
│   ├── 03_rag_builder.md       # Blueprint RAG
│   ├── 04-12_*.md             # Scrapers (9 agentes)
│   ├── 13-15_*.md             # Validadores (3 agentes)
│   ├── 16-20_*.md             # Análise (5 agentes)
│   ├── 21-23_*.md             # Síntese (3 agentes)
│   └── 24-26_*.md             # Output (3 agentes)
│
├── templates/                  # Templates de documentos
│   ├── peticao_inicial.md     # Petição com dados forenses
│   ├── artigo_academico.md    # Artigo Qualis A1
│   └── documento_forense.md   # Relatório forense
│
└── references/                 # Bases de conhecimento
    ├── jurisprudencia_index.md # STF/STJ/TJs
    ├── legislacao_index.md    # Leis e normas
    ├── autores_referencias.md # Doutrina
    └── scrapers_guide.md      # Guia de APIs
```

---

## USO

### Invocar Skill

```
/skill juridico-brasil-nexus
```

### Exemplos de Comandos

```bash
# Gerar petição com dados forenses
"Use juridico-brasil-nexus para gerar petição inicial de doação de 
terreno INSS para escola em Crateús/CE, verificando dados do município"

# Gerar artigo acadêmico
"Use juridico-brasil-nexus para gerar artigo Qualis A1 sobre 
responsabilidade civil digital"

# Análise forense
"Use juridico-brasil-nexus para auditar documento de viabilidade 
de parceria público-privada"
```

---

## TIER SYSTEM

| TIER | Nome | Páginas | Agentes | Uso |
|------|------|---------|---------|-----|
| **🥇 1** | MAGNUM | 110+ | 26 | Teses, dissertações |
| **🥈 2** | STANDARD | 15-30 | 18 | Artigos Q1, pareceres |
| **🥉 3** | EXPRESS | 5-10 | 12 | Petições, recursos |

---

## PIPELINE (6 FASES)

1. **G0 - Início:** Intent Parser + Tier Router + RAG Builder
2. **G1 - Coleta:** 9 Scrapers (IBGE, INEP, STF, STJ, etc)
3. **G2 - Validação:** Cross-Validator + Citation + Source
4. **G3 - Análise:** Precedent + Legislation + Doctrine + Risk
5. **G4 - Síntese:** Document Synthesizer + Forensic Auditor
6. **GF - Final:** Critic Router + Compliance + Quality Score

---

## QUALIDADE

| Métrica | Target | Crítico |
|---------|--------|---------|
| Completude | ≥98% | <95% |
| Precisão | ≥99% | <97% |
| Cruzamento | 100% | <95% |
| Auditoria | 100% | <95% |

---

## AUTORES DE REFERÊNCIA

### Direito Constitucional
- BARROSO, MENDES, SILVA, LENZA, SARLET

### Direito Civil
- PEREIRA, GONÇALVES, DINIZ, VENOSA

### Direito Administrativo
- DI PIETRO, CARVALHO FILHO, MEDAUAR

---

## FONTES OFICIAIS

- IBGE: ibge.gov.br
- INEP: inep.gov.br
- STF: portal.stf.jus.br
- STJ: stj.jus.br
- CNJ: cnj.jus.br
- LexML: lexml.gov.br
- TJ-CE: tjce.jus.br
- IPECE: ipece.ce.gov.br

---

## VERSÃO

**v3.0** - 21/03/2026

**STATUS:** OPERACIONAL ✅

---

*Parte do ecossistema JURÍDICO BRASIL MASTER v4.0*
*Compatible with MASWOS V5 NEXUS*
