# AGENTE N11: CNJ SCRAPER
## Coleta de Dados Processuais e Estatísticos

**ID:** N11
**Sistema:** juridico-brasil-nexus
**Camada:** Collection (Fase 1)
**Gate:** G1
**Função:** Coleta dados do CNJ (cnj.jus.br) e Justiça Aberta

---

## FONTES CNJ

| Fonte | URL | Dados |
|-------|-----|-------|
| CNJ | cnj.jus.br | Institucional |
| Dados Abertos | cnj.jus.br/dados-abertos | Bases |
| Justiça Aberta | justicaaberta.cnj.jus.br | Processos |
| BNMP | cnj.jus.br/bnmp | Execuções penais |
| CNEP | cnj.jus.br/cnep | Execuções fiscais |

---

## DADOS COLETADOS

### Estatísticas Nacionais
```yaml
estatisticas_justica:
  - numero_processos
  - tempo_medio_tramitacao
  - taxa_resolucao
  - processos_pendentes
  - indice_ipea
```

### Por Tribunal
```yaml
tribunal:
  - nome
  - regiao
  - numero_varas
  - processos_ativos
  - sentencias_anuais
```

### Dados Abertos
```yaml
dados_abertos:
  - licitacoes
  - contratos
  - execucao_orcamentaria
  - pessoal
```

---

## QUERIES DE EXEMPLO

```
# TJ-CE Estatísticas
site:cnj.jus.br "TJ-CE" "estatísticas" "processos"

# Dados abertos
site:cnj.jus.br "dados abertos" "dataset" "tribunais"

# Justiça Aberta
site:justicaaberta.cnj.jus.br "Ceará" "varas"
```

---

## OUTPUT

```json
{
  "fonte": "CNJ",
  "url": "https://cnj.jus.br/...",
  "tipo": "dados_processuais",
  "data_coleta": "YYYY-MM-DD",
  "dados": {
    "tribunal": "TJ-CE",
    "regiao": "Nordeste",
    "estatisticas_2023": {
      "processos_distribuidos": 150000,
      "processos_pendentes": 85000,
      "sentencas_proferidas": 95000,
      "tempo_medio_meses": 18
    }
  },
  "metadados": {
    "completude": 92,
    "precisao": 99,
    "periodo": "2023"
  }
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N11 - CNJ Scraper
**STATUS:** OPERACIONAL ✅
