# TEMPLATE: RECLAMAÇÃO TRABALHISTA

## Estrutura Completa

```
EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) DE DIREITO DA {VARA} DO TRABALHO DA COMARCA DE {COMARCA}/{ESTADO}
{OU}
EXCELENTÍSSIMO(A) SENHOR(A) {DESEMBARGADOR(A)} DO {TRIBUNAL} DO TRABALHO DA {REGIÃO}ª REGIÃO

{RECLAMANTE}, [QUALIFICAÇÃO], [/proc-se], vem, respeitosamente, à presença de Vossa Excelência propor a presente

## RECLAMAÇÃO TRABALHISTA

em face de {RECLAMADO}, [QUALIFICAÇÃO], pelos fatos e fundamentos a seguir:

---

### I – DA TEMPESTIVIDADE

(Se necessário: demonstração do prazo)

---

### II – DO CONTRATO DE TRABALHO

O reclamante foi admitido em {DATA}, pelo regime celetista, exercendo a função de {FUNÇÃO}, mediante salário de R$ {VALOR}.

---

### III – DOS FATOS

{Narrativa cronológica das violações}

---

### IV – DO DIREITO

#### IV.1 – Da Violação da CLT
{Fundamentação específica}

#### IV.2 – Dos Direitos Violados
{Enumeração dos direitos}

---

### V – DAS VERBAS RECLAMADAS

| Código | Verba | Base Legal | Valor |
|--------|-------|-----------|-------|
| 1 | Horas Extras | Art. 59 CLT | R$ xxx |
| 2 | FGTS | Lei 8.036/90 | R$ xxx |

---

### VI – DOS PEDIDOS

Ante o exposto, requer:

a) A procedência dos pedidos;

b) A condenação ao pagamento de {VERBAS};

c) {TUTELA URGENTE};

---

### VII – DO VALOR DA CAUSA

Atribui-se à causa o valor de R$ {VALOR}.

---

Termos em que,
Pede deferimento.

{local}, {data}

_______________________________
{NOME DO ADVOGADO}
{OAB/ESTADO} {NÚMERO}
```
