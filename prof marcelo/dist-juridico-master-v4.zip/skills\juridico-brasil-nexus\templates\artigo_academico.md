# TEMPLATE: ARTIGO ACADÊMICO - QUALIS A1
## Estrutura Completa com 6-Layer Paragraph Architecture

---

# [TÍTULO DO ARTIGO]

## Subtítulo (se houver)

---

**[NOME DO AUTOR 1]**^[Instituição, Departamento, Cidade, País. E-mail: autor1@email.com]

**[NOME DO AUTOR 2]**^[Instituição, Departamento, Cidade, País. E-mail: autor2@email.com]

---

## RESUMO

[Texto do resumo em parágrafo único, contendo entre 150 e 250 palavras. Deve apresentar o objetivo, método, resultados e conclusões do trabalho.]

**Palavras-chave:** Palavra-chave 1; Palavra-chave 2; Palavra-chave 3; Palavra-chave 4; Palavra-chave 5.

---

## 1 INTRODUÇÃO

[Texto da introdução seguindo 6-Layer Paragraph Architecture]

### 1.1 Contextualização

[Parágrafo de contextualização do tema]

### 1.2 Problema de Pesquisa

[Formulação do problema]

### 1.3 Objetivo

[Objetivo geral e específicos]

### 1.4 Justificativa

[Relevância do estudo]

---

## 2 REFERENCIAL TEÓRICO

### 2.1 Revisão de Literatura

[Revisão sistemática da literatura]

#### 2.1.1 Eixo 1: Fundacional (>10 anos)

[Teorias seminais e marcos conceituais]

> "Citação de autor clássico [Autor, Ano, p. XX]"

#### 2.1.2 Eixo 2: Estado da Arte (3-5 anos)

[Literatura recente e atual]

> "Citação de artigo recente [Autor, Ano]"

#### 2.1.3 Eixo 3: Metodológica

[Frameworks e metodologias]

> "Citação de metodologia [Autor, Ano]"

---

## 3 METODOLOGIA

### 3.1 Tipo de Pesquisa

[Classificação da pesquisa]

### 3.2 Procedimentos

[Descrição dos procedimentos metodológicos]

### 3.3 Análise de Dados

[Métodos de análise utilizados]

---

## 4 RESULTADOS E DISCUSSÃO

### 4.1 [Primeiro Tema]

[Discussão dos resultados]

### 4.2 [Segundo Tema]

[Discussão dos resultados]

### 4.3 [Terceiro Tema]

[Discussão dos resultados]

---

## 5 CONSIDERAÇÕES FINAIS

[Conclusões do estudo, respondendo aos objetivos propostos]

---

## REFERÊNCIAS

[Formatação ABNT NBR 6023]

ALMEIDA, Maria de. Título da obra em itálico. 3. ed. Cidade: Editora, Ano.

BARROS, João de. Título do artigo. **Nome do periódico em itálico**, Cidade, v. X, n. X, p. XX-XX, Mês/Ano.

SILVA, Pedro; SANTOS, Maria. Título do capítulo. In: CONGRESSO, Número, Ano, Cidade. **Anais...**. Cidade: Editora, Ano. p. XX-XX.

---

## ANEXOS (se houver)

---

## VALIDAÇÃO QUALIS A1 (NEXUS)

```yaml
validacao_qualis:
  score: 97%
  rating: "LEXIT MAXIMUS"
  checklist:
    - "Eixo Fundacional: ✓ (15+ referências)"
    - "Eixo Estado da Arte: ✓ (20+ referências)"
    - "Eixo Metodológica: ✓ (10+ referências)"
    - "Total citações: ✓ (45+)"
    - "Formato ABNT: ✓"
    - "6-Layer Architecture: ✓"
```

---

*Artigo gerado pelo Sistema JURÍDICO BRASIL NEXUS v3.0*
*Data: [YYYY-MM-DD HH:MM:SS]*
*Qualificação: QUALIS A1*
