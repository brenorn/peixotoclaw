---
name: juridico-brasil
description: Skill multiagente avançado para pesquisa jurídica brasileira com 34+ agentes especializados em arquitetura Transformer. Inclui Jurista Supremo PhD, Gerente Federal PhD, 9 especialistas por área, agentes granulares cirúrgicos, validação Qualis A1, índice de autoridades com referências reais auditáveis. Rigor máximo OAB/STF para advogado universal e impecável.
domain: legal
tier: 1
version: 3.0.0
author: MASWOS V5 NEXUS
license: MIT
compatibility: opencode
qualificacao: OAB | STF | STJ | QUALIS_A1 | PHD_SUMMA
---

# SKILL: JURÍDICO BRASIL v3.0
## Rede Transformer de 34+ Agentes para Advocacia Universal PhD Summa

> **ALERT:** Sistema opera sob padrão **JURISTA SUPREMO PhD** - Rigor Máximo OAB, Critérios STF/STJ, Classificação Qualis A1, Referências Bibliográficas Reais Auditáveis. Cada documento é avaliado em 7 dimensões por supervisão PhD Summa.

> **ALERT:** Este skill opera sob padrões OAB/STF. Todo conteúdo gerado deve seguir o **Rito de Nuremberg Jurídico v3.0**: Precisão Cirúrgica, Rastreabilidade Total, Reprodutibilidade Máxima, Auditabilidade Completa.

---

## ARQUITETURA TRANSFORMER

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    JURÍDICO BRASIL - SKILL                               │
│                    (Arquitetura Transformer Completa)                    │
│                                                                         
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      INPUT ENCODER STACK                         │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐      │   │
│  │  │Intent Parser │→ │Query Builder │→ │Tribunal Router   │      │   │
│  │  │(01)          │  │(02)          │  │(03)              │      │   │
│  │  └──────┬───────┘  └──────┬───────┘  └────────┬─────────┘      │   │
│  └─────────┼─────────────────┼───────────────────┼─────────────────┘   │
│            │                 │                   │                     │
│            ▼                 ▼                   ▼                     │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      CROSS-ATTENTION LAYER                       │   │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌─────────────┐    │   │
│  │  │LexML API │←→│STF/STJ   │←→│Diário    │←→│JusBrasil    │    │   │
│  │  │(04)      │  │Scraper   │  │Oficial   │  │Aggregator   │    │   │
│  │  └──────────┘  └──────────┘  └──────────┘  └─────────────┘    │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                              │                                           │
│                              ▼                                           │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      DECODER STACK                               │   │
│  │  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌──────────┐│   │
│  │  │Petition    │→ │Fault       │→ │Counter     │→ │OAB        ││   │
│  │  │Generator   │  │Analyzer    │  │Arg Builder │  │Validator ││   │
│  │  │(06)        │  │(07)         │  │(08)        │  │(09)       ││   │
│  │  └────────────┘  └────────────┘  └────────────┘  └──────────┘│   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                              │                                           │
│                              ▼                                           │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      OUTPUT LAYER                               │   │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────┐   │   │
│  │  │Document   │  │Citation  │  │Audit     │  │Export        │   │   │
│  │  │Formatter  │  │Engine    │  │Logger    │  │(PDF/DOCX)    │   │   │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         
└─────────────────────────────────────────────────────────────────────────┘
```

---

## DOMÍNIOS COBERTOS

### 1. Jurisprudência
- **STF**: Repertório de Julgamentos, Informativos, ADIs, ADOs, ADC
- **STJ**: Recursos Especiais, Recursos Ordinários, Agravos
- **TST**: Precedentes Administrativos, Recursos
- **TRTs**: Tribunais Regionais do Trabalho
- **TJs**: Tribunais de Justiça Estaduais (prioridade: TJSP, TJRJ, TJMG)
- **TRFs**: Tribunais Regionais Federais

### 2. Legislação
- **Constituição Federal** (1988 e Emendas)
- **Leis Ordinárias** (Código Civil, CPP, CLT, etc)
- **Leis Complementares**
- **Decretos Regulamentares
- **Medidas Provisórias
- **Súmulas** (STF, STJ, TST, TJs)
- **Enunciados** (TJPs, FNPs)

### 3. Doctrina
- Artigos acadêmicos de revistas Qualis A1/B1
- Teses e dissertações (BDTD, CAPES)
- Livros jurídicos digitalizados
- Comentários jurisprudenciais

### 4. Dados Complementares
- Diários Oficiais ( União, Estados, Municípios)
- Dados abertos do CNJ
- Estatísticas processuais
- Movimentação de precedentes

---

## AGENTES DO SKILL (34+ AGENTES) v3.0

### TRIBUNAL SUPREMO DE AGENTES

| ID | Agente | Qualificação | Função | Rating |
|----|--------|-------------|--------|--------|
| **25** | **JURISTA_SUPREMO_PHD** | PhD Summa ★★★ | Supervisor Máximo - Lexit Maximus | S+ |
| **13** | **GERENTE_SUPREMO_FEDERAL** | PhD ★★ | Diretor Jurídico Federal | S |

### CAMADA DE COORDENAÇÃO
| ID | Agente | Qualificação | Função Principal |
|----|--------|-------------|------------------|
| 00 | **juridico_orchestrator** | PhD | Coordenação central do pipeline |
| 34 | **coordenador_tribunais** | PhD | Coordenação multi-tribunal |

### CAMADA DE ENTRADA (ENCODER)
| ID | Agente | Qualificação | Função Principal |
|----|--------|-------------|------------------|
| 01 | **intent_parser_juridico** | PhD | Parsing de intent jurídica |
| 02 | **query_builder** | PhD | Construção de queries estruturadas |
| 03 | **tribunal_router** | PhD | Roteamento para tribunais específicos |
| 23 | **atualizador_conhecimento** | PhD | Atualização contínua do conhecimento |

### CAMADA DE DADOS (SCRAPERS)
| ID | Agente | Qualificação | Função Principal |
|----|--------|-------------|------------------|
| 04 | **lexml_scraper** | PhD | Scraping LexML/CNJ |
| 05 | **stf_stj_scraper** | PhD | Scraping STF/STJ |

### ESPECIALISTAS POR ÁREA DO DIREITO (9 ESPECIALISTAS)
| ID | Agente | Qualificação | Função Principal |
|----|--------|-------------|------------------|
| 14 | **especialista_civil** | PhD ★ | Obrigações, Contratos, Coisas |
| 15 | **especialista_constitucional** | PhD ★★★ | ADI, ADC, Controle Constitucionalidade |
| 16 | **especialista_penal** | PhD ★★★ | Penal, CPP, Crimes Hediondos |
| 17 | **especialista_trabalhista** | PhD ★ | CLT, TST, Reforma Trabalhista |
| 18 | **especialista_tributario** | PhD ★ | CTN, Impostos, Processo Fiscal |
| 19 | **especialista_consumidor** | PhD | CDC, Relações de Consumo |
| 20 | **especialista_administrativo** | PhD | Ato, Licitações, Contratos |
| 21 | **especialista_empresarial** | PhD | Societário, Falência, Recuperação |
| 22 | **especialista_internacional** | PhD ★ | Tratados, Arbitragem, Extradição |

### AGENTES CIRÚRGICOS GRANULARES (8 AGENTES)
| ID | Agente | Qualificação | Função Principal |
|----|--------|-------------|------------------|
| 26 | **analista_precedentes** | PhD ★ | Cirurgia de precedentes STF/STJ |
| 27 | **cirurgiao_recursos** | PhD ★ | Técnica de recursos |
| 28 | **auditor_citacoes** | PhD ★ | Auditoria de citações ABNT |
| 29 | **perito_linguagem** | PhD ★ | Linguagem jurídica formal |
| 30 | **estrategista_processual** | PhD ★ | Planejamento estratégico |
| 31 | **analista_vulnerabilidades** | PhD | Pontos fracos e riscos |
| 32 | **revisor_tese** | PhD ★ | Revisão de teses jurídicas |
| 33 | **gestor_tramites** | Mestre | Controle de prazos e protocolos |

### CAMADA DE PRODUÇÃO (DECODER)
| ID | Agente | Qualificação | Função Principal |
|----|--------|-------------|------------------|
| 06 | **petition_generator** | PhD ★ | Geração de petições especializadas |
| 07 | **fault_analyzer** | PhD ★★★ | Análise de falhas processuais |
| 08 | **counter_argument_builder** | PhD ★★★ | Construção de contra-argumentos |
| 10 | **citation_engine** | PhD | Formatação de citações ABNT |

### CAMADA DE VALIDAÇÃO
| ID | Agente | Qualificação | Função Principal |
|----|--------|-------------|------------------|
| 09 | **oab_validator** | PhD ★ | Validação OAB/critério STF |
| 24 | **qualidade_qualis** | PhD ★★★ | Validação Qualis A1 |

### CAMADA DE SAÍDA
| ID | Agente | Qualificação | Função Principal |
|----|--------|-------------|------------------|
| 11 | **document_formatter** | PhD | Formatação final PDF/DOCX |
| 12 | **audit_logger** | - | Logging de auditoria completo |

**LEGENDA:**
- **★★★** = PhD Summa com Lexit Maximus
- **★★** = PhD com avaliação em 7 dimensões
- **★** = PhD com avaliação em 5 dimensões
- **S+** = Rating Tribunal Supremo

---

## WORKFLOW DE EXECUÇÃO - PIPELINE GRANULAR SINCRONIZADO

### Pipeline Completo em 7 Fases

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           FASE 1: RECEPÇÃO E ANÁLISE                        │
├─────────────────────────────────────────────────────────────────────────────┤
│  [USUÁRIO INPUT]                                                          │
│       │                                                                    │
│       ▼                                                                    │
│  ┌──────────────────┐      ┌──────────────────┐                          │
│  │ 00_ORCHESTRATOR   │─────→│ 01_INTENT_PARSER │                          │
│  │ Coordenação       │      │ Extração NER     │                          │
│  └──────────────────┘      └────────┬─────────┘                          │
│                                      │                                     │
│                                      ▼                                     │
│                          ┌───────────────────────┐                        │
│                          │ 23_ATUALIZADOR_CONHEC  │                        │
│                          │ Busca Updates          │                        │
│                          └───────────────────────┘                        │
└─────────────────────────────────────────────────────────────────────────────┘
                                     │
                                     ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           FASE 2: CONSTRUÇÃO DE QUERY                       │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌──────────────────┐      ┌──────────────────┐                           │
│  │ 02_QUERY_BUILDER │─────→│ 03_TRIBUNAL_     │                           │
│  │ Queries Bool.    │      │ ROUTER           │                           │
│  └──────────────────┘      └────────┬─────────┘                           │
│                                      │                                     │
│                        ┌─────────────┼─────────────┐                       │
│                        ▼             ▼             ▼                         │
│                   ┌────────┐   ┌────────┐   ┌─────────┐                     │
│                   │ LexML  │   │STF/STJ │   │Diário   │                     │
│                   │ (04)   │   │ (05)   │   │Oficial  │                     │
│                   └────┬───┘   └────┬───┘   └────┬────┘                     │
│                        └────────────┴────────────┘                          │
└─────────────────────────────────────────────────────────────────────────────┘
                                     │
                                     ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                     FASE 3: SELEÇÃO DE ESPECIALISTA                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                              Área Identificada?                             │
│            ┌──────────────────┬──────────────────┬────────────────┐       │
│            │ CIVEL/CONSUMIDOR │ CONSTITUCIONAL   │ PENAL          │       │
│            ▼                  ▼                  ▼                │       │
│     ┌──────────────┐   ┌──────────────┐   ┌──────────────┐        │       │
│     │14_CIVIL     │   │15_CONSTITUC. │   │16_PENAL     │        │       │
│     │18_TRIBUTÁRIO│   │13_GER.SUPREMO│   │22_INTERNAC. │        │       │
│     │21_EMPRESAR. │   │              │   │              │        │       │
│     └──────────────┘   └──────────────┘   └──────────────┘        │       │
│            │                  │                  │                   │       │
│            │ TRABALHISTA      │ ADMINISTRATIVO   │ FAMILIA          │       │
│            ▼                  ▼                  ▼                   │       │
│     ┌──────────────┐   ┌──────────────┐   ┌──────────────┐        │       │
│     │17_TRABALHISTA│  │20_ADMINIST.  │   │ESPECIALISTA  │        │       │
│     └──────────────┘   └──────────────┘   │FAMILIA       │        │       │
│                                           └──────────────┘        │       │
└─────────────────────────────────────────────────────────────────────────────┘
                                     │
                                     ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         FASE 4: PRODUÇÃO JURÍDICA                           │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌──────────────────┐      ┌──────────────────┐      ┌──────────────────┐ │
│  │ 06_PETITION_GEN  │─────→│ 07_FAULT_ANALYZER│─────→│ 08_COUNTER_ARGS  │ │
│  │ Gera Documento   │      │ Análise Crítica  │      │ Contra-Argumentos│ │
│  └──────────────────┘      └──────────────────┘      └────────┬─────────┘ │
│                                                              │             │
│                                                              ▼             │
│                                                    ┌──────────────────┐   │
│                                                    │ 10_CITATION     │   │
│                                                    │ Formata Citações │   │
│                                                    └────────┬─────────┘   │
└─────────────────────────────────────────────────────────────┼─────────────┘
                                                              │
                                                              ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           FASE 5: VALIDAÇÃO DUAL                            │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌──────────────────┐                        ┌──────────────────┐            │
│  │ 09_OAB_VALIDATOR │                        │ 24_QUALIS_A1    │            │
│  │ Rigor OAB/STF    │                        │ Padrão Acadêmico│            │
│  │ Score: 7 dims    │                        │ Qualis A1       │            │
│  └────────┬─────────┘                        └────────┬─────────┘            │
│           │                                         │                       │
│           └────────────────┬────────────────────────┘                       │
│                            ▼                                                │
│                   ┌──────────────────┐                                      │
│                   │ 13_GERENTE_SUPREMO│                                     │
│                   │ PHD - AVALIAÇÃO   │                                     │
│                   │ FINALE            │                                     │
│                   └────────┬─────────┘                                      │
│                            │                                                │
│                   ┌────────┴─────────┐                                       │
│                   │ DECISÃO PhD:     │                                       │
│                   │ ✓ APROVADO PHD   │                                       │
│                   │ ⚠ REVISÃO MENOR │                                       │
│                   │ ✗ REPROVADO     │                                       │
│                   └──────────────────┘                                       │
└─────────────────────────────────────────────────────────────────────────────┘
                                     │
                                     ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           FASE 6: FORMATAÇÃO FINAL                           │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌──────────────────┐      ┌──────────────────┐      ┌──────────────────┐     │
│  │ 11_DOC_FORMATTER │─────→│ 12_AUDIT_LOGGER │─────→│ EXPORTAÇÃO      │     │
│  │ PDF/DOCX/HTML   │      │ Trilha Auditoria│      │ PRONTO USO      │     │
│  └──────────────────┘      └──────────────────┘      └──────────────────┘     │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Workflow por Tipo de Documento

#### PETIÇÃO INICIAL CÍVEL
```
[00] → [01] → [02] → [03] → [04/05] → [14_CIVIL] → [06] → [09] → [24] → [13_PHD] → [11] → [12]
```

#### ANÁLISE DE PRECEDENTE STF
```
[00] → [01] → [02] → [03] → [05_STF] → [15_CONSTITUCIONAL] → [07] → [08] → [13_PHD] → [12]
```

#### DEFESA TRABALHISTA
```
[00] → [01] → [02] → [03] → [04/05] → [17_TRABALHISTA] → [06] → [09] → [24] → [13_PHD] → [11] → [12]
```

#### RECURSO ESPECIAL STJ
```
[00] → [01] → [02] → [03] → [05_STJ] → [ESPECIALISTA_MATERIA] → [07] → [08] → [09] → [13_PHD] → [11] → [12]
```

---

## FONTES DE DADOS

### 1. APIs Oficiais

```yaml
sources:
  LexML:
    url: "https://www.lexml.gov.br/"
    type: "API REST"
    coverage: "legislação completa, jurisprudência indexada"
    
  STF:
    url: "https://portal.stf.jus.br/"
    endpoints:
      jurisprudencia: "/servicos/jurisprudencia/"
      acordaos: "/servicos/acordaos/"
    type: "Web Scraping + API"
    
  STJ:
    url: "https://www.stj.jus.br/"
    endpoints:
      jurisprudencia: "/jurisprudencia/"
    type: "Web Scraping"
    
  CNJ:
    url: "https://www.cnj.jus.br/"
    dados_abertos: "/dados-abertos/"
    type: "API REST + CSV"
    
  Diários Oficiais:
    url: "https://www.in.gov.br/"
    type: "API REST"
    coverage: "Diário Oficial da União + Estados"
```

### 2. Scrapers Especializados

| Tribunal | URL Base | Método | Frequência |
|----------|----------|--------|------------|
| TJSP | www.tjsp.jus.br | Scraping | Tempo real |
| TJRJ | www.tjrj.jus.br | Scraping | Tempo real |
| TJMG | www.tjmg.jus.br | Scraping | Tempo real |
| TRF1 | www.trf1.jus.br | Scraping | Tempo real |
| TST | www.tst.jus.br | API | Tempo real |

### 3. Bases de Dados Complementares

```yaml
doctrine:
  - name: "Google Scholar"
    url: "scholar.google.com"
  - name: "SciELO"
    url: "www.scielo.br"
  - name: "CAPES"
    url: "catalogodeteses.capes.gov.br"
  - name: "BDTD"
    url: "bdtd.ibict.br"
```

---

## TEMPLATES JURÍDICOS EXPANDIDOS (11+ Templates)

### Petições Cíveis
- `peticion_inicial_civel.md` - Petição inicial cível padrão
- `acao_civil_publica.md` - Ação civil pública
- `mandado_de_seguranca.md` - Mandado de segurança
- `acao_anulatoria_tributaria.md` - Ação anulatória tributária

### Petições Trabalhistas
- `reclamacao_trabalhista.md` - Reclamação trabalhista CLT

### Petições Criminais
- `denuncia_criminal.md` - Notitia Criminis
- `defesa_previa_criminal.md` - Defesa prévia CPP

### Procedimentos Sucessórios
- `inventario.md` - Inventário judicial

### Recursos
- `recurso.md` - Recursos em geral (CPC, CLT, CPP)
- `analise_falhas.md` - Análise de falhas processuais
- `contra_argumentacao.md` - Contra-argumentação OAB

### Exemplo: Petição Inicial

```markdown
# [TIPO DA PETIÇÃO]

## CABEÇALHO
EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) DE DIREITO DA __VARA__ 
DA COMARCA DE __COMARCA__
ESTADO DE __ESTADO__

__CLASSE PROCESSUAL__, por seu(sua) advogado(a) subscrito(a), 
[JULGADOR] [NATUREA], com escritório profissional em [ENDEREÇO], 
onde recebe intimações, nos autos da [AÇÃO] em face de [RÉU],
[/proc-se], vem, respeitosamente, à presença de Vossa Excelência, 
com fundamento no artigo [FUNDAMENTO LEGAL], 

## I - DOS FATOS
[Conteúdo]

## II - DO DIREITO
[Conteúdo com fundamentação legal e jurisprudencial]

## III - DOS REQUERIMENTOS
[Lista de pedidos]

## IV - DOS PEDIDOS
Ante o exposto, requer:
1. [Pedido 1]
2. [Pedido 2]

## V - DO VALOR DA CAUSA
R$ [VALOR]

## VI - DAS PROVAS
Protesta provar o alegado por todos os meios de prova em direito admitidos.

## VII - DAS DISPOSIÇÕES FINAIS
Dá-se à causa o valor de R$ [VALOR].

Termos em que,
Pede deferimento.

[CIDADE], [DATA]

___________________________
[ADVOGADO]
OAB/[ESTADO] [NÚMERO]
```

### Template: Análise de Falhas

```markdown
# RELATÓRIO DE ANÁLISE DE FALHAS PROCESSUAIS

## 1. IDENTIFICAÇÃO
- **Processo**: [NÚMERO]
- **Tribunal**: [TRIBUNAL]
- **Relator**: [RELATOR]
- **Data**: [DATA]

## 2. TESE ANALISADA
[Descrição da tese principal]

## 3. FALHAS IDENTIFICADAS

### 3.1 Falha Material
- **Tipo**: Erro de fato/direito
- **Localização**: [Trecho do acórdão]
- **Fundamentação**: [Base legal violada]

### 3.2 Falha Processual
- **Tipo**: Cerceamento de defesa/vício processual
- **Impacto**: [Alto/Médio/Baixo]
- **Precedentes**: [STFx/SSTJx]

### 3.3 Falha Jurisprudencial
- **Tipo**: Divergência com precedente vinculante
- **Precedente**: [ADI/ADC/Repercussão Geral]

## 4. CONTRA-ARGUMENTAÇÃO
### 4.1 Fundamentação Legal
[Artigos e leis aplicáveis]

### 4.2 Jurisprudência de Suporte
| Tribunal | Número | Tema | Status |
|----------|--------|------|--------|
| STF | RE xxx | Tema xxx | ... |

### 4.3 Doctrina Relevante
[Autores e obras]

## 5. RECOMENDAÇÃO ESTRATÉGICA
[Próximos passos]

## 6. QUALIFICAÇÃO OAB
- **Revisado por**: [Advogado OAB]
- **Status**: Aprovado/Rejeitado
```

---

## CRITÉRIOS DE VALIDAÇÃO OAB/STF

### Checklist de Rigor Jurídico

```yaml
validacao_oab:
  estrutural:
    - nome_julgador_correto
    - orgao_julgador_adequado
    - endereco_profissional_completo
    - numero_oab_valido
    - classe_processual_correta
    
  processual:
    - fundamento_legal_existente
    - jurisprudencia_atualizada
    - precedente_vinculante_se_aplicavel
    - repercussao_geral_observada
    - prazo_prescricional_verificado
    
  material:
    - fato_conexo_direito
    - pedido_consonante_fato
    - valor_causa_justificado
    - documentacao_anexa
    - procuração_ativa
    
  formal:
    - linguagem_juridica_correta
    - ausencia_vicios_redacao
    - formatacao_cnj
    - assinatura_eletronica
```

### Critérios STF para Vinculação

```yaml
vinculacao_stf:
  adin_adc_ado:
    efeito: "vinculante"
    abrangencia: "todos_os_entes"
    
  repercussao_geral:
    temas: "obrigatorios"
    recursos: "suspensos_ate_decisao"
    
  sumula_vinculante:
    efeito: "vinculante"
    aplicacao: "immediate"
    
  causa_piloto:
    efeito: "referencia"
    multiplicidade: "art_543-B"
```

---

## SCRIPTS DE SCRAPING

### Arquivo: references/scrapers_guide.md

```markdown
# GUIA DE SCRAPERS JURÍDICOS BRASILEIROS

## 1. LexML Brasil

### Endpoint Principal
https://www.lexml.gov.br/

### Queries Common
- Legislação: `/busca/resultado?termo={termo}&tipo=lei`
- Jurisprudência: `/busca/resultado?termo={termo}&tipo=jurisprudencia`

### Rate Limiting
- 10 requests/minuto
- Chave API disponível em: https://www.lexml.gov.br/sobre/api

## 2. Portal STF

### Estrutura de URLs
- Acórdãos: `https://portal.stf.jus.br/jurisprudencia/repercussao/{id}`
- Decisões Monocráticas: `https://portal.stf.jus.br/jurisprudencia/decisoes/{id}`

### Parser
```python
def parse_stf_decisao(html):
    # Extrair: número processo, relator, data, ementa, decisão
    pass
```

## 3. STJ Jurisprudência

### API Não-Oficial
- Base URL: `https://www.stj.jus.br/jurisprudencia`
- Formato: `/pesquisa.html?new=search_norm_interno.html`
```

---

## MÉTRICAS DE QUALIDADE PhD v3.0

### KPIs por Agente Tribunal Supremo

| Agente | Precisão | Latência | Target |
|--------|----------|----------|--------|
| **25_JURISTA_SUPREMO_PHD** | 99.9% | 60s | Lexit Maximus |
| **13_GERENTE_SUPREMO_FEDERAL** | 99% | 45s | Aprovação Federal |
| 15_ESPECIALISTA_CONSTITUCIONAL | 98% | 40s | ADI/ADC/RE |
| 16_ESPECIALISTA_PENAL | 98% | 35s | Defesas Criminais |
| 26_ANALISTA_PRECEDENTES | 97% | 30s | Cirurgia Precedentes |
| 27_CIRURGIAO_RECURSOS | 96% | 35s | Técnica Recursal |
| 28_AUDITOR_CITACOES | 99% | 20s | ABNT Válidas |

### KPIs de Qualidade Sistema v3.0

| Métrica | Target | Crítico | 
|---------|--------|---------|
| **Conformidade OAB** | 100% | <100% |
| **Qualis A1 Compliance** | 98% | <95% |
| **Score PhD 7 Dimensões** | ≥90% | <80% |
| **Citations ABNT Válidas** | 100% | <98% |
| **Completude Documental** | 99% | <97% |
| **Jurisprudência Atual** | 100% | <95% |
| **Lexit Maximus Rate** | 50% | <30% |
| **Aprovação Primeira** | 90% | <75% |

### Métricas de Performance

| Métrica | Target | Crítico |
|---------|--------|---------|
| **Latência Total Pipeline** | <120s | >180s |
| **Tempo Busca Multi-Tribunal** | <25s | >40s |
| **Throughput Simultâneo** | 8 docs | 3 docs |
| **Taxa Sucesso Geral** | 99% | <97% |
| **Referências Auditadas** | 100% | <95% |

---

## CASOS DE USO

### Caso 1: Petição por Danos Morais
```
INPUT: "Gere petição inicial de danos morais contra banco X por inscrição 
       indevida no SPC, valor R$ 50.000, comarca São Paulo, 2ª Vara 
       Cível. Busque jurisprudência recente do TJSP."

OUTPUT: Petição completa com:
- Cabeçalho correto
- Fundamentação legal (CDC, Lei 9.613/98)
- Jurisprudência TJSP 2024
- Precedentes STJ
- Pedidos específicos
- Valor da causa
```

### Caso 2: Análise de Falhas em Recurso
```
INPUT: "Analise o RE 1.000.000 e identifique possíveis falhas 
       processuais e como rebater."

OUTPUT: Relatório estruturado com:
- Identificação do precedente
- Falhas materiais identificadas
- Falhas processuais
- Contra-argumentação OAB
- Recomendação estratégica
```

### Caso 3: Pesquisa de Precedentes
```
INPUT: "Encontre todos os precedentes do STF sobre 'desconsideração 
       da personalidade jurídica' com repercussão geral."

OUTPUT: Lista estruturada com:
- Temas vinculados
- Decisions por anno
- Ementas resumidas
- Citações em formato padrão
```

---

## STARTUP v3.0

```
═══════════════════════════════════════════════════════════════════════════════════
                    JURÍDICO BRASIL v3.0 - JURISTA SUPREMO PhD SUMMA
═══════════════════════════════════════════════════════════════════════════════════

⚖️ SISTEMA DE ADVOCACIA UNIVERSAL PhD SUMMA ATIVADO
   34+ Agentes Especializados | Rigor OAB/STF | Padrão Qualis A1
   Referências Bibliográficas Reais Auditáveis

═══════════════════════════════════════════════════════════════════════════════════

👨‍⚖️ TRIBUNAL SUPREMO DE AGENTES
   [25] JURISTA SUPREMO PhD...... [✓] ★★★ LEXIT MAXIMUS - DIRETOR LEGUM MAXIME
   [13] GERENTE SUPREMO FEDERAL.. [✓] ★★ DIRETOR JURÍDICO FEDERAL

📚 CAMADA DE COORDENAÇÃO
   [00] ORQUESTRADOR............. [✓] PhD
   [34] COORDENADOR_TRIBUNAIS... [✓] PhD

📥 CAMADA DE ENTRADA
   [01] INTENT_PARSER........... [✓] PhD
   [02] QUERY_BUILDER........... [✓] PhD
   [03] TRIBUNAL_ROUTER......... [✓] PhD
   [23] ATUALIZADOR_CONHEC...... [✓] PhD

📊 CAMADA DE DADOS
   [04] LEXML_SCRAPER........... [✓] PhD
   [05] STF_STJ_SCRAPER......... [✓] PhD

⚖️ ESPECIALISTAS POR ÁREA DO DIREITO (9)
   [14] CIVIL................... [✓] PhD ★
   [15] CONSTITUCIONAL.......... [✓] PhD ★★★
   [16] PENAL.................. [✓] PhD ★★★
   [17] TRABALHISTA............ [✓] PhD ★
   [18] TRIBUTÁRIO............. [✓] PhD ★
   [19] CONSUMIDOR............. [✓] PhD
   [20] ADMINISTRATIVO......... [✓] PhD
   [21] EMPRESARIAL........... [✓] PhD
   [22] INTERNACIONAL.......... [✓] PhD ★

🔬 AGENTES CIRÚRGICOS GRANULARES (8)
   [26] ANALISTA_PRECEDENTES.... [✓] PhD ★ CIRURGIA PRECISÃO
   [27] CIRURGIÃO_RECURSOS..... [✓] PhD ★ TÉCNICA RECURSAL
   [28] AUDITOR_CITAÇÕES....... [✓] PhD ★ ABNT AUDITADO
   [29] PERITO_LINGUAGEM...... [✓] PhD ★ LÍNGUA CULTA
   [30] ESTRATEGISTA........... [✓] PhD ★ PLANEJAMENTO
   [31] ANALISTA_VULNERABIL... [✓] PhD ANÁLISE RISCO
   [32] REVISOR_TESE........... [✓] PhD ★ CONSISTÊNCIA
   [33] GESTOR_TRÂMITES....... [✓] Mestre PRAZOS

📝 CAMADA DE PRODUÇÃO
   [06] PETITION_GENERATOR..... [✓] PhD ★
   [07] FAULT_ANALYZER......... [✓] PhD ★★★
   [08] COUNTER_ARG_BUILDER... [✓] PhD ★★★
   [10] CITATION_ENGINE....... [✓] PhD

✅ CAMADA DE VALIDAÇÃO
   [09] OAB_VALIDATOR.......... [✓] PhD ★
   [24] QUALIDADE_QUALIS....... [✓] PhD ★★★ QUALIS A1

📤 CAMADA DE SAÍDA
   [11] DOC_FORMATTER.......... [✓] PhD
   [12] AUDIT_LOGGER........... [✓] COMPLETO

═══════════════════════════════════════════════════════════════════════════════════

📋 DIREITOS COBERTOS:
   ✓ Constitucional    ✓ Civil          ✓ Penal
   ✓ Trabalhista      ✓ Tributário     ✓ Consumidor
   ✓ Administrativo   ✓ Empresarial    ✓ Internacional
   ✓ Família          ✓ Ambiental      ✓ Digital

═══════════════════════════════════════════════════════════════════════════════════

📚 REFERÊNCIAS BIBLIOGRÁFICAS:
   ✓ Índice de Autoridades Reais (100+ obras)
   ✓ Precedentes STF/STJ Auditados
   ✓ Revistas Qualis A1/A2
   ✓ Autores Classificados por Matéria

═══════════════════════════════════════════════════════════════════════════════════

PARA INICIAR, INFORME:

1. **TIPO DE DOCUMENTO:**
   • "Gere petição inicial de [tipo]"
   • "Analise recurso [número]"
   • "Elabore defesa em [ação]"
   • "Estude precedente [STF/STJ]"
   • "Audite citações de [documento]"

2. **ÁREA DO DIREITO:**
   • Civil, Constitucional, Penal, Trabalhista
   • Tributário, Consumidor, Empresarial
   • Administrativo, Internacional, Ambiental

3. **TRIBUNAIS:**
   • STF, STJ, TJSP, TJRJ, TST, TRTs
   • TRFs, TSE, STM, CARF

4. **URGÊNCIA:**
   • Normal (Padrão OAB)
   • Urgente (Prioridade PhD)
   • Imediato (Lexit Jurista Supremo)

═══════════════════════════════════════════════════════════════════════════════════

★ RATINGS DE APROVAÇÃO:
   ⚖️ LEXIT MAXIMUS (97-100) - Pronto protocolo imediato
   ✓ APROVADO (90-96) - Pronto com ajustes
   ⚠ APROVADO C/RESSALVAS (80-89) - Revisão menor
   ⚠ REVISÃO NECESSÁRIA (65-79) - Reformulação
   ✗ REJEITADO (<65) - Rebase completo

═══════════════════════════════════════════════════════════════════════════════════
```

---

## TROUBLESHOOTING

| Problema | Causa | Solução |
|----------|-------|---------|
| Busca sem resultados | Query mal formatada | Verificar termos em PT-BR |
| Jurisprudência desatualizada | Cache | Forçar refresh com `refresh: true` |
| Validação OAB falhou | Formato incorreto | Revisar template |
| Rate limit excedido | Muitas requisições | Aguardar 60s |
| Tribunal offline | Manutenção | Usar fonte alternativa |

---

## ESTRUTURA DO SKILL v3.0 (34+ AGENTES)

```
.juridico-brasil/
├── SKILL.md                         # Arquitetura principal v3.0
├── README.md                        # Documentação
│
├── agents/                          # 34+ AGENTES ESPECIALIZADOS
│   │
│   ├── TRIBUNAL_SUPREMO/
│   │   ├── 25_jurista_supremo_phd.md      # ★★★ PhD Summa - LEXIT MAXIMUS
│   │   └── 13_gerente_supremo_federal.md   # ★★ PhD - Diretor Federal
│   │
│   ├── CAMADA_COORDENACAO/
│   │   ├── 00_juridico_orchestrator.md     # Coordenação PhD
│   │   └── 34_coordenador_tribunais.md     # Multi-tribunal PhD
│   │
│   ├── CAMADA_ENTRADA/
│   │   ├── 01_intent_parser_juridico.md    # NER Jurídico PhD
│   │   ├── 02_query_builder.md              # Queries PhD
│   │   ├── 03_tribunal_router.md            # Roteamento PhD
│   │   └── 23_atualizador_conhecimento.md   # Updates PhD
│   │
│   ├── CAMADA_DADOS/
│   │   ├── 04_lexml_scraper.md              # LexML/CNJ PhD
│   │   └── 05_stf_stj_scraper.md           # STF/STJ PhD
│   │
│   ├── ESPECIALISTAS_DIREITO/              # 9 ESPECIALISTAS PhD
│   │   ├── 14_especialista_civil.md         # ★ Civil
│   │   ├── 15_especialista_constitucional.md # ★★★ Constitucional
│   │   ├── 16_especialista_penal.md        # ★★★ Penal
│   │   ├── 17_especialista_trabalhista.md  # ★ Trabalhista
│   │   ├── 18_especialista_tributario.md   # ★ Tributário
│   │   ├── 19_especialista_consumidor.md   # Consumidor
│   │   ├── 20_especialista_administrativo.md # Administrativo
│   │   ├── 21_especialista_empresarial.md # Empresarial
│   │   └── 22_especialista_internacional.md # ★ Internacional
│   │
│   ├── AGENTES_CIRURGICOS/               # 8 AGENTES GRANULARES
│   │   ├── 26_analista_precedentes_cirurgico.md  # ★ Cirurgia
│   │   ├── 27_cirurgiao_recursos.md              # ★ Recursos
│   │   ├── 28_auditor_citacoes.md                 # ★ Citações
│   │   ├── 29_perito_linguagem_juridica.md       # ★ Linguagem
│   │   ├── 30_estrategista_processual.md          # ★ Estratégia
│   │   ├── 31_analista_vulnerabilidades.md        # Vulnerabilidades
│   │   ├── 32_revisor_tese.md                     # ★ Tese
│   │   └── 33_gestor_tramites.md                 # Trâmites
│   │
│   ├── CAMADA_PRODUCAO/
│   │   ├── 06_petition_generator.md        # ★ PhD
│   │   ├── 07_fault_analyzer.md            # ★★★ PhD
│   │   ├── 08_counter_argument_builder.md  # ★★★ PhD
│   │   └── 10_citation_engine.md           # PhD
│   │
│   ├── CAMADA_VALIDACAO/
│   │   ├── 09_oab_validator.md              # ★ PhD
│   │   └── 24_especialista_qualidade_qualis.md  # ★★★ Qualis A1
│   │
│   └── CAMADA_SAIDA/
│       ├── 11_document_formatter.md        # PDF/DOCX PhD
│       └── 12_audit_logger.md              # Auditoria
│
├── templates/                       # 11+ TEMPLATES
│   ├── peticion_inicial_civel.md
│   ├── recurso.md
│   ├── analise_falhas.md
│   ├── contra_argumentacao.md
│   ├── acao_civil_publica.md
│   ├── mandado_de_seguranca.md
│   ├── reclamacao_trabalhista.md
│   ├── acao_anulatoria_tributaria.md
│   ├── denuncia_criminal.md
│   ├── defesa_previa_criminal.md
│   └── inventario.md
│
└── references/                      # CONHECIMENTO AUDITÁVEL
    ├── scrapers_guide.md            # APIs
    ├── legislacao_index.md         # Leis + CTN + CDC + CLT
    ├── jurisprudencia_index.md      # STF/STJ/TST + Súmulas
    └── autoridades_bibliografia.md  # ★ REFERÊNCIAS REAIS AUDITÁVEIS
```

---

## 7 DIMENSÕES PhD - AVALIAÇÃO DO TRIBUNAL SUPREMO

| Dim | Nome | Peso | Descrição |
|-----|------|------|-----------|
| 1 | Fundamentação Teórica | 20% | Coerência, profundidade, Qualis A1, Originalidade |
| 2 | Conformidade Constitucional | 25% | CF, SV, ADC, Princípios Fundamentais |
| 3 | Qualidade Argumentativa | 20% | Clareza, coesão, originalidade, Lógica |
| 4 | Precedentes | 15% | Atualização, pertinência, Vinculação |
| 5 | Estratégia Processual | 10% | Timing, adequação, Prazo |
| 6 | Linguagem | 5% | Norma culta, terminologia, Elegância |
| 7 | Completude | 5% | Seções obrigatórias, Anexos, Provas |

### Ratings de Aprovação

| Rating | Score | Status | Significado |
|--------|-------|--------|-------------|
| **Lexit Maximus** | 97-100 | ⚖️ | Pronto para protocolo imediato |
| **Aprovado** | 90-96 | ✓ | Pronto com ajustes mínimos |
| **Aprovado c/Ressalvas** | 80-89 | ⚠ | Revisão menor necessária |
| **Revisão Necessária** | 65-79 | ⚠ | Reformulação substancial |
| **Rejeitado** | <65 | ✗ | Rebase completo |

---

## ÍNDICE DE AUTORIDADES

O skill inclui referência a **100+ obras jurídicas reais** dos seguintes autores:

### Direito Constitucional
- BARROSO, MENDES, SILVA, LENZA, SARLET

### Direito Processual Civil
- DINAMARCO, MARINONI, WAMBIER, DIDIER, THEODORO JÚNIOR

### Direito Civil
- PEREIRA, GAGLIANO, DINIZ, GONÇALVES, VENOSA

### Direito Penal
- BITENCOURT, GRECO, CAPEZ, NUCCI, PRADO

### Direito Trabalhista
- DELGADO, MARTINS, CASSAR, NASCIMENTO

### Direito Tributário
- BALEEIRO, CARVALHO, ATALIBA, SCHOUERI, DERZI

---

*JURÍDICO BRASIL v3.0*
*JURISTA SUPREMO PhD SUMMA - Rede Transformer de 34+ Agentes*
*Compatible with MASWOS V5 NEXUS & OpenCode*
*Qualificação: OAB | STF | STJ | QUALIS A1 | PHD_SUMMA*
*★★★ = PhD Summa com Lexit Maximus | ★★ = PhD Federal | ★ = PhD Standard*
