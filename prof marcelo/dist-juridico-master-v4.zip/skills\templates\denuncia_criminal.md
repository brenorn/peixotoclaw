# TEMPLATE: DENÚNCIA CRIMINAL

## Estrutura Completa

```
EXCELENTÍSSIMO(A) SENHOR(A) {AUTORIDADE POLICIAL | JUIZ DE DIREITO | PROMOTOR DE JUSTIÇA}

{OUTORGANTE}, [QUALIFICAÇÃO COMPLETA], [/endereço], [/cpf], [/telefone], vem respeitosamente à presença de Vossa Excelência comunicar

## NOTITIA CRIMINIS – COMUNICAÇÃO DE CRIME

contra {AUTOR}, [QUALIFICAÇÃO OU DESCRIÇÃO], [/endereço_se_conhecido], pelos fatos a seguir:

---

### I – DOS FATOS

{Narrativa objetiva e cronológica da conduta delitiva}

---

### II – DA PROVA DA MATERIALIDADE

{Indicação das provas da materialidade delitiva}

- Laudo Pericial: {se houver}
- Boletim de Ocorrência: {se houver}
- Outros documentos: {listar}

---

### III – DA PROVA DA AUTORIA

{Indicação das provas da autoria}

---

### IV – DA TIPIFICAÇÃO

A conduta de {AUTOR} configura, em tese, o crime previsto no art. {XX} do Código Penal {OU LEI ESPECIAL}, por {DESCRIÇÃO DA CONDUTA}.

---

### V – DOS REQUERIMENTOS

Requer:

a) A instauração de {INQUÉRITO POLICIAL | NOTITIA CRIMINIS};

b) A {DILIGÊNCIAS NECESSÁRIAS};

c) {OUTROS REQUERIMENTOS};

---

{local}, {data}

_______________________________
{OUTORGANTE}
CPF: {NÚMERO}
```
