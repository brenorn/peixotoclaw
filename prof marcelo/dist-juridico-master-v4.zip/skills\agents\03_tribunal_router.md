---
name: 03_tribunal_router
type: specialist
domain: legal
gate_in: G3
gate_out: G4
criticality: high
---

# AGENTE 03: TRIBUNAL ROUTER

## Perfil de Competência

**Função:** Roteia queries para os tribunais e fontes de dados apropriados, gerencia execução paralela e agrega resultados.

**Responsabilidades:**
- Identificar tribunais específicos por área do direito
- Rotear queries para fontes corretas
- Executar buscas em paralelo quando possível
- Agregar resultados de múltiplas fontes
- Deduplicar resultados
- Ordenar por relevância
- Tratar erros de formagraceful

**Limitações Conhecidas:**
- Máximo 5 requisições simultâneas
- Alguns tribunais podem estar indisponíveis
- Rate limiting varia por fonte

---

## Protocolo de Execução

### Input
```yaml
tipo: QuerySpec
fonte: 02_query_builder
validações:
  - fontes_nao_vazia
  - queries_validas
```

### Processamento

**Fase 1 - Roteamento por Área**

```yaml
area_mapping:
  constitucional:
    fontes_principais:
      - STF (pleno, turmas)
      - LexML (CF, ADI, ADC)
    fontes_secundarias:
      - STJ (repercussão geral)
      
  civel:
    fontes_principais:
      - TJ da comarca específica
      - STJ (recursos especiais)
    fontes_secundarias:
      - LexML (Código Civil, CPC)
      - TRF (se federal)
      
  trabalhista:
    fontes_principais:
      - TST
      - TRT da região
    fontes_secundarias:
      - LexML (CLT)
      - TST jurisprudência
      
  penal:
    fontes_principais:
      - STF (HC, RE)
      - STJ (RHC, recursos)
    fontes_secundarias:
      - TJ (se estadual)
      - TRF (se federal)
      
  tributario:
    fontes_principais:
      - STF (ADIs tributárias)
      - STJ (recursos especiais)
      - CARF
    fontes_secundarias:
      - LexML (CTN, CF art. 150-156)
      - TRFs
```

**Fase 2 - Execução Paralela**
```yaml
estrategia: "parallel_with_fallback"
config:
  max_concurrent: 5
  timeout_per_source: 30s
  retry_on_failure: 3
  fallback_order:
    - fonte_primaria
    - fonte_secundaria
    - fonte_alternativa
```

**Fase 3 - Agregação**
```yaml
agregacao:
  deduplicacao: true
  criterio_dedup: "hash_ementa"
  ordenacao:
    - score_relevancia (peso 0.4)
    - data (peso 0.3)
    - tribunal_rank (peso 0.2)
    - citacoes (peso 0.1)
```

### Output
```yaml
tipo: SearchResults
formato: structured_json
destino: 07_fault_analyzer ou 06_petition_generator
estrutura:
  resultados:
    - fonte: string
      tipo: enum[acordao, lei, norma, informativ]
      titulo: string
      ementa: string
      numero: string
      data: date
      url: string
      score: float
      partes_relevantes: list[string]
  metadata:
    total_resultados: number
    fontes_utilizadas: list[string]
    tempo_execucao: number
    qualidade: enum[excelente, bom, regular, baixo]
```

### Critérios de Qualidade
```yaml
threshold_minimo: 0.75
checklist:
  - minimo_3_fontes_consultadas
  - minimo_5_resultados_relevantes
  - deduplicacao_aplicada
  - ordenacao_por_relevancia
flag_se_falhar: partial_results_with_warning
```

---

## Handoff Protocol

### Recebe de
```yaml
agente: 02_query_builder
valida_input:
  - query_spec_contendo_fontes
  - parametros_consulta
```

### Envia para
```yaml
agente: 07_fault_analyzer (se intent=analise_falhas)
agente: 06_petition_generator (se intent=peticao)
agente: 05_stf_stj_scraper (se mais dados necessários)
```

---

## Códigos de Tribunal

```yaml
tribunais_federais:
  STF: "Supremo Tribunal Federal"
  STJ: "Superior Tribunal de Justiça"
  TST: "Tribunal Superior do Trabalho"
  CSJT: "Conselho Superior da Justiça do Trabalho"
  TRF1: "Tribunal Regional Federal 1ª Região"
  TRF2: "Tribunal Regional Federal 2ª Região"
  TRF3: "Tribunal Regional Federal 3ª Região"
  TRF4: "Tribunal Regional Federal 4ª Região"
  TRF5: "Tribunal Regional Federal 5ª Região"

tribunais_estaduais:
  TJSP: "Tribunal de Justiça de São Paulo"
  TJRS: "Tribunal de Justiça do Rio Grande do Sul"
  TJRJ: "Tribunal de Justiça do Rio de Janeiro"
  TJMG: "Tribunal de Justiça de Minas Gerais"
  TJPR: "Tribunal de Justiça do Paraná"
  TJSC: "Tribunal de Justiça de Santa Catarina"
  TJBA: "Tribunal de Justiça da Bahia"
  TJC E: "Tribunal de Justiça de Ceará"
  TJGO: "Tribunal de Justiça de Goiás"
  TJD F: "Tribunal de Justiça do Distrito Federal"
```

---

## Métricas
```yaml
latência_target: 15s
precisão_target: 88%
KPIs:
  fontes_consultadas: 100%
  taxa_sucesso: 95%
  deduplicacao_rate: 15%
  avg_result_quality: 0.85
```

---

*AGENTE 03 - TRIBUNAL ROUTER v1.0*
