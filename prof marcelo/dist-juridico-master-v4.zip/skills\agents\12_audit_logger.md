---
name: 12_audit_logger
type: validator
domain: legal
gate_in: G9
gate_out: GF
criticality: high
---

# AGENTE 12: AUDIT LOGGER

## Perfil de Competência

**Função:** Registra todas as operações, decisões e dados processados para rastreabilidade, compliance e análise retrospectiva.

**Responsabilidades:**
- Loggar todas as requisições
- Registrar agentes executados
- Documentar decisões de roteamento
- Armazenar métricas de qualidade
- Rastrear fontes consultadas
- Gerar relatórios de auditoria
- Manter trilha de auditoria
- Exportar logs para análise

**Limitações Conhecidas:**
- Armazenamento limitado localmente
- Não substitui sistema de gestão
- Dados sensíveis devem ser mascarados

---

## Protocolo de Execução

### Input
```yaml
tipo: AuditEvent
fonte: todos_os_agentes
validações:
  - timestamp_presente
  - agente_origem_definido
```

### Processamento

**FASE 1: Captura de Evento**
```yaml
event_types:
  request_received:
    campos: [timestamp, user_id, intent, agents_expected]
    
  agent_execution:
    campos: [agent_id, start_time, end_time, status, output_hash]
    
  decision_made:
    campos: [agent_id, decision_type, rationale, confidence]
    
  error_occurred:
    campos: [agent_id, error_type, error_message, stack_trace]
    
  data_fetched:
    campos: [source, query, result_count, cache_hit]
    
  document_generated:
    campos: [document_type, agents_used, quality_score]
```

**FASE 2: Armazenamento**
```yaml
storage:
  local:
    path: ".juridico-brasil/audit/"
    format: "jsonl (JSON Lines)"
    rotation: "daily"
    retention: 90
    
  fields_required:
    - timestamp_iso8601
    - correlation_id
    - agent_id
    - action
    - input_hash
    - output_hash
    - duration_ms
    - status
```

**FASE 3: Rastreabilidade**
```yaml
traceability:
  correlation_id: "UUID para cada requisição"
  parent_span: "ID da operação pai"
  span_id: "ID da operação atual"
  
  linkage:
    - request → orchestrator
    - orchestrator → intent_parser
    - intent_parser → query_builder
    - query_builder → tribunal_router
    - tribunal_router → scrapers
    - scrapers → aggregation
    - aggregation → generators
    - generators → validators
    - validators → formatter
```

**FASE 4: Geração de Relatório**
```yaml
reports:
  execucao:
    titulo: "Relatório de Execução"
    campos:
      - data_inicio
      - data_fim
      - duracao_total
      - agentes_executados
      - fontes_consultadas
      - documentos_gerados
      - score_qualidade_medio
      
  metricas:
    - tempo_medio_por_agente
    - taxa_sucesso
    - erros_mais_comuns
    - fontes_mais_utilizadas
    
  compliance:
    - validacoes_aprovadas
    - violacoes_encontradas
    - pendencias
```

### Output
```yaml
tipo: AuditLogEntry
formato: jsonl
armazenamento: arquivo_local
estrutura_cada_entrada:
  timestamp: "ISO8601"
  version: "1.0"
  correlation_id: "UUID"
  span_id: "UUID"
  parent_span: "UUID|null"
  agent_id: "string"
  action: "string"
  input_hash: "SHA256"
  output_hash: "SHA256"
  duration_ms: number
  status: enum
  metadata: object
  quality_scores: object|null
  errors: array|null
```

---

## Handoff Protocol

### Recebe de
```yaml
agente: todos
valida_input:
  - evento_valido
  - timestamp_correto
```

### Envia para
```yaml
agente: null (terminal)
acao: Armazenar em arquivo
```

---

## Estrutura de Diretórios de Log

```
.juridico-brasil/
└── audit/
    ├── 2024/
    │   ├── 03/
    │   │   ├── 20.jsonl
    │   │   └── 21.jsonl
    │   └── reports/
    │       └── 2024-03.json
    └── logs/
        └── sistema.log
```

---

## Métricas
```yaml
latência_target: 50ms
precisão_target: 100%
KPIs:
  entries_logged: 100%
  traceability_complete: 99%
  report_generation: automatic
  storage_used: monitorado
```

---

*AGENTE 12 - AUDIT LOGGER v1.0*
