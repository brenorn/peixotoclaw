# TEMPLATE: AÇÃO CIVIL PÚBLICA

## Estrutura Completa

```
EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) DE DIREITO DA {VARA}ª VARA DA COMARCA DE {COMARCA}/{ESTADO}

{ministerio_publico | defensoria_publica | ente_publico}, por seu(sua) representante legal, com escritório em {ENDEREÇO}, vem, respeitosamente, à presença de Vossa Excelência, com fundamento no art. 129, III, da Constituição Federal, e na Lei nº 7.347/85, propor a presente

## AÇÃO CIVIL PÚBLICA

em face de {RÉU}, [NATUREZA JURÍDICA], sito à {ENDEREÇO}, pelos fatos e fundamentos a seguir:

---

### I – DA LEGITIMIDADE ATIVA

O {MINISTÉRIO PÚBLICO / DEFENSORIA PÚBLICA} possui legitimidade ativa para esta ação, conforme art. 129, III, CF e art. 5º, Lei 7.347/85.

---

### II – DOS FATOS

{Narrativa dos fatos lesivos ao patrimônio público, moradia, ambiente, consumidor ou outros interesses difusos/coletivos}

---

### III – DO DIREITO

#### III.1 – Da Violação aos Princípios Constitucionais
{Fundamentação}

#### III.2 – Da Lei 7.347/85 Aplicável
{Fundamentação}

---

### IV – DOS PEDIDOS

Ante o exposto, requer:

a) A concessão de Tutela Provisória para {PEDIDO URGENTE};

b) A procedência dos pedidos para {PEDIDOS};

c) A condenação do requerido ao pagamento de {DANOS MORAIS COLETIVOS | INDENIZAÇÃO};

d) {OUTROS PEDIDOS};

---

### V – DOS REQUERIMENTOS FINAIS

Protesta provar o alegado por todos os meios de prova em direito admitidos.

Dá-se à causa o valor de R$ {VALOR}.

Termos em que,
Pede deferimento.

{local}, {data}

_______________________________
{PROMOTOR DE JUSTIÇA | DEFENSOR PÚBLICO}
{ÓRGÃO} - {NÚMERO}
```
