# GUIA DE SCRAPERS JURÍDICOS BRASILEIROS

## Índice
1. LexML Brasil
2. STF Portal
3. STJ Jurisprudência
4. CNJ Dados Abertos
5. Diários Oficiais

---

## 1. LexML Brasil

### Sobre
Sistema de informação para legislação brasileira. Integra legislação federal, estadual e municipal.

### API Endpoint
```
Base URL: https://www.lexml.gov.br
Documentação: https://www.lexml.gov.br/sobre/api
```

### Queries Common

```bash
# Buscar lei
curl "https://www.lexml.gov.br/busca.json?termo=direitos+autorais"

# Buscar jurisprudência
curl "https://www.lexml.gov.br/busca.json?termo=responsabilidade+civil&tipo=jurisprudencia"

# Buscar por tipo
curl "https://www.lexml.gov.br/busca.json?termo=imposto&tipo=lei&ano=2020"
```

### Rate Limiting
- **Limite:** 10 requisições por minuto
- **Recomendação:** Implementar cache de 5 minutos

---

## 2. STF Portal

### Portal
```
URL Base: https://portal.stf.jus.br
Jurisprudência: https://portal.stf.jus.br/jurisprudencia/
Repercussão Geral: https://portal.stf.jus.br/jurisprudencia/repercussao/
```

### Endpoints

```python
# Pesquisa de Jurisprudência
POST /jurisprudencia/pesquisaLegado
Body: {
    "Pesquisa": "dano moral",
    "Origem": "J",
    "FlagColecao": false
}

# Repercussão Geral
GET /jurisprudencia/repercussao/rest/pesquisa/listar?
    pagina={n}&tamanho={n}&palavra={termo}
```

### Parsing de Decisões

```python
# Estrutura esperada de parsing
{
    "numero": "RE 1.000.000",
    "relator": "Min. LUIZ FUX",
    "data": "10/03/2024",
    "ementa": "...",
    "tema": "Tema 1.234",
    "procedural": "..."
}
```

---

## 3. STJ Jurisprudência

### Portal
```
URL Base: https://www.stj.jus.br
Jurisprudência: https://www.stj.jus.br/jurisprudencia/
Pesquisa: https://www.stj.jus.br/jurisprudencia/pesquisa/
```

### Endpoints

```python
# Pesquisa por palavras
GET /jurisprudencia/pesquisa.html?
    texto={palavras}&
    classe={classe}&
    data={data_inicio}+a+{data_fim}

# Pesquisa REST
GET /jurisprudencia/rest/pesquisa?
    palavras={termo}&
    pagina={n}&
    tamanho={n}
```

### Classes Mais Comuns
- REsp (Recurso Especial)
- AgInt (Agravo Interno)
- HC (Habeas Corpus)
- RMS (Recurso em Mandado de Segurança)

---

## 4. CNJ Dados Abertos

### Portal
```
URL Base: https://www.cnj.jus.br
Dados Abertos: https://www.cnj.jus.br/dados-abertos/
API: https://www.cnj.jus.br/api
```

### Conjuntos de Dados

```bash
# Justica estatistica
curl "https://www.cnj.jus.br/bd?filename=justica_estatistica"

# CNJ-E
curl "https://www.cnj.jus.br/bd?filename=cj"

# PJe
curl "https://www.cnj.jus.br/bd?filename=pje"
```

---

## 5. Diários Oficiais

### Diário Oficial da União
```
URL: https://www.in.gov.br/
API: https://www.in.gov.br/web/guest/dou-/busca
```

```python
# Buscar publicação
GET /dou-/busca?busca={termo}&dateFrom={data}&dateTo={data}
```

### Diários Estaduais

| Estado | Portal |
|--------|--------|
| SP | https://www.imprensaoficial.com.br |
| RJ | https://www.ioff.rj.gov.br |
| MG | https://www.mg.gov.br/executivo/dou |
| RS | https://www.diariooficial.rs.gov.br |

---

## Considerações Técnicas

### Rate Limiting
Sempre implemente delays entre requisições:
- LexML: 6 segundos
- STF: 10 segundos
- STJ: 5 segundos

### Headers Recomendados
```python
headers = {
    "User-Agent": "MASWOS-Juridico/1.0",
    "Accept": "application/json, text/html",
    "Accept-Language": "pt-BR"
}
```

### Caching
- Resultados: 1 hora para legislação
- Jurisprudência: 30 minutos
- Decisões recentes: Sem cache

### Error Handling
```python
retry_codes = [408, 429, 500, 502, 503, 504]
max_retries = 3
backoff = exponential(1s, 2s, 4s)
```
