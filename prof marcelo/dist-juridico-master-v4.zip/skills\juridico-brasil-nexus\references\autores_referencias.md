# REFERENCES: AUTORES E DOUTRINA
## Índice de Autoridades Bibliográficas

---

## DIREITO CONSTITUCIONAL

### PhD Summa (★★★)

| Autor | Área | Obras Principais |
|-------|------|------------------|
| **Luis Roberto Barroso** | Constitucional | "Curso de Direito Constitucional", "A Nova Interpretação Constitucional" |
| **Ingo Wolfgang Sarlet** | Constitucional | "Constituição e Proporcionalidade", "Direitos Fundamentais" |
| **Gilmar Ferreira Mendes** | Constitucional | "Curso de Direito Constitucional", "ADIs e ADOens" |

### PhD (★★)

| Autor | Área | Obras |
|-------|------|-------|
| José Afonso da Silva | Constitucional | "Curso de Direito Constitucional Positivo" |
| Pedro Lenza | Constitucional | "Direito Constitucional Esquematizado" |
| Alexandre de Moraes | Constitucional | "Direito Constitucional" |

---

## DIREITO ADMINISTRATIVO

### PhD (★★)

| Autor | Área | Obras |
|-------|------|-------|
| Maria Sylvia Zanella Di Pietro | Admin. | "Direito Administrativo", "Parcerias na Admin. Pública" |
| José dos Santos Carvalho Filho | Admin. | "Manual de Direito Administrativo" |
| Odete Medauar | Admin. | "Direito Administrativo Moderno" |

---

## DIREITO CIVIL

### PhD (★)

| Autor | Área | Obras |
|-------|------|-------|
| Caio Mário da Silva Pereira | Civil | "Instituições de Direito Civil" |
| Carlos Roberto Gonçalves | Civil | "Direito Civil Brasileiro" |
| Maria Helena Diniz | Civil | "Curso de Direito Civil Brasileiro" |
| Silvio de Salvo Venosa | Civil | "Direito Civil" |

---

## DIREITO DA EDUCAÇÃO

### Doutrina Especializada

| Autor | Área | Obras |
|-------|------|-------|
| Maria Sylvia Zanella Di Pietro | Admin. Educacional | "Parcerias na Admin. Pública" |
| Dalmar de Pinho | Educacional | "Gestão Educacional" |
| Carlos Roberto Juca | Educacional | "Sistema Municipal de Ensino" |

---

## DIREITO PROCESSUAL

### PhD (★)

| Autor | Área | Obras |
|-------|------|-------|
| Pedro.lenha Dinamarco | Processual | "Instituições de Direito Processual" |
| Luiz Guilherme Marinoni | Processual | "Tutela Jurisdicional" |
| Teresa Walmir Santos | Processual | "Manual de Direito Processual" |

---

## CRITÉRIOS DE QUALIDADE DOUTRINÁRIA

### Hierarquia de Fontes

```yaml
qualidade:
  maxima:
    - "Autores PhD reconhecidos nacionalmente"
    - "Obras em revistas Qualis A1"
    - "Publicações em editoras acadêmicas"
    
  alta:
    - "Autores Mestre/Especialistas"
    - "Publicações em revistas Qualis B1/B2"
    - "Capítulos em livros coletivos"
    
  media:
    - "Artigos em periódicos não Qualis"
    - "Publicações institucionais"
```

---

**ATUALIZAÇÃO:** 21/03/2026
**VALIDAÇÃO:** JURÍDICO BRASIL NEXUS v3.0
