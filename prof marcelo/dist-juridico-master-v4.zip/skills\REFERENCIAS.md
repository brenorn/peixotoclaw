# 📚 REFERÊNCIAS TEÓRICAS

## JURÍDICO BRASIL v3.0

### Documentação de Fundamentação Acadêmica

---

## 1. ARQUITETURA DO SISTEMA

### 1.1 Arquitetura Transformer

O sistema implementa uma arquitetura **Transformer** adaptada para processamento jurídico:

```
┌─────────────────────────────────────────────┐
│              INPUT ENCODER STACK              │
│  Intent → Query Builder → Tribunal Router   │
└─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────┐
│              CROSS-ATTENTION LAYER            │
│  LexML ←→ STF/STJ ←→ Diário ←→ JusBrasil   │
└─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────┐
│              DECODER STACK                    │
│  Petition → Fault → Counter → Citation      │
└─────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────┐
│              OUTPUT LAYER                     │
│  Document → OAB Validator → PhD Review      │
└─────────────────────────────────────────────┘
```

### 1.2 Camadas de Agentes

| Camada | Função | Agentes |
|--------|--------|---------|
| **Coordenação** | Supervisão máxima | 00, 13, 25 |
| **Entrada** | Processamento input | 01, 02, 03, 23 |
| **Dados** | Busca fontes | 04, 05, 34 |
| **Especialistas** | Domínio jurídico | 14-22 |
| **Produção** | Geração conteúdo | 06, 07, 08, 10 |
| **Validação** | Controle qualidade | 09, 24, 26-33 |
| **Saída** | Formatação final | 11, 12 |

---

## 2. QUALIFICAÇÕES E PADRÕES

### 2.1 Padrão OAB

O sistema segue rigorosamente os padrões da OAB para petições:
- Estrutura formal (CPC Art. 319)
- Linguagem jurídica adequada
- Fundamentação legal completa
- Citações em formato ABNT

### 2.2 Padrão STF

Critérios de admissibilidade aplicados:
- Repercussão Geral verificada
- Súmulas Vinculantes identificadas
- Precedentes vinculantes mapeados

### 2.3 Padrão QUALIS A1

Referências bibliográficas classificadas:
- Periódicos Qualis A1 verificados
- ISSN confirmado
- Autoridade dos autores validada

---

## 3. DIMENSÕES DE AVALIAÇÃO PhD

### 3.1 As 7 Dimensões

| # | Dimensão | Peso | Descrição |
|---|----------|------|-----------|
| 1 | Fundamentação Teórica | 20% | Coerência, profundidade, Qualis |
| 2 | Conformidade Constitucional | 25% | CF, SV, ADC |
| 3 | Qualidade Argumentativa | 20% | Clareza, lógica, originalidade |
| 4 | Precedentes | 15% | Atualização, pertinência |
| 5 | Estratégia Processual | 10% | Timing, adequação |
| 6 | Linguagem | 5% | Norma culta, terminologia |
| 7 | Completude | 5% | Seções obrigatórias |

### 3.2 Cálculo de Score

```
Score Final = Σ(Dimensão × Peso)
```

Exemplo:
```
Score = (Teórica × 0.20) + (Constitucional × 0.25) + ... + (Completude × 0.05)
```

---

## 4. SISTEMA DE RATINGS

### 4.1 Lexit Maximus (97-100)

Concedido quando:
- Todas as 7 dimensões ≥ 95
- Nenhuma falha crítica
- Citações todas verificadas
- Jurisprudência atual

### 4.2 Aprovado (90-96)

Concedido quando:
- Maioria das dimensões ≥ 90
- Falhas menores identificáveis
- Revisão mínima necessária

### 4.3 Aprovado c/Ressalvas (80-89)

Concedido quando:
- Dimensões principais ≥ 80
- Ajustes específicos identificados
- Revisão moderada necessária

### 4.4 Rejeitado (<80)

Quando:
- Qualquer dimensão < 65
- Falhas críticas identificadas
- Reformulação necessária

---

## 5. AGENTES ESPECIALIZADOS

### 5.1 Tribunal Supremo de Agentes

**Agente 25 - Jurista Supremo PhD**
- Supervisor máximo do sistema
- Poder de veto a qualquer documento
- Avaliação em 7 dimensões
- Concessão de Lexit Maximus

**Agente 13 - Gerente Supremo Federal**
- Coordenação operacional
- Validação intermediária
- Supervisão de especialistas

### 5.2 Especialistas por Área

| ID | Especialidade | PhD | Área |
|----|---------------|-----|------|
| 14 | Civil | ★ | Obrigações, Contratos |
| 15 | Constitucional | ★★★ | ADI, ADC, RG |
| 16 | Penal | ★★★ | CP, CPP |
| 17 | Trabalhista | ★ | CLT, TST |
| 18 | Tributário | ★ | CTN, Impostos |
| 19 | Consumidor | - | CDC |
| 20 | Administrativo | - | Licitações |
| 21 | Empresarial | - | Falência |
| 22 | Internacional | ★ | Tratados |

### 5.3 Agentes Cirúrgicos

| ID | Função | Descrição |
|----|--------|-----------|
| 26 | Analista Precedentes | Ratio decidendi |
| 27 | Cirurgião Recursos | Técnica recursal |
| 28 | Auditor Citações | Verificação ABNT |
| 29 | Perito Linguagem | Norma culta |
| 30 | Estrategista | Planejamento |
| 31 | Analista Vulnerabilidades | Riscos |
| 32 | Revisor Tese | Consistência |
| 33 | Gestor Trâmites | Prazos |

---

## 6. FONTES DE DADOS

### 6.1 APIs Oficiais

| Fonte | URL | Tipo |
|-------|-----|------|
| LexML | lexml.gov.br | API REST |
| STF | portal.stf.jus.br | Scraping |
| STJ | stj.jus.br | Scraping |
| CNJ | cnj.jus.br | API + CSV |
| DOU | in.gov.br | API REST |

### 6.2 Rate Limiting

| Fonte | Limite | Implementação |
|-------|--------|---------------|
| LexML | 10/min | Cache 5min |
| STF | 6/min | Backoff |
| STJ | 6/min | Backoff |

---

## 7. VALIDAÇÃO DE CITAÇÕES

### 7.1 Formato ABNT

**Legislação:**
```
Art. XX, Lei nº X.XXX/XXXX
```

**Jurisprudência STF:**
```
STF, RE xxx, Rel. Min. Nome, Órgão, j. DD/MM/AAAA, DJe DD/MM/AAAA
```

**Jurisprudência STJ:**
```
STJ, REsp xxx, Rel. Min. Nome, Órgão, j. DD/MM/AAAA, DJe DD/MM/AAAA
```

### 7.2 Verificações

- [ ] Norma vigente
- [ ] Edição correta
- [ ] ISSN válido
- [ ] Precedente atualizado
- [ ] Aplicabilidade confirmada

---

## 8. LIMITAÇÕES CIENTÍFICAS

### 8.1 Limitações Conhecidas

| Limitação | Descrição | Impacto |
|-----------|-----------|---------|
| **Latência** | Atualização pode ter delay | Jurisprudência não real-time |
| **Vies de seleção** | Escolha de precedentes é parcial | Revisão humana necessária |
| **Alucinação** | Modelos podem gerar dados incorretos | Verificação obrigatória |
| **Contexto limitado** | Não processa imagens/anexos | Análise limitada |

### 8.2 Mitigações Implementadas

1. **Cache inteligente** com TTL configurável
2. **Validação múltipla** por agentes
3. **Revisão humana** sempre recomendada
4. **Avisos claros** de limitações

### 8.3 Protocolo de Uso Seguro

```
1. Gerar rascunho ← Sistema
2. Revisar conteúdo ← Humano
3. Verificar citações ← Humano + Sistema
4. Validar estratégia ← Humano
5. Protocolar ← Humano
```

---

## 9. REFERÊNCIAS BIBLIOGRÁFICAS

### 9.1 Direito Constitucional
- BARROSO, L. R. Curso de Direito Constitucional Contemporâneo. 9.ed. Saraiva, 2020.
- MENDES, G. F.; BRANCO, P. G. Curso de Direito Constitucional. 15.ed. Saraiva, 2020.

### 9.2 Direito Processual Civil
- DINAMARCO, C. R. Instituições de Direito Processual Civil. 9.ed. Malheiros, 2017.
- MARINONI, L. G. Curso de Processo Civil. 5.ed. Thomson Reuters, 2020.

### 9.3 Direito Civil
- PEREIRA, C. M. Instituições de Direito Civil. 23.ed. Forense, 2020.
- GAGLIANO, P. S. Novo Curso de Direito Civil. 8.ed. Saraiva, 2018.

### 9.4 Direito Penal
- BITENCOURT, C. R. Tratado de Direito Penal. 22.ed. Saraiva, 2020.
- GRECO, R. Código Penal Comentado. 10.ed. Thomson Reuters, 2019.

---

## 10. VERSÕES E CHANGELOG

### v3.0.0 (2024)
- 34+ agentes
- Jurista Supremo PhD
- 8 agentes granulares cirúrgicos
- 100+ referências reais

### v2.0.0 (2024)
- 24 agentes
- Gerente Supremo Federal
- 9 especialistas por área

### v1.0.0 (2023)
- 13 agentes básicos
- Lançamento inicial

---

## 11. CITAÇÃO DO SISTEMA

```bibtex
@software{JURIDICO_BRASIL,
  title = {JURÍDICO BRASIL v3.0},
  subtitle = {Sistema de Advocacia Universal PhD Summa},
  author = {MASWOS V5 NEXUS},
  year = {2024},
  url = {https://github.com/maswos/juridico-brasil},
  note = {Ferramenta de apoio jurídico com 34+ agentes especializados}
}
```

---

## 12. CONTATO

- **Email:** suporte@maswos.com.br
- **Issues:** GitHub Issues
- **Licença:** MIT

---

*Documento de fundamentação teórica - JURÍDICO BRASIL v3.0*
