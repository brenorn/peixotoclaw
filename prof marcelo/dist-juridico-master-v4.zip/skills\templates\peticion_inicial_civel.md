# TEMPLATE: PETIÇÃO INICIAL CÍVEL

## Estrutura Completa (CPC Art. 319)

```
EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) DE DIREITO DA {VARA}ª VARA {ESPECIALIDADE} DA COMARCA DE {COMARCA}/{ESTADO}

{CLASSE PROCESSUAL} (art. {FUNDAMENTO CPC}), por seu(sua) advogado(a) e procurador(a) ao final identificado(a), ampla e subscrito(a), com escritório profissional sito à {ENDEREÇO COMPLETO}, onde recebe intimações, com escritório eletrônico {EMAIL}, em face de {RÉU}, [NATUREZA JURÍDICA - CPF/CNPJ], {ENDEREÇO}, [/proc-se], vem, respeitosamente, à presença de Vossa Excelência, com fundamento no art. {XX} do {CÓDIGO}, propor a presente

## {TÍTULO DA AÇÃO}

pelos fatos e fundamentos a seguir expostos:

---

### I – DOS FATOS

(Parágrafos narrando os fatos de forma impessoal, objetiva e cronológica)

---

### II – DO DIREITO

#### II.1 - {SUBTÍTULO JURÍDICO}
{Fundamentação legal e jurisprudencial}

---

### III – DOS REQUERIMENTOS / DOS PEDIDOS

Ante o exposto, requer:

a) {Pedido 1};

b) {Pedido 2};

c) {Pedido 3};

---

### IV – DO VALOR DA CAUSA

Atribui-se à causa o valor de R$ {VALOR} ({extenso}).

---

### V – DAS PROVAS

Protesta provar o alegado por todos os meios de prova em direito admitidos, especialmente pela {INDICAÇÃO}, {AUDIÇÃO}, {ACOLHIMENTO} e {PROVA}.

---

### VI – DAS DISPOSIÇÕES FINAIS

Dá-se à causa o valor de R$ {VALOR}.

Termos em que,
Pede deferimento.

{local}, {data}

_______________________________
{NOME DO ADVOGADO}
{OAB/ESTADO} {NÚMERO OAB}
```
