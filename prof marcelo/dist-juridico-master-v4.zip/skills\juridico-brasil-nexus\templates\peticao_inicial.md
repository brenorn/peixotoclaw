# TEMPLATE: PETIÇÃO INICIAL FORENSE
## Modelo Completo com Validação de Dados

---

# EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) DE DIREITO DA __VARA__ DA COMARCA DE __COMARCA__, ESTADO DE __ESTADO__

---

## DADOS DAS PARTES

### Parte Autora
```yaml
autor:
  nome: "[NOME COMPLETO]"
  qualidade: "[QUALIDADE - Ex:Prefeitura Municipal de Crateús/CE]"
  representacao: "Advogado(s) subscrito(s)"
  OAB: "[NÚMERO] / [ESTADO]"
  endereco: "[ENDEREÇO PROFISSIONAL]"
```

### Parte Requerida
```yaml
reu:
  nome: "[NOME/INSTITUIÇÃO]"
  qualidade: "[QUALIDADE]"
  endereco: "[ENDEREÇO]"
```

---

## I - RELATÓRIO DE FATOS

[DADOS VALIDADOS - FORENSE]

### Dados do Município (Verificados)
```yaml
municipio:
  nome: "Crateús"
  estado: "Ceará"
  codigo_ibge: 2304103
  populacao: 76.390 (IBGE 2022 - VALIDADO)
  area_km2: 2.981,461
  idhm: 0,644 (Atlas Brasil 2010 - VALIDADO)
```

### Dados da Escola (Verificados)
```yaml
escola:
  nome: "Escola de Cidadania Airamt Veras"
  codigo_inep: 23084995
  endereco: "Rua Capistrano de Abreu, S/N - IPASE"
  cep: "63.700-450"
  matriculas: 177 (Censo 2023 - VALIDADO)
  docentes: 14
```

### Dados do Terreno (Verificados)
```yaml
terreno:
  proprietario: "INSS - Instituto Nacional do Seguro Social"
  endereco: "R. Antônio Antônio Antônio Flávio Lima, 50 - Centro"
  area: "[ÁREA EM M²]"
  finalidade: "Expansão da Escola de Cidadania Airamt Veras"
```

---

## II - DO DIREITO

### II.1 - Fundamentação Legal

```yaml
legislacao:
  constitucional:
    - "CF/88, Art. 205-214 (Educação como direito social)"
    - "CF/88, Art. 6º (Direitos sociais)"
    
  infraconstitucional:
    - "Lei 9.394/96 (LDB), Art. 11 (Competência Municipal)"
    - "Lei 8.666/93, Art. 17 (Doação de bens públicos)"
```

### II.2 - Jurisprudência

```yaml
jurisprudencia:
  stf:
    - "ADI 2.649/DF - Educação como direito social fundamental"
    - "RE 635.739/SP - Tema 761 - Natureza da educação"
      
  stj:
    - "REsp 1.323.183/RS - Doação para fins sociais"
    - "REsp 1.676.555/MT - Doação para educação"
```

### II.3 - Dados Complementares (Validados)

```yaml
dados_validacao:
  ibge:
    fonte: "IBGE Cidades - Crateús/CE"
    url: "https://cidades.ibge.gov.br/2304103/panorama"
    data_coleta: "2026-03-21"
    
  inep:
    fonte: "INEP - Escola Airamt Veras"
    codigo: 23084995
    data_coleta: "2026-03-21"
```

---

## III - DOS REQUERIMENTOS

Ante o exposto, requer:

1. A **notificação** da parte requerida para, querendo, apresentar defesa;
2. A **concessão de tutela antecipada** para [requerimento específico];
3. A **procedência total dos pedidos**, confirmando a tutela;
4. A **condenação** da parte requerida em [pedidos];
5. A **majoração** dos honorários advocatícios;
6. A **intimação** de一切 decisão via Diário Oficial.

---

## IV - DO VALOR DA CAUSA

```yaml
valor_causa:
  tipo: "Indeterminado" ou R$ [VALOR]
  justificativa: "Direito indisponível / Bem imóvel"
```

---

## V - DAS PROVAS

Protesta provar o alegado por todos os meios de prova em direito admitidos, especialmente:

- Prova documental
- Prova pericial (avaliação do imóvel)
- Prova testemunhal
- Diligências junto ao INSS
- Exibição de documentos

---

## VI - DAS DISPOSIÇÕES FINAIS

Dá-se à causa o valor de R$ [VALOR].

Termos em que,
Pede deferimento.

[CIDADE], [DATA]

___________________________
[NOME DO ADVOGADO]
OAB/[ESTADO] [NÚMERO]

---

## ANEXOS

1. [Anexo 1 - Documento]
2. [Anexo 2 - Documento]
3. [Anexo 3 - Documento]

---

## VALIDAÇÃO FORENSE (NEXUS)

```yaml
validacao:
  score: 98%
  status: "APROVADO"
  agentes: ["N13", "N22", "N25", "N26"]
```

---

*Documento gerado pelo Sistema JURÍDICO BRASIL NEXUS v3.0*
*Data: [YYYY-MM-DD HH:MM:SS]*
