#!/bin/bash
# =============================================================
#    JURÍDICO BRASIL MASTER v4.0 - INSTALAÇÃO (Linux/Mac)
# =============================================================

set -e

echo "============================================================="
echo "   JURÍDICO BRASIL MASTER v4.0 - INSTALAÇÃO RÁPIDA"
echo "============================================================="
echo ""

# Verificar arquivo
if [ ! -f "dist-juridico-master-v4.zip" ]; then
    echo "ERRO: Arquivo dist-juridico-master-v4.zip não encontrado!"
    echo "Execute este script na mesma pasta do arquivo ZIP."
    exit 1
fi

# Criar diretório de destino
DESTINO="$HOME/.opencode/skills"
mkdir -p "$DESTINO"

# Extrair ZIP
echo ""
echo "Extraindo arquivos..."
unzip -o "dist-juridico-master-v4.zip" -d "temp_install"

# Copiar skills
echo ""
echo "Instalando skills..."
cp -r "temp_install/skills/juridico-brasil-master" "$DESTINO/"
cp -r "temp_install/skills/juridico-brasil" "$DESTINO/"
cp -r "temp_install/skills/juridico-brasil-nexus" "$DESTINO/"
cp -r "temp_install/skills/juridico-brasil-forense" "$DESTINO/"

# Limpar
echo ""
echo "Limpando arquivos temporários..."
rm -rf "temp_install"

# Verificar instalação
echo ""
echo "============================================================="
echo "   VERIFICAÇÃO"
echo "============================================================="
if [ -f "$DESTINO/juridico-brasil-master/SKILL.md" ]; then
    echo "[OK] juridico-brasil-master"
fi
if [ -f "$DESTINO/juridico-brasil/SKILL.md" ]; then
    echo "[OK] juridico-brasil"
fi
if [ -f "$DESTINO/juridico-brasil-nexus/SKILL.md" ]; then
    echo "[OK] juridico-brasil-nexus"
fi
if [ -f "$DESTINO/juridico-brasil-forense/SKILL.md" ]; then
    echo "[OK] juridico-brasil-forense"
fi

echo ""
echo "============================================================="
echo "   INSTALAÇÃO CONCLUÍDA!"
echo "============================================================="
echo ""
echo "Para usar, no OpenCode digite:"
echo "  /skill juridico-brasil-master"
echo ""
