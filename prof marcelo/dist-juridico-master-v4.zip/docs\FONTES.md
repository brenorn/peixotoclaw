# 🌐 FONTES OFICIAIS
## JURÍDICO BRASIL MASTER v4.0

---

## FONTES GOVERNAMENTAIS FEDERAIS

| Fonte | URL | Dados |
|-------|-----|-------|
| **IBGE** | ibge.gov.br | Demografia, economia, território |
| **INEP** | inep.gov.br | Educação, escolas, IDEB |
| **CNJ** | cnj.jus.br | Justiça, processos, estatísticas |
| **STF** | portal.stf.jus.br | Supremo Tribunal Federal |
| **STJ** | stj.jus.br | Superior Tribunal de Justiça |
| **TST** | tst.jus.br | Tribunal Superior do Trabalho |
| **LexML** | lexml.gov.br | Legislação federal/estadual |
| **Diário Oficial** | in.gov.br | Publicações oficiais |

---

## FONTES ESTADUAIS (CEARÁ)

| Fonte | URL | Dados |
|-------|-----|-------|
| **IPECE** | ipece.ce.gov.br | Indicadores econômicos CE |
| **TJ-CE** | tjce.jus.br | Tribunal de Justiça CE |
| **SEDUC** | educacao.ce.gov.br | Secretaria Educação |
| **TCM-CE** | tcm.ce.gov.br | Tribunal Contas Município |
| **SEFAZ** | sefaz.ce.gov.br | Secretaria Fazenda |

---

## FONTES MUNICIPAIS (CRATEÚS)

| Fonte | URL | Dados |
|-------|-----|-------|
| **Prefeitura** | crateus.ce.gov.br | Dados municipais |
| **Transparência** | crateus.ce.gov.br/transparencia | Licitações, contratos |
| **Educação** | crateus.ce.gov.br/educacao | Escolas municipais |

---

## BASES DE DADOS

### Jurídicas
| Base | URL | Dados |
|------|-----|-------|
| JusBrasil | jusbrasil.com.br | Jurisprudência agregada |
| LexML | lexml.gov.br | Legislação indexada |
| DataJus | datajusp3g93d1br | Dados processuais |
| JusNavigator | jusnav.com.br | Consulta processual |

### Acadêmicas
| Base | URL | Dados |
|------|-----|-------|
| SciELO | scielo.br | Artigos científicos BR |
| CAPES | capes.gov.br | Teses e dissertações |
| Google Scholar | scholar.google.com | Literatura geral |
| BDTD | bdtd.ibict.br | Teses brasileiras |

---

## APIs SUPORTADAS

### IBGE
```yaml
api_ibge:
  base: "https://servicodados.ibge.gov.br/api"
  endpoints:
    municipios: "/v1/localidades/municipios"
    ibge_code: "/v1/codigosp/municipios/{id}"
```

### INEP
```yaml
api_inep:
  base: "https://api.inep.gov.br"
  endpoints:
    escolas: "/escolas"
    ideb: "/ideb"
```

### LexML
```yaml
api_lexml:
  base: "https://www.lexml.gov.br"
  busca: "/busca/resultado"
```

---

## SCRAPERS CONFIGURADOS

### Configuração Padrão

```yaml
scraper_config:
  user_agent: "MASWOS-NEXUS-Bot/1.0"
  timeout: 30
  retries: 3
  delay: 2
  
rate_limits:
  gov_br: "10 req/min"
  stf_stj: "10 req/min"
  ibge: "60 req/min"
```

---

**FONTES v4.0 - 21/03/2026**
