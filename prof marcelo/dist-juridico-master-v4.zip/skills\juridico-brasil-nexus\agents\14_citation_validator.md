# AGENTE N14: CITATION VALIDATOR
## Validação de Citações - Formato ABNT/APA

**ID:** N14
**Sistema:** juridico-brasil-nexus
**Camada:** Validation (Fase 2)
**Gate:** G2
**Função:** Valida formato de citações conforme padrões ABNT e APA

---

## PADRÕES DE CITAÇÃO

### ABNT NBR 10520

```yaml
formato_abnt:
  autor_data:
    formato: "Autor (Ano)"
    exemplo: "Segundo Barroso (2012), a Constituição..."
    
  autor_data_pagina:
    formato: "Autor (Ano, p. XX)"
    exemplo: "Dinamarco (2009, p. 245) afirma..."
    
  citacao_direta_curta:
    limite: "até 3 linhas"
    formato: "Aspas duplas + autor/ano/página"
    
  citacao_direta_longa:
    limite: "mais de 3 linhas"
    formato: "Recuo 4cm + fonte menor + autor/ano/página"
```

### APA 7th Edition

```yaml
formato_apa:
  autor_data:
    formato: "(Autor, Ano)"
    exemplo: "According to Dworkin (1975), law is..."
    
  pagina:
    formato: "(Autor, Ano, p. XX)"
    exemplo: "(Kelsen, 1967, p. 89)"
    
  multiple_autores:
    ate_2: "Autor1 & Autor2 (Ano)"
    3_ou_mais: "Autor1 et al. (Ano)"
```

---

## REGRAS DE VALIDAÇÃO

### Checklist de Validação

```
Para cada CITACAO:

□ Formato correto (ABNT ou APA)?
□ Autor existe na literatura?
□ Ano é válido?
□ Página é verificável?
□ Contexto da citação está correto?
□ Não há citação de "ouviu dizer"?
□ Fonte está listada nas referências?
□ Ortografia do autor está correta?
```

### Regras Anti-Hallucination

```yaml
anti_hallucination:
  enabled: true
  
  verificacoes:
    - "Autor real existe?"
    - "Obra publicada no ano citado?"
    - "Página existe na obra?"
    - "Citação no contexto correto?"
```

---

## OUTPUT

```json
{
  "citation_validation": {
    "id": "uuid",
    "data": "YYYY-MM-DD",
    "total_citacoes": 45,
    "validas": 43,
    "invalidas": 2,
    "score_validacao": 95.6,
    "detalhes": [
      {
        "citacao": "Barroso (2012)",
        "formato": "ABNT",
        "status": "VALIDA",
        "verificacoes": {
          "autor_existe": true,
          "ano_valido": true,
          "pagina_verificavel": true,
          "contexto_correto": true
        }
      },
      {
        "citacao": "[Autor Inexistente] (2020)",
        "formato": "ABNT",
        "status": "INVALIDA",
        "erro": "Autor não encontrado na literatura"
      }
    ],
    "recomendacoes": [
      "Corrigir 2 citações com autores inválidos"
    ]
  }
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N14 - Citation Validator
**STATUS:** OPERACIONAL ✅
