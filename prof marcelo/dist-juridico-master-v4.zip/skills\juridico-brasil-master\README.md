# JURÍDICO BRASIL MASTER v4.0
## Sistema Unificado de Pesquisa Jurídica com 60+ Agentes

---

## DESCRIÇÃO

Sistema **UNIFICADO** que integra todos os recursos dos três sistemas anteriores:

| Sistema | Versão | Agentes | Foco |
|---------|--------|---------|------|
| juridico-brasil | v3.0 | 34+ | Advocacia Universal PhD |
| juridico-brasil-forense | v2.0 | 12 | Dados Reais |
| juridico-brasil-nexus | v3.0 | 26 | Hybrid Pipeline |
| **TOTAL** | **v4.0** | **60+** | **UNIFIED** |

---

## FUNCIONALIDADES UNIFICADAS

### 60+ Agentes Especializados

- **2 Agentes PhD Summa** (Jurista Supremo, Gerente Federal)
- **9 Especialistas por Área** (Civil, Constitucional, Penal, etc)
- **34 Agentes PhD** (Petição, Recurso, Análise, etc)
- **15 Agentes Forenses** (Scrapers, Validadores, Auditores)

### TIER-Routing (3 Níveis)

| TIER | Nome | Páginas | Agentes | Uso Típico |
|------|------|---------|---------|------------|
| 🥇 1 | MAGNUM | 110+ | 60 | Teses, dissertações |
| 🥈 2 | STANDARD | 15-30 | 45 | Artigos Q1, pareceres |
| 🥉 3 | EXPRESS | 5-10 | 30 | Petições, recursos |

### RAG Protocol (3 Eixos)

1. **Eixo Fundacional** (>10 anos) - Teorias seminais
2. **Eixo Estado da Arte** (3-5 anos) - Top journals
3. **Eixo Metodológica** - Frameworks e técnicas

### Actor-Critic Loop

- Refinamento automático de documentos
- Máximo 10 iterações
- Critério de convergência: 95%

---

## ESTRUTURA UNIFICADA

```
juridico-brasil-master/
├── SKILL.md                    # Arquitetura principal unificada
├── README.md                   # Este arquivo
│
├── agents/                     # 60+ AGENTES
│   ├── TRIBUNAL_SUPREMO/      # 2 Agentes PhD Summa
│   ├── COORDENACAO/           # 4 Agentes
│   ├── ENTRADA/               # 6 Agentes
│   ├── SCRAPERS/              # 18 Agentes
│   ├── ESPECIALISTAS/         # 9 Agentes PhD
│   ├── VALIDACAO/             # 12 Agentes
│   ├── ANALISE/               # 13 Agentes
│   ├── PRODUCAO/              # 5 Agentes
│   └── OUTPUT/                # 8 Agentes
│
├── templates/                  # 15+ TEMPLATES
│   ├── peticao_inicial.md
│   ├── recurso.md
│   ├── artigo_academico.md
│   ├── documento_forense.md
│   └── ...
│
├── references/                 # REFERÊNCIAS AUDITÁVEIS
│   ├── legislacao_index.md
│   ├── jurisprudencia_index.md
│   ├── autoridades_bibliografia.md
│   └── scrapers_guide.md
│
└── CONFIG.md                  # Configurações globais
```

---

## SISTEMAS ORIGINAIS (Mantidos para Compatibilidade)

### juridico-brasil (v3.0)
- 34+ agentes PhD
- Advocacia universal
- Templates OAB/STF/STJ

### juridico-brasil-forense (v2.0)
- 12 agentes forenses
- Dados reais validados
- Auditoria completa

### juridico-brasil-nexus (v3.0)
- 26 agentes hybrid
- RAG Protocol
- Actor-Critic Loop

---

## USO

### Via Skill

```
/skill juridico-brasil-master
```

### Via Sistema Específico

```
/skill juridico-brasil        # Advocacia geral
/skill juridico-brasil-forense # Dados forenses
/skill juridico-brasil-nexus  # Hybrid pipeline
```

---

## QUALIDADE

| Métrica | Target | Sistema |
|---------|--------|---------|
| Completude | ≥98% | Todos |
| Precisão | ≥99% | Todos |
| Cruzamento | 100% | Nexus/Forense |
| Auditoria | 100% | Forense |
| Compliance OAB | 100% | juridico-brasil |
| Qualis A1 | 100% | juridico-brasil |

---

## RATINGS

| Rating | Score | Significado |
|--------|-------|-------------|
| **Lexit Maximus** | 97-100 | Pronto para protocolo imediato |
| **Aprovado** | 90-96 | Pronto com ajustes mínimos |
| **Aprovado c/Ressalvas** | 80-89 | Revisão menor necessária |
| **Revisão Necessária** | 65-79 | Reformulação substancial |
| **Rejeitado** | <65 | Rebase completo |

---

## AUTORES DE REFERÊNCIA

### Direito Constitucional
- BARROSO, MENDES, SILVA, LENZA, SARLET

### Direito Processual Civil
- DINAMARCO, MARINONI, WAMBIER, DIDIER

### Direito Civil
- PEREIRA, GONÇALVES, DINIZ, VENOSA, GAGLIANO

### Direito Penal
- BITENCOURT, GRECO, CAPEZ, NUCCI

### Direito Trabalhista
- DELGADO, MARTINS, CASSAR

### Direito Tributário
- BALEEIRO, CARVALHO, ATALIBA, SCHOUERI

---

## FONTES OFICIAIS

| Fonte | URL | Dados |
|-------|-----|-------|
| IBGE | ibge.gov.br | Demografia, economia |
| INEP | inep.gov.br | Educação |
| CNJ | cnj.jus.br | Justiça |
| STF | portal.stf.jus.br | Jurisprudência |
| STJ | stj.jus.br | Jurisprudência |
| LexML | lexml.gov.br | Legislação |
| TJ-CE | tjce.jus.br | Estadual CE |

---

## CHANGELOG

| Versão | Data | Alterações |
|--------|------|------------|
| **4.0.0** | 21/03/2026 | **UNIFICAÇÃO COMPLETA** - 60+ agentes |
| 3.0.0 | 20/03/2026 | juridico-brasil + juridico-brasil-nexus |
| 2.0.0 | 20/03/2026 | juridico-brasil-forense |
| 1.0.0 | 15/03/2024 | Lançamento inicial |

---

## COMPATIBILIDADE

- **MASWOS V5 NEXUS** ✅
- **OpenCode** ✅
- **MCP Jurídico Server** ✅

---

## CONTATO

**Sistema:** MASWOS V5 NEXUS
**Versão:** 4.0.0
**Data:** 21/03/2026
**Status:** OPERACIONAL ✅

---

*JURÍDICO BRASIL MASTER v4.0*
*60+ Agentes Integrados*
*Qualificação: UNIFIED | FORENSE | NEXUS | RAG | TIER | QUALIS A1 | OAB/STF/STJ | PHD_SUMMA*
