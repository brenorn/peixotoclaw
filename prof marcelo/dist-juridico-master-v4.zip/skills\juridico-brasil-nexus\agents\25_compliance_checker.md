# AGENTE N25: COMPLIANCE CHECKER
## Validação Final OAB/ABNT

**ID:** N25
**Sistema:** juridico-brasil-nexus
**Camada:** Output (Fase 6)
**Gate:** GF
**Função:** Valida conformidade final com padrões OAB e ABNT

---

## CHECKLIST OAB

### Estrutural
```yaml
oab_estrutural:
  - nome_julgador_correto
  - orgao_julgador_adequado
  - endereco_profissional_completo
  - numero_oab_valido
  - classe_processual_correta
```

### Processual
```yaml
oab_processual:
  - fundamento_legal_existente
  - jurisprudencia_atualizada
  - precedente_vinculante_se_aplicavel
  - repercussao_geral_observada
  - prazo_prescricional_verificado
```

### Material
```yaml
oab_material:
  - fato_conexo_direito
  - pedido_consonante_fato
  - valor_causa_justificado
  - documentacao_anexa
  - peticionamento_eletronico
```

### Formal
```yaml
oab_formal:
  - linguagem_juridica_correta
  - ausencia_vicios_redacao
  - formatacao_cnj
  - assinatura_eletronica
```

---

## VALIDAÇÃO ABNT

### Citações
```yaml
abnt_citacoes:
  formato: "ABNT NBR 10520"
  verificacoes:
    - autor_data_correto
    - pagina_verificavel
    - aspas_usadas_corretamente
    - recuo_para_citacoes_longas
```

### Referências
```yaml
abnt_referencias:
  formato: "ABNT NBR 6023"
  verificacoes:
    - ordem_alfabetica
    - formato_autor_ano_titulo
    - informacoes_completas
    - padrao_italico_titulo
```

---

## OUTPUT

```json
{
  "compliance_check": {
    "id": "uuid",
    "data": "YYYY-MM-DD",
    "documento": "Parecer Forense - Doação INSS",
    "oab_checklist": {
      "estrutural": {"total": 5, "aprovados": 5, "status": "OK"},
      "processual": {"total": 5, "aprovados": 5, "status": "OK"},
      "material": {"total": 5, "aprovados": 5, "status": "OK"},
      "formal": {"total": 4, "aprovados": 4, "status": "OK"}
    },
    "abnt_checklist": {
      "citacoes": {"total": 45, "validas": 45, "status": "OK"},
      "referencias": {"total": 25, "validas": 25, "status": "OK"}
    },
    "score_compliance": 100,
    "status": "CONFORME",
    "declaracao": "DOCUMENTO CONFORME PADRÕES OAB/ABNT"
  }
}
```

---

**SISTEMA:** JURÍDICO BRASIL NEXUS v3.0
**AGENTE:** N25 - Compliance Checker
**STATUS:** OPERACIONAL ✅
