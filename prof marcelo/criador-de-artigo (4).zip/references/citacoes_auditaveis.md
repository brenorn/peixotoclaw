# 可审计引用 — 通用规则与完整格式

## 重要说明
**本文件以中文编写，供内部指令参考。**
**所有面向用户的输出内容，须以正式巴西葡萄牙语书写。**

---

## 绝对强制性通用规则

**所有引用 = 作者 + 年份 + 页码**

无一例外。"apud"来源须可追溯。年份不可缺页码。
无页码来源（网站）：使用编号段落或章节。

---

## ABNT NBR 10520:2023格式 — 正文引用

### 间接引用（转述）— 最常见
```
(SOBRENOME, Ano, p. XX)
例：(FREIRE, 1987, p. 29)
例：(VYGOTSKY, 1934/1991, p. 112)    ← 译本：原始年份/译本年份
```

### 短直接引用（不超过3行）— 正文中加引号
```
"[精确文字]" (SOBRENOME, Ano, p. XX)
例："A educação é um ato de amor" (FREIRE, 1987, p. 79).
```

### 长直接引用（超过3行）— 缩进段落
```
缩进：从左边距缩进4cm
字体：小于正文（正文12pt则用10pt）
不加引号
不加斜体
段落后标注：(SOBRENOME, Ano, p. XX)
```

### 机构作者引用
```
(BRASIL, 2023, p. 15)
(IBGE, 2022, p. 34)
(OMS, 2021, p. 8)
```

### 法律条文引用
```
(BRASIL, 1988, Art. 5º, inciso III)     ← 联邦宪法
(BRASIL, 2002, Art. 186)                ← 民法典
(BRASIL, 1940, Art. 121, §2º)          ← 刑法典
```

### 判例引用
```
(BRASIL, STF, ADI 3.330, 2012, p. 1)
(BRASIL, STJ, REsp 1.234.567/SP, 2020, p. 15)
```

### 二位作者
```
(SILVA; SANTOS, 2020, p. 45)
```

### 三位及以上作者
```
(SILVA et al., 2021, p. 22)
```

### 转引（apud）— 仅在无法获取原文时使用
```
(FREUD, 1915 apud LAPLANCHE; PONTALIS, 2001, p. 234)
强制要求：参考文献列表中只列出实际阅读的文献（本例中为Laplanche）
绝不将未直接阅读的著作列入参考文献
```

### 无页码来源（网站、电子文档）
```
使用段落编号：(SOBRENOME, Ano, par. 4)
或章节：(SOBRENOME, Ano, seção "Metodologia")
绝不省略位置信息
```

---

## ABNT NBR 6023:2018格式 — 参考文献列表

### 期刊文章
```
SOBRENOME, Nome; SOBRENOME2, Nome2. Título do artigo. Nome do Periódico, cidade,
v. X, n. X, p. XX-XX, mês abrev. Ano. DOI: 10.XXXX/XXXXXXX.

示例：
MALLOY-DINIZ, L. F. et al. Funções executivas e cognição social em pacientes com
transtorno bipolar. Revista de Psiquiatria Clínica, São Paulo, v. 36, n. 5,
p. 177-183, out. 2009. DOI: 10.1590/S0101-60832009000500001.
```

### 完整图书
```
SOBRENOME, Nome. Título da obra: subtítulo. Número de ed. Cidade: Editora, Ano.

示例：
FREIRE, Paulo. Pedagogia do oprimido. 17. ed. Rio de Janeiro: Paz e Terra, 1987.
```

### 文集章节
```
SOBRENOME, Nome. Título do capítulo. In: SOBRENOME, Nome (org.). Título do livro.
Cidade: Editora, Ano. cap. X, p. XX-XX.
```

### 学位论文
```
SOBRENOME, Nome. Título da tese/dissertação: subtítulo. Ano. X f. Tese (Doutorado
em [Área]) / Dissertação (Mestrado em [Área]) — [Nome do Programa], [Instituição],
[Cidade], Ano.
```

### 巴西立法
```
BRASIL. Lei nº XXXXX, de DD de mês de AAAA. Descrição da lei. Diário Oficial da
União: seção X, Brasília, DF, v. XXX, n. XX, p. XX, DD mês AAAA.
```

### 判例
```
BRASIL. Superior Tribunal de Justiça. [Tipo de recurso] nº XXXXX/UF. [Ementa resumida].
Relator: [Nome]. Brasília, DF, XX de mês de AAAA. Diário da Justiça Eletrônico,
Brasília, DF, XX mês AAAA. Disponível em: [URL]. Acesso em: DD mês AAAA.
```

### DSM-5-TR（心理学/精神病学）
```
AMERICAN PSYCHIATRIC ASSOCIATION. Manual diagnóstico e estatístico de transtornos
mentais: DSM-5-TR. 5. ed. texto rev. Porto Alegre: Artmed, 2023.
```

### 软件/代码库
```
R CORE TEAM. R: A language and environment for statistical computing. Vienna:
R Foundation for Statistical Computing, 2024. Disponível em: https://www.r-project.org.
```

---

## 可审计脚注模板 — 强制使用

引用任何来源时，须添加脚注：

```
¹ [SOBRENOME, Ano, p. XX] — Título completo da obra. Periódico/Editora, Ano.
  DOI: 10.XXXX/XXXXX（或完整URL + 访问日期）.
  物理位置：图书馆X / 馆藏Y / 永久链接Z.
```

填写示例：
```
¹ [LEZAK et al., 2004, p. 35] — Neuropsychological Assessment. 4. ed. Oxford:
  Oxford University Press, 2004. ISBN: 978-0-19-511121-7.

² [BRASIL, 2002, Art. 186] — Código Civil Brasileiro. Lei nº 10.406/2002.
  Disponível em: https://www.planalto.gov.br/ccivil_03/leis/2002/l10406compilada.htm
  Acesso em: 8 mar. 2026.
```

---

## 绝对禁止的错误

❌ 无页码引用："(SILVA, 2020)" — 错误
✅ 含页码引用："(SILVA, 2020, p. 45)" — 正确

❌ 参考文献列表中有未在正文中引用的文献
❌ 正文中有引用但参考文献列表中无对应条目
❌ 对可直接获取的文献使用"apud"
❌ DOI无效或URL无法访问
❌ 引用未完整阅读的文献
