@echo off
chcp 65001 >nul
echo ============================================
echo   MASWOS MCP Server - Instalador
echo ============================================
echo.

REM Obter caminho do script
set "SCRIPT_DIR=%~dp0"
set "INSTALL_DIR=%USERPROFILE%\.config\opencode"
set "MCP_PATH=%INSTALL_DIR%\maswos-mcp"

echo [1/3] Criando diretório de instalação...
if not exist "%MCP_PATH%" mkdir "%MCP_PATH%"

echo [2/3] Copiando arquivos do servidor...
xcopy /E /Y "%SCRIPT_DIR%server\*" "%MCP_PATH%\" >nul
echo.

echo [3/3] Configurando OpenCode...
powershell -Command "
$configPath = '%INSTALL_DIR%\opencode.json'
$serverConfig = Get-Content '%SCRIPT_DIR%config\opencode.json' -Raw | ConvertFrom-Json
$serverPath = '%MCP_PATH%\dist\index.js'
$serverConfig.mcp.maswos.command = @('node', $serverPath)

if (Test-Path $configPath) {
    $config = Get-Content $configPath -Raw | ConvertFrom-Json
    $config.mcp = $serverConfig.mcp
    $config | ConvertTo-Json -Depth 10 | Set-Content $configPath
} else {
    @{
        '$schema' = 'https://opencode.ai/config.json'
        mcp = $serverConfig.mcp
    } | ConvertTo-Json -Depth 10 | Set-Content $configPath
}
"

echo.
echo ============================================
echo   Instalacao concluida!
echo ============================================
echo.
echo Caminho: %MCP_PATH%
echo.
echo Para testar, execute:
echo   opencode mcp list
echo.
pause
