# MASWOS MCP Server - Distribuição

## Instalação Rápida

### Windows

1. Extraia o arquivo ZIP
2. Execute `install.bat` (clique duplo)
3. Confirme a instalação
4. Teste com `opencode mcp list`

### Linux/Mac

```bash
chmod +x install.sh
./install.sh
```

---

## Estrutura

```
maswos-mcp-dist/
├── server/                    # Arquivos do servidor
│   ├── dist/                  # Código compilado
│   │   ├── index.js          # Entry point
│   │   ├── agents/
│   │   └── types/
│   └── package.json
├── config/
│   └── mcp-config.json       # Template de configuração
├── scripts/
│   ├── install.bat           # Instalador Windows
│   └── install.sh           # Instalador Linux/Mac
└── README.md                 # Este arquivo
```

---

## Pré-requisitos

- **Node.js** >= 18.0.0
- **OpenCode** >= 1.2.27

### Instalar Node.js

```bash
# Windows: https://nodejs.org
# Linux:  sudo apt install nodejs
# Mac:    brew install node
```

### Instalar OpenCode

```bash
# https://opencode.ai
```

---

## Ferramentas Disponíveis (12)

| Tool | Descrição |
|------|-----------|
| `maswos_create_skill` | Cria skill completo |
| `maswos_parse_intent` | Extrai intent do usuário |
| `maswos_analyze_domain` | Analisa domínio |
| `maswos_map_scope` | Mapeia features/agentes |
| `maswos_validate_constraints` | Valida constraints |
| `maswos_generate_agents` | Gera código de agentes |
| `maswos_assemble_skill` | Compila SKILL.md |
| `maswos_validate_skill` | Valida skill final |
| `maswos_critic_route` | Avalia qualidade |
| `maswos_list_agents` | Lista agentes |
| `maswos_get_agent_info` | Info de agente |
| `maswos_run_workflow` | Executa pipeline |

---

## Uso

### Via OpenCode

```bash
opencode
# Diga: "criar skill para análise de contratos"
```

### Via CLI

```bash
cd server
npm install
node dist/index.js
```

---

## Testar Instalação

```bash
opencode mcp list
```

Saída esperada:
```
┌───────────────
│ MCP Servers
│
● ✓ maswos connected
│
└── 1 server(s)
```

---

## Desinstalar

### Windows

```powershell
Remove-Item -Recurse -Force "$env:USERPROFILE\.config\opencode\maswos-mcp"
```

### Linux/Mac

```bash
rm -rf ~/.config/opencode/maswos-mcp
```

---

## Solução de Problemas

### Server não inicia

```bash
cd ~/.config/opencode/maswos-mcp/server
node dist/index.js
```

### Erro de conexão

```bash
opencode mcp list
# Verifique se mostra "connected"
```

---

## Versão

v1.0.0 - MASWOS V5 NEXUS

---

## Licença

MIT
