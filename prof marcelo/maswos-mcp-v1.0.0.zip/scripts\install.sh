#!/bin/bash
set -e

echo "============================================"
echo "  MASWOS MCP Server - Instalador"
echo "============================================"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$HOME/.config/opencode"
MCP_PATH="$INSTALL_DIR/maswos-mcp"

echo "[1/3] Criando diretório de instalação..."
mkdir -p "$MCP_PATH"

echo "[2/3] Copiando arquivos do servidor..."
cp -r "$SCRIPT_DIR/server/"* "$MCP_PATH/"
echo ""

echo "[3/3] Configurando OpenCode..."
SERVER_PATH="$MCP_PATH/dist/index.js"

# Backup config if exists
if [ -f "$INSTALL_DIR/opencode.json" ]; then
    cp "$INSTALL_DIR/opencode.json" "$INSTALL_DIR/opencode.json.bak"
fi

# Create config
cat > "$INSTALL_DIR/opencode.json" << EOF
{
  "\$schema": "https://opencode.ai/config.json",
  "mcp": {
    "maswos": {
      "type": "local",
      "command": ["node", "$SERVER_PATH"]
    }
  }
}
EOF

echo ""
echo "============================================"
echo "  Instalação concluída!"
echo "============================================"
echo ""
echo "Caminho: $MCP_PATH"
echo ""
echo "Para testar, execute:"
echo "  opencode mcp list"
echo ""
