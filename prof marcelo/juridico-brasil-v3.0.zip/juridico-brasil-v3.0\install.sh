#!/bin/bash
# ============================================================
# JURÍDICO BRASIL v3.0 - SCRIPT DE INSTALAÇÃO
# Sistema de Advocacia Universal PhD Summa
# ============================================================

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║        JURÍDICO BRASIL v3.0 - INSTALAÇÃO              ║"
echo "║        Sistema de Advocacia Universal PhD Summa         ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""

# Verifica se está no diretório correto
if [ ! -d ".opencode" ]; then
    echo "[ERRO] Pasta .opencode não encontrada!"
    echo "Execute este script no diretório raiz do MASWOS/OpenCode."
    exit 1
fi

# Verifica se já existe versão anterior
if [ -d ".opencode/skills/juridico-brasil" ]; then
    echo "[AVISO] Skill juridico-brasil já existe!"
    read -p "Deseja substituir? (S/N): " CONFIRM
    if [ "$CONFIRM" != "S" ] && [ "$CONFIRM" != "s" ]; then
        echo "Instalação cancelada."
        exit 0
    fi
    echo "[INFO] Removendo versão anterior..."
    rm -rf ".opencode/skills/juridico-brasil"
fi

# Copia os arquivos
echo "[INFO] Instalando skill juridico-brasil v3.0..."
cp -r "./juridico-brasil-v3.0" ".opencode/skills/juridico-brasil"

if [ $? -ne 0 ]; then
    echo "[ERRO] Falha na instalação!"
    exit 1
fi

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║           INSTALAÇÃO CONCLUÍDA COM SUCESSO!            ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "Para usar o skill, digite:"
echo "  /skill juridico-brasil"
echo ""
echo "  Agentes instalados: 34+"
echo "  Qualificações: OAB, STF, STJ, QUALIS A1, PhD Summa"
echo ""
