@echo off
REM ============================================================
REM JURÍDICO BRASIL v3.0 - SCRIPT DE INSTALAÇÃO
REM Sistema de Advocacia Universal PhD Summa
REM ============================================================

echo.
echo  ╔══════════════════════════════════════════════════════════╗
echo  ║        JURÍDICO BRASIL v3.0 - INSTALAÇÃO              ║
echo  ║        Sistema de Advocacia Universal PhD Summa         ║
echo  ╚══════════════════════════════════════════════════════════╝
echo.

REM Verifica se está no diretório correto
if not exist ".opencode" (
    echo [ERRO] Pasta .opencode não encontrada!
    echo Execute este script no diretório raiz do MASWOS/OpenCode.
    pause
    exit /b 1
)

REM Verifica se já existe versão anterior
if exist ".opencode\skills\juridico-brasil" (
    echo [AVISO] Skill juridico-brasil já existe!
    echo Deseja substituir? (S/N)
    set /p CONFIRM=
    if /i not "%CONFIRM%"=="S" (
        echo Instalação cancelada.
        pause
        exit /b 0
    )
    echo [INFO] Removendo versão anterior...
    rmdir /s /q ".opencode\skills\juridico-brasil"
)

REM Copia os arquivos
echo [INFO] Instalando skill juridico-brasil v3.0...
xcopy /E /I /Y "juridico-brasil-v3.0" ".opencode\skills\juridico-brasil"

if %errorlevel% neq 0 (
    echo [ERRO] Falha na instalação!
    pause
    exit /b 1
)

echo.
echo  ╔══════════════════════════════════════════════════════════╗
echo  ║           INSTALAÇÃO CONCLUÍDA COM SUCESSO!            ║
echo  ╚══════════════════════════════════════════════════════════╝
echo.
echo Para usar o skill, digite:
echo   /skill juridico-brasil
echo.
echo  Agentes instalados: 34+
echo  Qualificações: OAB, STF, STJ, QUALIS A1, PhD Summa
echo.
pause
