# JURÍDICO BRASIL v3.0 - PACOTE DE DISTRIBUIÇÃO

## Arquivo: INSTALL.md

---

# INSTRUÇÕES DE INSTALAÇÃO

## JURÍDICO BRASIL v3.0
### Sistema de Advocacia Universal PhD Summa

**Versão:** 3.0.0  
**Autor:** MASWOS V5 NEXUS  
**Licença:** MIT  
**Domínio:** Legal  
**TIER:** Magnum (34+ Agentes)  

---

## REQUISITOS

1. **MASWOS V5 NEXUS** ou **OpenCode** instalado
2. **Node.js 18+** (opcional, para customizações)
3. **Git** (opcional, para atualização)

---

## INSTALAÇÃO

### Método 1: Copia Direta (Recomendado)

1. Copie a pasta `juridico-brasil-v3.0` para:
   ```
   .opencode/skills/
   ```

2. Estrutura final:
   ```
   .opencode/
   └── skills/
       └── juridico-brasil-v3.0/
           ├── package.json
           ├── SKILL.md
           ├── README.md
           ├── agents/
           ├── templates/
           └── references/
   ```

3. Reinicie o MASWOS/OpenCode

### Método 2: via Git

```bash
cd .opencode/skills/
git clone <REPOSITORIO> juridico-brasil-v3.0
```

### Método 3: via NPM (Futuro)

```bash
npm install @maswos/juridico-brasil
```

---

## ESTRUTURA DO SKILL

```
juridico-brasil-v3.0/
├── SKILL.md                    # Arquitetura principal
├── README.md                   # Documentação
├── package.json                # Configuração npm
├── MANIFEST.json               # Manifesto de distribuição
├── agents/                     # 35 agentes especializados
│   ├── 00_juridico_orchestrator.md
│   ├── 25_jurista_supremo_phd.md    # ★ PhD Summa
│   ├── 34_coordenador_tribunais.md
│   └── ... (35 arquivos)
├── templates/                  # 11 templates
│   ├── peticion_inicial_civel.md
│   ├── recurso.md
│   └── ... (11 arquivos)
└── references/                 # Conhecimento
    ├── autoridades_bibliografia.md  # ★ 100+ refs reais
    ├── jurisprudencia_index.md
    ├── legislacao_index.md
    └── scrapers_guide.md
```

---

## USO

### Ativar o Skill

```
/skill juridico-brasil
```

### Comandos Principais

```bash
# Gerar petição
" Gere petição inicial de danos morais contra banco X"

// Analisar precedente
" Analise o RE 1.000.000"

// Buscar jurisprudência
" Encontre precedentes STF sobre desconsideração da personalidade jurídica"

// Auditar documento
" Audite citações do documento X"

// Contra-argumentação
" Construa contra-argumentação para Y"
```

---

## QUALIFICAÇÕES

| Certificação | Status |
|--------------|--------|
| **OAB** | ✓ Padrão |
| **STF** | ✓ Critérios |
| **STJ** | ✓ Critérios |
| **QUALIS A1** | ✓ Referências |
| **PHD SUMMA** | ✓ Jurista Supremo |

---

## AGENTES (34+)

### Tribunal Supremo
- 25 - JURISTA SUPREMO PhD ★★★
- 13 - GERENTE SUPREMO FEDERAL ★★

### Especialistas (9)
- 14 - Civil | 15 - Constitucional ★★★
- 16 - Penal ★★★ | 17 - Trabalhista
- 18 - Tributário | 19 - Consumidor
- 20 - Administrativo | 21 - Empresarial
- 22 - Internacional

### Cirúrgicos (8)
- 26 - Analista Precedentes ★
- 27 - Cirurgião Recursos ★
- 28 - Auditor Citações ★
- 29 - Perito Linguagem ★
- 30 - Estrategista ★
- 31 - Analista Vulnerabilidades
- 32 - Revisor Tese ★
- 33 - Gestor Trâmites

---

## RATINGS DE APROVAÇÃO

| Rating | Score | Status |
|--------|-------|--------|
| ⚖️ LEXIT MAXIMUS | 97-100 | Pronto imediato |
| ✓ APROVADO | 90-96 | Com ajustes |
| ⚠ APROVADO C/RESSALVAS | 80-89 | Revisão menor |
| ⚠ REVISÃO NECESSÁRIA | 65-79 | Reformulação |
| ✗ REJEITADO | <65 | Rebase |

---

## ATUALIZAÇÕES

Para verificar atualizações:
```bash
# Futura implementação
npm update @maswos/juridico-brasil
```

---

## SUPORTE

- **Issues:** https://github.com/maswos/juridico-brasil/issues
- **Email:** suporte@maswos.com.br

---

## CHANGELOG

### v3.0.0
- 34+ agentes especializados
- Jurista Supremo PhD Summa
- 8 agentes granulares cirúrgicos
- 100+ referências bibliográficas reais
- Ratings de aprovação Lexit
- Índices de jurisprudência expandidos

### v2.0.0
- 24 agentes
- Gerente Supremo Federal PhD
- 9 especialistas por área
- Templates expandidos

### v1.0.0
- Lançamento inicial
- 13 agentes básicos

---

**JURÍDICO BRASIL v3.0**  
*Advocacia Universal PhD Summa*  
*Compatible with MASWOS V5 NEXUS & OpenCode*
