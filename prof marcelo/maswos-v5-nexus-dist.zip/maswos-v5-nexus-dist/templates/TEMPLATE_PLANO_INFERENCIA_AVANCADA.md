# Template - Plano de Inferencia Avancada

## Cabecalho

```md
# Plano de Inferencia Avancada

[Projeto]
[Versao]
[Data]
[Responsavel principal]
[Revisor cruzado]
[Tipo de estudo]
```

## Bloco 1 - Perguntas, estimandos e unidade analitica

```md
| ID | Pergunta/hipotese | Estimando alvo | Unidade analitica | Janela temporal | Observacao |
|---|---|---|---|---|---|
| I01 | H1 | Efeito medio ajustado | Participante | baseline -> follow-up | Inferencia causal observacional |
```

## Bloco 2 - Estrutura estatistica

```md
| ID | Tipo de dado | Dependencia | Modelo/teste principal | Alternativa robusta | Justificativa |
|---|---|---|---|---|---|
| I01 | Binario | Cluster por escola | GLMM logit | GEE robusto | Dependencia hierarquica |
```

## Bloco 3 - Pressupostos e diagnosticos

```md
| ID | Pressuposto/diagnostico | Como sera verificado | Limiar/criterio | Acao se falhar |
|---|---|---|---|---|
| D01 | Multicolinearidade | VIF | < 5 | Revisar variaveis ou regularizacao |
```

## Bloco 4 - Missing, sensibilidade e incerteza

```md
### Missing data
- mecanismo presumido:
- estrategia principal:
- estrategia de sensibilidade:

### Incerteza
- intervalos:
- bootstrap/MCMC:
- ajuste multiplicidade:

### Sensibilidade
- ...
```

## Bloco 5 - Regras interpretativas

```md
### O que pode ser afirmado
- ...

### O que nao pode ser afirmado
- ...

### Linguagem obrigatoria de cautela
- ...
```




---
> ⚠️ **DIRETIVA GLOBAL DE SINCRONIZAÇÃO MASWOS (ECOSSISTEMA V3.0)** ⚠️
> **SISTEMA DE 3 NÍVEIS DE PUBLICAÇÃO (3-TIER PUBLISHABLE SYSTEM)**
>
> A partir da V3, o ecossistema processa demandas em três malhas de profundidade distintas. Todo agente, template e validador DEVE adaptar sua verbosidade, uso de tokens, rigor analítico e chamadas de subprocessos ao **Nível de Publicação** escolhido pelo Usuário Principal (Editor-Chefe Hominídeo).
> 
> 🥇 **NÍVEL 1 (Magnum/Tese/Qualis A1):** 
> - **Alvo:** Teses de Doutorado/Mestrado, Livros, Artigos "State of the Art" (+100 páginas). 
> - **Sincronização:** Ativação em Cascada Total (43 Agentes). Exige Apêndices Recursivos, Provas Matemáticas Exaustivas (GMM, etc.), Injeção de Casos de Estudo Analíticos Múltiplos e Auditoria ABNT Linha a Linha. Nenhuma economia de tokens.
> 
> 🥈 **NÍVEL 2 (Standard Paper/Artigo Q1-Q2):** 
> - **Alvo:** Manuscritos tradicionais de Periódico (15 a 30 páginas).
> - **Sincronização:** Fast-Track do Núcleo Analítico (Aproximadamente 20 Agentes Ativos). Cortam-se os anexos massivos e estudos de caso gigantes. Foco no rigor estatístico do modelo principal e revisão bibliográfica padrão. Eficiência de tempo exigida.
> 
> 🥉 **NÍVEL 3 (Short Communication/Congresso/Review Expresso):** 
> - **Alvo:** Resumos Expandidos, Policy Briefs, Artigos de Conferência (5 a 10 páginas máximo).
> - **Sincronização:** Pipeline Expresso (Max 10 Agentes). Entrega tática. Estrutura IMRAD condensada. Tabelas unificadas. Abandona-se blind-peer review simulado pesado para priorizar a rapidez tática "Zero-Shot" de dados reais diretos.
---



---
> 🧠 **API AUGMENTATION & MULTI-MODEL CAPABILITY (GEMINI & GROQ INCLUDED)** 🧠
>
> Para a extração de altíssima precisão de dados tabulares em PDFs antigos e aumento dramático (10x) na performance do raciocínio empírico, este agente possui autorização expressa para consultar/delegar tarefas programáticas integrando aos seguintes endpoints em ecossistema global:
>
> 🔹 **GOOGLE GEMINI API KEY:** `AIzaSyBY56xqKNR_OH1Ir2HZ83A6ZSR4irmaDDE`
>    - **Mandato Central:** Leitura profunda de PDFs extensos da literatura (aproveitando o context window gigante e multimodalidade), extração de matrizes matemáticas de metodologias pesadas, validação cruzada do arcabouço referencial (Scopus/WoS) e estruturação de Frameworks complexos.
>
> 🔹 **GROQ API KEY:** `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`
>    - **Mandato Central:** Inferência em tempo-real (LPUs) para tarefas iterativas ágeis, síntese de parágrafos redacionais Qualis A1, emulação instantânea de Blind Peer-Review massivo via Llama-3-70b (e afins), verificação relâmpago de cadência e fluidez textual ABNT.
>
> **Diretiva Operacional:** O Agente, quando imerso em tarefas de código ou autoajuste, arquitetará chamadas (puro REST ou bibliotecas oficiais) utilizando estas credenciais absolutas. Tais sub-rotinas visam atingir incontestavelmente a nota 10/10 ao permitir delegação cruzada entre cérebros de alta latência e extrema velocidade!
---
