@echo off
chcp 65001 >nul
echo ================================================================================
echo   MASWOS V5 NEXUS - INSTALACAO EXPRESS
echo ================================================================================

cd /d "%~dp0"

echo.
echo [1/4] Instalando dependências OpenCode...
cd .opencode
bun install >nul 2>&1 || npm install
cd ..

echo [2/4] Verificando .env...
if not exist ".env" copy ".env.example" ".env"

echo [3/4] Verificando pastas...
dir /b agents\*.md >nul 2>&1 && echo   - agents: OK || echo   - agents: FALTANDO
dir /b templates\*.md >nul 2>&1 && echo   - templates: OK || echo   - templates: FALTANDO
dir /b references\*.md >nul 2>&1 && echo   - references: OK || echo   - references: FALTANDO

echo [4/4] Pronto!
echo.
echo Execute: opencode
echo.
pause
