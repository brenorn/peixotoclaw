@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ================================================================================
echo   MASWOS V5 NEXUS - INSTALADOR AUTOMATICO
echo   Multi-Agent Scientific Writing Operating System
echo ================================================================================
echo.

REM ========================================
REM VERIFICACOES INICIAIS
REM ========================================

echo [1/6] Verificando pre-requisitos...
echo.

REM Verificar Node.js
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo   [ERRO] Node.js NAO encontrado!
    echo   Baixe em: https://nodejs.org/
    echo   Pressione qualquer tecla para sair...
    pause >nul
    exit /b 1
)

for /f "tokens=*" %%i in ('node -v') do set NODE_VERSION=%%i
echo   [OK] Node.js: !NODE_VERSION!

REM Verificar Bun
where bun >nul 2>&1
if %errorlevel% neq 0 (
    echo   [AVISO] Bun NAO encontrado. Instalando...
    powershell -Command "irm bun.sh/install.ps1 | iex"
    if !errorlevel! neq 0 (
        echo   [ERRO] Falha ao instalar Bun.
        echo   Tente instalar manualmente: https://bun.sh
        echo   Pressione qualquer tecla para continuar...
        pause >nul
    ) else (
        echo   [OK] Bun instalado com sucesso!
    )
) else (
    for /f "tokens=*" %%i in ('bun -v') do set BUN_VERSION=%%i
    echo   [OK] Bun: !BUN_VERSION!
)

REM Verificar OpenCode
where opencode >nul 2>&1
if %errorlevel% neq 0 (
    echo   [AVISO] OpenCode NAO encontrado. Instalando...
    npm install -g @opencode-ai/cli
    if !errorlevel! neq 0 (
        echo   [ERRO] Falha ao instalar OpenCode.
    ) else (
        echo   [OK] OpenCode instalado!
    )
) else (
    for /f "tokens=*" %%i in ('opencode -v') do set OPENCODE_VERSION=%%i
    echo   [OK] OpenCode: !OPENCODE_VERSION!
)

echo.
echo ================================================================================
echo   [2/6] Instalando dependencias do projeto...
echo ================================================================================
echo.

cd /d "%~dp0.opencode"
if exist "package.json" (
    echo   Executando bun install...
    bun install
    if !errorlevel! neq 0 (
        echo   [AVISO] Tentando com npm...
        npm install
    )
) else (
    echo   [ERRO] package.json nao encontrado!
)

cd /d "%~dp0"

echo.
echo ================================================================================
echo   [3/6] Configurando variaveis de ambiente...
echo ================================================================================
echo.

if not exist ".env" (
    if exist ".env.example" (
        copy ".env.example" ".env"
        echo   [OK] Arquivo .env criado a partir do modelo.
    ) else (
        echo   [ERRO] .env.example nao encontrado!
    )
) else (
    echo   [OK] Arquivo .env ja existe.
)

echo.
echo ================================================================================
echo   [4/6] Verificando estrutura de pastas...
echo ================================================================================
echo.

set PASTA_OK=1

if not exist ".opencode" (
    echo   [ERRO] Pasta .opencode faltando!
    set PASTA_OK=0
) else (
    echo   [OK] .opencode/
)

if not exist "agents" (
    echo   [ERRO] Pasta agents faltando!
    set PASTA_OK=0
) else (
    echo   [OK] agents/
)

if not exist "references" (
    echo   [ERRO] Pasta references faltando!
    set PASTA_OK=0
) else (
    echo   [OK] references/
)

if not exist "templates" (
    echo   [ERRO] Pasta templates faltando!
    set PASTA_OK=0
) else (
    echo   [OK] templates/
)

if !PASTA_OK! equ 0 (
    echo.
    echo   [ERRO] Estrutura incompleta! Baixe o pacote completo.
    pause >nul
    exit /b 1
)

echo.
echo ================================================================================
echo   [5/6] Verificacao de integridade...
echo ================================================================================

echo.
echo   Contando agentes...
set AGENT_COUNT=0
for %%f in (agents\*.md) do set /a AGENT_COUNT+=1
echo   [OK] !AGENT_COUNT! agentes encontrados

echo.
echo   Contando templates...
set TEMPLATE_COUNT=0
for %%f in (templates\*.md) do set /a TEMPLATE_COUNT+=1
echo   [OK] !TEMPLATE_COUNT! templates encontrados

echo.
echo   Contando referencias...
set REF_COUNT=0
for %%f in (references\*.md) do set /a REF_COUNT+=1
echo   [OK] !REF_COUNT! arquivos de referencia

echo.
echo ================================================================================
echo   [6/6] OLLAMA (Opcional - Privacy/Offline)
echo ================================================================================
echo.

echo   Deseja instalar o Ollama para uso offline? (S/N)
set /p OLLAMA_INST=

if /i "%OLLAMA_INST%"=="S" (
    echo.
    echo   Baixando Ollama...
    powershell -Command "Invoke-WebRequest -Uri 'https://ollama.com/install.ps1' -OutFile 'install_ollama.ps1'"
    powershell -ExecutionPolicy Bypass -File install_ollama.ps1
    del install_ollama.ps1
    
    if exist "C:\Ollama\ollama.exe" (
        echo.
        echo   [OK] Ollama instalado! Baixando modelo base...
        ollama pull llama3.2
        echo.
        echo   Para usar com OpenCode, edite opencode.json e defina:
        echo   "model": "ollama/llama3.2"
    )
)

echo.
echo ================================================================================
echo   INSTALACAO CONCLUIDA!
echo ================================================================================
echo.
echo   PROXIMOS PASSOS:
echo   ----------------
echo   1. Edite o arquivo .env com suas chaves de API (se necessario)
echo   2. Execute: opencode
echo   3. O sistema detectara o skill automaticamente
echo.
echo   DOCUMENTACAO: Leia o README.md para detalhes
echo.
echo   Pressione qualquer tecla para sair...
pause >nul
