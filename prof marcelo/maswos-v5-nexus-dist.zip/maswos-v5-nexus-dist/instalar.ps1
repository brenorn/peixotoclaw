# MASWOS V5 NEXUS - Instalador PowerShell
# Execute como: powershell -ExecutionPolicy Bypass -File instalar.ps1

Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  MASWOS V5 NEXUS - INSTALADOR AUTOMATICO" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""

$ErrorActionPreference = "Continue"

# ========================================
# 1. Verificar Pre-requisitos
# ========================================
Write-Host "[1/6] Verificando pre-requisitos..." -ForegroundColor Yellow
Write-Host ""

# Node.js
$node = Get-Command node -ErrorAction SilentlyContinue
if ($node) {
    $nodeVersion = node -v
    Write-Host "   [OK] Node.js: $nodeVersion" -ForegroundColor Green
} else {
    Write-Host "   [ERRO] Node.js NAO encontrado!" -ForegroundColor Red
    Write-Host "   Baixe em: https://nodejs.org/" -ForegroundColor Yellow
}

# Bun
$bun = Get-Command bun -ErrorAction SilentlyContinue
if ($bun) {
    $bunVersion = bun -v
    Write-Host "   [OK] Bun: $bunVersion" -ForegroundColor Green
} else {
    Write-Host "   [AVISO] Bun NAO encontrado. Tentando instalar..." -ForegroundColor Yellow
    iwr bun.sh/install.ps1 -UseBasicParsing | iex
    $bun = Get-Command bun -ErrorAction SilentlyContinue
    if ($bun) { Write-Host "   [OK] Bun instalado!" -ForegroundColor Green }
}

# OpenCode
$opencode = Get-Command opencode -ErrorAction SilentlyContinue
if ($opencode) {
    Write-Host "   [OK] OpenCode instalado" -ForegroundColor Green
} else {
    Write-Host "   [AVISO] OpenCode NAO encontrado. Instalando..." -ForegroundColor Yellow
    npm install -g @opencode-ai/cli
    $opencode = Get-Command opencode -ErrorAction SilentlyContinue
    if ($opencode) { Write-Host "   [OK] OpenCode instalado!" -ForegroundColor Green }
}

Write-Host ""

# ========================================
# 2. Instalar Dependencias
# ========================================
Write-Host "[2/6] Instalando dependencias..." -ForegroundColor Yellow
Write-Host ""

Push-Location "$PSScriptRoot\.opencode"
if (Test-Path "package.json") {
    if ($bun) { bun install } 
    else { npm install }
    Write-Host "   [OK] Dependencias instaladas" -ForegroundColor Green
} else {
    Write-Host "   [ERRO] package.json nao encontrado" -ForegroundColor Red
}
Pop-Location

Write-Host ""

# ========================================
# 3. Configurar .env
# ========================================
Write-Host "[3/6] Configurando ambiente..." -ForegroundColor Yellow
Write-Host ""

if (-not (Test-Path ".env")) {
    if (Test-Path ".env.example") {
        Copy-Item ".env.example" ".env"
        Write-Host "   [OK] Arquivo .env criado" -ForegroundColor Green
    }
} else {
    Write-Host "   [OK] .env ja existe" -ForegroundColor Green
}

Write-Host ""

# ========================================
# 4. Verificar Estrutura
# ========================================
Write-Host "[4/6] Verificando estrutura..." -ForegroundColor Yellow
Write-Host ""

$folders = @(".opencode", "agents", "references", "templates")
foreach ($folder in $folders) {
    if (Test-Path $folder) {
        Write-Host "   [OK] $folder/" -ForegroundColor Green
    } else {
        Write-Host "   [ERRO] $folder/ faltando!" -ForegroundColor Red
    }
}

Write-Host ""

# ========================================
# 5. Contagem de Arquivos
# ========================================
Write-Host "[5/6] Integridade dos arquivos..." -ForegroundColor Yellow
Write-Host ""

$agentCount = (Get-ChildItem agents -Filter "*.md" -ErrorAction SilentlyContinue).Count
$templateCount = (Get-ChildItem templates -Filter "*.md" -ErrorAction SilentlyContinue).Count
$refCount = (Get-ChildItem references -Filter "*.md" -ErrorAction SilentlyContinue).Count

Write-Host "   Agentes: $agentCount" -ForegroundColor Cyan
Write-Host "   Templates: $templateCount" -ForegroundColor Cyan
Write-Host "   Referencias: $refCount" -ForegroundColor Cyan

Write-Host ""

# ========================================
# 6. Ollama (Opcional)
# ========================================
Write-Host "[6/6] Ollama - Instalacao Offline/Oprivacidade" -ForegroundColor Yellow
Write-Host ""

$ollama = Get-Command ollama -ErrorAction SilentlyContinue
if ($ollama) {
    Write-Host "   [OK] Ollama ja instalado" -ForegroundColor Green
} else {
    Write-Host "   Ollama nao detectado. Deseja instalar? (S/N): " -NoNewline
    $resposta = Read-Host
    if ($resposta -eq "S") {
        Write-Host "   Baixando Ollama..." -ForegroundColor Yellow
        iwr https://ollama.com/install.ps1 -OutFile install_ollama.ps1
        .\install_ollama.ps1
        Remove-Item install_ollama.ps1 -Force
        
        if (Test-Path "$env:LOCALAPPDATA\Ollama\ollama.exe") {
            Write-Host "   [OK] Ollama instalado! Baixando modelo..." -ForegroundColor Green
            ollama pull llama3.2
            Write-Host ""
            Write-Host "   Para usar no OpenCode, edite opencode.json:" -ForegroundColor Cyan
            Write-Host '   "model": "ollama/llama3.2"' -ForegroundColor Cyan
        }
    }
}

Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  INSTALACAO CONCLUIDA!" -ForegroundColor Green
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "PROXIMOS PASSOS:" -ForegroundColor Yellow
Write-Host "1. Edite o arquivo .env com suas chaves de API"
Write-Host "2. Execute: opencode"
Write-Host "3. O sistema detectara o skill automaticamente"
Write-Host ""
Write-Host "Documentacao: Leia o README.md" -ForegroundColor Cyan
Write-Host ""

Read-Host "Pressione ENTER para sair"
