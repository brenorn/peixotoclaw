# MASWOS V5 NEXUS - Pacote de Distribuição e Auditoria Acadêmica

## Sumário

1. [Visão Geral do Sistema](#visão-geral-do-sistema)
2. [Pré-requisitos](#pré-requisitos)
3. [Instalação](#instalação)
   - [3.1 Clonar o Repositório](#31-clonar-o-repositório)
   - [3.2 Configurar o OpenCode](#32-configurar-o-opencode)
   - [3.3 Variáveis de Ambiente](#33-variáveis-de-ambiente)
   - [3.4 Instalação do Ollama (Opcional)](#34-instalação-do-ollama-opcional)
4. [Estrutura de Diretórios](#estrutura-de-diretórios)
5. [Guia de Uso](#guia-de-uso)
   - [5.1 Ativando o Skill](#51-ativando-o-skill)
   - [5.2 Fluxo de Trabalho](#52-fluxo-de-trabalho)
   - [5.3 Usando com Ollama](#53-usando-com-ollama)
6. [Entendendo os Componentes](#entendendo-os-componentes)
   - [6.1 Agents (Agentes)](#61-agents-agentes)
   - [6.2 OpenCode](#62-opencode)
   - [6.3 Skill do Sistema](#63-skill-do-sistema)
   - [6.4 References (Referências)](#64-references-referências)
   - [6.5 Templates (Modelos)](#65-templates-modelos)
   - [6.6 Framework](#66-framework)
   - [6.7 Variáveis de Ambiente (.env)](#67-variáveis-de-ambiente-env)
7. [Arquitetura do Sistema](#arquitetura-do-sistema)
8. [Importância dos Agentes na Produção Acadêmica](#importância-dos-agentes-na-produção-acadêmica)
9. [Glossário](#glossário)

---

## 1. Visão Geral do Sistema

**MASWOS V5 NEXUS** (Multi-Agent Scientific Writing Operating System) é uma arquitetura cognitiva avançada baseada em agentes para redação acadêmica de alto nível. O sistema foi projetado para produzir artigos científicos com classificação **Qualis A1** (nota 10/10), utilizando:

- **43 agentes especializados** organizados em pipeline DAG (Directed Acyclic Graph)
- **Sistema de RAG** (Retrieval-Augmented Generation) com 45 scrapers
- **Protocolos de rigor auditável** com verificação cega de qualidade
- **Conformidade total** com normas ABNT e APA
- **Suporte a múltiplos níveis de publicação** (Tese, Artigo Q1, Short Paper)

O sistema funciona como uma "Rede Transformer de Sub-Agentes", onde um agente principal orquestra múltiplos sub-agentes especializados em loop contínuo de `Geração ⟷ Crítica ⟷ Refinamento`.

---

## 2. Pré-requisitos

Antes de instalar, certifique-se de ter:

| Requisito | Versão Mínima | Descrição |
|-----------|---------------|------------|
| **Node.js** | 18.x ou superior | Ambiente de execução JavaScript |
| **Bun** | 1.0 ou superior | Gerenciador de pacotes (alternativa ao npm) |
| **OpenCode** | 1.2.27+ | CLI de agentes de IA |
| **Ollama** (opcional) | 0.1+ | Modelo local para inference offline |

### Por que cada pré-requisito?

- **Node.js**: O OpenCode utiliza o SDK JavaScript da Anomaly para executar agentes
- **Bun**: Gerenciador de pacotes mais rápido que o npm, usado para instalar dependências
- **OpenCode**: A plataforma CLI que orchestrou toda a arquitetura de agentes
- **Ollama**: Permite executar modelos LLM localmente (privacy-first, offline)

---

## 3. Instalação

### 3.1 Clonar o Repositório

```bash
# Clone o repositório ou extraia o pacote distribuído
git clone https://github.com/seu-repositorio/maswos-v5-nexus-dist.git
cd maswos-v5-nexus-dist
```

### 3.2 Configurar o OpenCode

O OpenCode já está pré-configurado neste pacote. Para reinstallar as dependências:

```bash
# Navegue para o diretório .opencode
cd .opencode

# Instale as dependências (via Bun - recomendado)
bun install

# Ou via npm
npm install
```

O arquivo `package.json` especifica:

```json
{
  "dependencies": {
    "@opencode-ai/plugin": "1.2.27"
  }
}
```

### 3.3 Variáveis de Ambiente

Este pacote inclui dois arquivos de configuração:

#### `.env.example` (Modelo)
Copie para `.env` e configure suas credenciais:

```bash
cp .env.example .env
```

#### `.env` (Configuração Atual)
Contém as chaves API configuradas. **IMPORTANTE**: Nunca compartilhe este arquivo.

| Variável | Descrição |
|----------|------------|
| `OPENAI_API_KEY` | Chave da OpenAI |
| `GOOGLE_GEMINI_API_KEY` | Chave do Google Gemini |
| `GROQ_API_KEY` | Chave do Groq |
| `MODEL` | Modelo padrão (ex: `openai/llama3.2`) |

### 3.4 Instalação do Ollama (Opcional)

O Ollama permite executar modelos LLM localmente, sem dependência de APIs externas. Isso é ideal para:

- Ambientes offline
- Privacidade de dados
- Economia de custos
- Auditoria acadêmica local

#### Windows

1. Baixe o instalador em: https://ollama.com/download/windows
2. Execute o instalador `.exe`
3. Verifique a instalação:
   ```bash
   ollama --version
   ```

#### macOS/Linux

```bash
# curl -fsSL https://ollama.com/install.sh | sh
ollama --version
```

#### Baixando Modelos

```bash
# Modelo base leve (recomendado para começar)
ollama pull llama3.2

# Modelos maiores (opcional)
ollama pull mistral
ollama pull codellama
```

#### Configurando o OpenCode para usar Ollama

Edite o arquivo `opencode.json`:

```json
{
  "$schema": "https://opencode.ai/config.json",
  "model": "ollama/llama3.2"
}
```

---

## 4. Estrutura de Diretórios

```
maswos-v5-nexus-dist/
├── .opencode/                 # Configuração do OpenCode
│   ├── package.json          # Dependências Node.js
│   ├── skills/              # Skills do sistema
│   │   └── criador-de-artigo-v2/
│   │       └── SKILL.md    # Skill principal
│   └── bun.lock             # Lockfile do Bun
├── agents/                   # 43 agentes especializados
│   ├── 00_editor_chefe_phd.md
│   ├── 01_agente_diagnostico_escopo.md
│   ├── ...
│   ├── 43_agente_satelite_bioinformatica_omics.md
│   ├── README.md            # Guia de agentes
│   ├── DISPATCHER_ATIVACAO.md
│   └── TEMPLATE_HANDOFF.md
├── references/               # Documentação de referência
│   ├── arquitetura_multiagentes.md
│   ├── protocolo_rigor_auditavel.md
│   ├── nucleo_analitico_reprodutivel.md
│   ├── auditoria_codigo_cientifico.md
│   ├── checklist_qualis.md
│   ├── rubrica_avaliacao.md
│   └── ...
├── templates/               # Modelos de documentos
│   ├── TEMPLATE_MATRIZ_EVIDENCIAS.md
│   ├── TEMPLATE_CATALOGO_DATASETS.md
│   ├── TEMPLATE_AUDITORIA_FINAL_QUALIS.md
│   └── ... (21 templates)
├── .env                     # Variáveis de ambiente
├── .env.example             # Modelo de variáveis
└── opencode.json            # Configuração do OpenCode
```

---

## 5. Guia de Uso

### 5.1 Ativando o Skill

No terminal, com o OpenCode instalado:

```bash
opencode
```

O sistema detectará automaticamente o skill `criador-de-artigo-v2` e apresentará a interface de inicialização:

```
# 🏛️ MASWOS V5 NEXUS - HYBRID PIPELINE
> Inicialização da Rede Transformer de Engenharia Científica...
> Security Patch V5: Aplicado. RAG System: Standby.
> Scrapers: 45 APIs carregadas. DAG Orchestrator: Ready.
```

### 5.2 Fluxo de Trabalho

O sistema opera em **3 níveis de publicação**:

| Nível | Nome | Target | Agentes Ativos |
|-------|------|--------|----------------|
| 🥇 TIER 1 | MAGNUM | 110+ páginas (Tese/Livro) | 43 (Cascata Total) |
| 🥈 TIER 2 | STANDARD | 15-30 páginas (Artigo Q1) | ~20 (Núcleo Analítico) |
| 🥉 TIER 3 | EXPRESS | 5-10 páginas (Short Paper) | ~10 (Pipeline Expresso) |

**Fluxo Padrão:**

1. **Diagnóstico e Arquitetura** - Definir tema, gaps, escopo
2. **Busca e Curadoria** - Pesquisar literatura seminal
3. **Estrutura Argumentativa** - Definir hipóteses
4. **Redação** - Geração com crítica contínua
5. **Validação** - Auditoria ABNT e Qualis
6. **Exportação** - DOCX, LaTeX, PDF

### 5.3 Usando com Ollama

Para máxima privacidade e operação offline:

```bash
# Inicie o Ollama em background
ollama serve

# Configure no opencode.json
# "model": "ollama/llama3.2"

# Execute o opencode
opencode
```

---

## 6. Entendendo os Componentes

### 6.1 Agents (Agentes)

Os **43 agentes especializados** são o coração do sistema. Cada agente é responsável por uma etapa específica da produção acadêmica:

| Categoria | Agentes | Função |
|-----------|---------|--------|
| **Core Editorial** | 00-04 | Editor-Chefe, Diagnóstico, Busca, Evidências, Estrutura |
| **Metodologia** | 05-07 | Revisão Literatura, Metodologia, Estatística |
| **Resultados** | 08-11 | Visualização, Resultados, Discussão, Conclusão |
| **Qualidade** | 12-15 | ABNT, QA, Consistência, Abstract |
| **Técnicos** | 16-22 | DOCX, Reprodutibilidade, Dados, ML/DL |
| **Especializados** | 23-31 | Bioinfo, Química, Quantum, Benchmarking |
| **Formatação** | 32-38 | LaTeX, Peer-Review, Slides, Entrega Final |

**Por que 43 agentes?**
AFragmentação extrema permite:
- especialização profunda
- verificação cruzada
- paralelização de tarefas
- auditabilidade completa

### 6.2 OpenCode

O **OpenCode** é uma plataforma CLI que permite criar e orquestrar agentes de IA. No contexto do MASWOS:

- **Executor**: Rode os agentes via linha de comando
- **Orquestrador**: Gerencia o pipeline DAG
- **Configurável**: `opencode.json` define modelo, temperatura, etc.

### 6.3 Skill do Sistema

O **skill** (`SKILL.md`) é a definição de alto nível do comportamento do sistema. Ele contém:

- 📌 **Metadados**: Nome, descrição, versão
- 🧭 **Tier-Routing**: Sistema de 3 níveis de publicação
- 🧬 **RAG Protocol**: Diretrizes de citação e recuperação
- ⚙️ **DAG Workflow**: Orquestração de nós
- 🔒 **API Augmentation**: Configuração de APIs externas

### 6.4 References (Referências)

A pasta `references/` contém documentação técnica fundamental:

| Arquivo | Propósito |
|---------|-----------|
| `arquitetura_multiagentes.md` | Arquitetura detalhada do sistema |
| `protocolo_rigor_auditavel.md` | Procedimentos de auditoria |
| `nucleo_analitico_reprodutivel.md` | Núcleo de análise reprodutível |
| `auditoria_codigo_cientifico.md` | Guidelines para código científico |
| `checklist_qualis.md` | Checklist de avaliação Qualis A1 |
| `rubrica_avaliacao.md` | Rubrica de pontuação |

**Por que referências são importantes?**
- Asseguram que todos os agentes sigam o mesmo protocolo
- Documentam decisões de design
- Permitem auditoria externa
- Garantem reprodutibilidade

### 6.5 Templates (Modelos)

Os **21 templates** padronizam todas as saídas dos agentes:

| Template | Uso |
|----------|-----|
| `TEMPLATE_MATRIZ_EVIDENCIAS.md` | Organizar citações e evidências |
| `TEMPLATE_CATALOGO_DATASETS.md` | Catalogar datasets usados |
| `TEMPLATE_AUDITORIA_FINAL_QUALIS.md` | Auditoria final pré-publicação |
| `TEMPLATE_MANIFESTO_REPRODUTIBILIDADE.md` | Documentar reprodutibilidade |
| `TEMPLATE_REGISTRO_EXPERIMENTOS.md` | Registrar experimentos |
| `TEMPLATE_CODEBOOK_DADOS.md` | Dicionário de variáveis |

Cada agente deve preencher os templates obrigatórios antes de entregar.

### 6.6 Framework

O diretório `framework/` contém:

- **README.md**: Guia do framework de reprodutibilidade
- **Ambientes**: Configurações Docker/Conda para execução
- **Pipelines**: Scripts de processamento de dados

### 6.7 Variáveis de Ambiente (.env)

O arquivo `.env` é crítico para:

1. **Autenticação**:联结 às APIs externas (OpenAI, Gemini, Groq)
2. **Configuração**: Definir modelo padrão, região, etc.
3. **Privacidade**: Mantém credenciais fora do código fonte

**NUNCA** compartilhe o arquivo `.env` em repositórios públicos. Use `.env.example` como modelo.

---

## 7. Arquitetura do Sistema

```
┌─────────────────────────────────────────────────────────────────┐
│                     MASWOS V5 NEXUS                             │
│                   (Hybrid Pipeline DAG)                         │
└─────────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        ▼                     ▼                     ▼
┌───────────────┐     ┌───────────────┐     ┌───────────────┐
│  TIER 1       │     │  TIER 2       │     │  TIER 3       │
│  (MAGNUM)     │     │  (STANDARD)    │     │  (EXPRESS)    │
│  43 Agentes   │     │  ~20 Agentes   │     │  ~10 Agentes  │
└───────────────┘     └───────────────┘     └───────────────┘
        │                     │                     │
        └─────────────────────┼─────────────────────┘
                              ▼
              ┌───────────────────────────────┐
              │     SKILL (Orquestrador)       │
              │  ┌─────────────────────────┐  │
              │  │  TIER-ROUTING SYSTEM    │  │
              │  │  RAG & EPISTEMOLOGY     │  │
              │  │  DAG WORKFLOW           │  │
              │  │  6-LAYER PARAGRAPH      │  │
              │  └─────────────────────────┘  │
              └───────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        ▼                     ▼                     ▼
┌───────────────┐     ┌───────────────┐     ┌───────────────┐
│   OpenCode    │     │    Ollama     │     │  APIs Ext.    │
│   (CLI)       │     │   (Local)     │     │ (Gemini/GroQ) │
└───────────────┘     └───────────────┘     └───────────────┘
```

---

## 8. Importância dos Agentes na Produção Acadêmica

### Por que usar uma arquitetura multiagente?

#### 8.1 Especialização Profunda

Cada agente é um "especialista" em uma área:

- **Agente de Busca**: Domina estratégias de pesquisa
- **Agente de Estatística**: Mestre em análise quantitativa
- **Agente de ABNT**: Expert em formatação

#### 8.2 Verificação Cruzada

O padrão **Actor-Critic** garante qualidade:

```
<Agente>  ──gera──►  <Crítico>  ──avalia──►  <Revisor>
   ▲                                    │
   └──────────── feedback ──────────────┘
```

#### 8.3 Rastreabilidade

Cada agente:
- Registra suas fontes
- Preenche templates obrigatórios
- Deixa "rastros de auditoria"

#### 8.4 Paralelização

Agentes independentes podem rodar simultaneamente:
- Busca + Coleta de Dados
- estatística + Visualização

#### 8.5 Reproductibilidade

O sistema documenta cada decisão, permitindo:
- Replicar o processo
- Auditar第三方
- Publicar o código junto ao artigo

---

## 9. Glossário

| Termo | Significado |
|-------|-------------|
| **DAG** | Directed Acyclic Graph - Grafo acíclico orientado |
| **RAG** | Retrieval-Augmented Generation - Geração aumentada por recuperação |
| **Qualis** | Sistema de classificação de periódicos da CAPES |
| **ABNT** | Associação Brasileira de Normas Técnicas |
| **IMRAD** | Introduction, Methods, Results and Discussion |
| **Tier** | Nível de profundidade do artigo |
| **Skill** | Definição de comportamento do agente |
| **Handoff** | Transferência entre agentes |
| **Dispatcher** | Sistema de ativação condicional |

---

## Licença

Este pacote é distribuído para fins acadêmicos e de pesquisa.

---

## Suporte

Para dúvidas sobre instalação ou uso, consulte a documentação dos componentes individuais ou abra uma issue no repositório.
